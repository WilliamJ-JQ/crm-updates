# -*- coding: utf-8 -*-
"""服务看护 / 开关工具(纯代码,不调用任何 AI,不产生模型费用)。

  python3 keepalive.py               # 检查服务,不在就拉起(定时任务用的就是它)
  python3 keepalive.py --status      # 只看状态
  python3 keepalive.py --stop        # 停止服务
  python3 keepalive.py --port 8799   # 指定端口(默认 8765)

特点:服务以"独立进程"方式启动(脱离网关进程),所以网关重启不会带走它;
电脑重启后,由定时看护任务在 15 分钟内把它拉回来。
"""
import argparse
import os
import signal
import subprocess
import sys
import time
import urllib.request

PROJECT = os.path.dirname(os.path.abspath(__file__))
DEFAULT_PORT = 8765


def pidfile(port):
    return os.path.join(PROJECT, "data", "server-%d.pid" % port)


def logfile(port):
    return os.path.join(PROJECT, "data", "server-%d.log" % port)


def alive(port, timeout=3):
    try:
        with urllib.request.urlopen("http://127.0.0.1:%d/api/stats" % port,
                                    timeout=timeout) as r:
            return r.status == 200
    except Exception:
        return False


def scan_pids(port):
    """在 /proc 里找负责该端口的进程(pid 文件丢失时的兜底方案)。"""
    pids = []
    for name in os.listdir("/proc"):
        if not name.isdigit():
            continue
        try:
            with open("/proc/%s/cmdline" % name, "rb") as f:
                cmd = f.read().decode("utf-8", "replace").replace("\x00", " ")
        except Exception:
            continue
        if "main.py" in cmd and ("--port %d" % port) in cmd:
            pids.append(int(name))
    return pids


def stop(port):
    pids = []
    pf = pidfile(port)
    if os.path.exists(pf):
        try:
            pids.append(int(open(pf).read().strip()))
        except Exception:
            pass
        try:
            os.remove(pf)
        except Exception:
            pass
    for p in scan_pids(port):
        if p not in pids:
            pids.append(p)
    killed = []
    for pid in pids:
        try:
            os.kill(pid, signal.SIGTERM)
            killed.append(pid)
        except Exception:
            pass
    time.sleep(0.8)
    return killed


def start(port):
    data_dir = os.path.join(PROJECT, "data")
    os.makedirs(data_dir, exist_ok=True)
    with open(logfile(port), "ab") as logf:
        proc = subprocess.Popen(
            [sys.executable, "main.py", "--no-browser", "--port", str(port)],
            cwd=PROJECT, stdout=logf, stderr=logf, stdin=subprocess.DEVNULL,
            start_new_session=True)
    with open(pidfile(port), "w") as f:
        f.write(str(proc.pid))
    time.sleep(1.5)
    return proc.pid


def main():
    ap = argparse.ArgumentParser(description="外贸客户工作台 - 服务看护")
    ap.add_argument("--port", type=int, default=DEFAULT_PORT)
    ap.add_argument("--status", action="store_true", help="只查看状态")
    ap.add_argument("--stop", action="store_true", help="停止服务")
    args = ap.parse_args()

    if args.status:
        if alive(args.port):
            print("OK: 服务正在运行(端口 %d)" % args.port)
            return 0
        print("DEAD: 服务没有运行(端口 %d)" % args.port)
        return 1

    if args.stop:
        killed = stop(args.port)
        if killed:
            print("已停止进程: %s" % ",".join(str(k) for k in killed))
        else:
            print("服务本来就没在跑")
        print("OK: 服务已关闭" if not alive(args.port)
              else "WARN: 端口仍有响应,请稍后重查(日志 %s)" % logfile(args.port))
        return 0

    if alive(args.port):
        print("OK: 服务正在运行(端口 %d),无需处理" % args.port)
        return 0
    print("服务未响应,正在拉起……")
    pid = start(args.port)
    if alive(args.port):
        print("OK: 已拉起,pid=%d,端口 %d" % (pid, args.port))
        return 0
    print("FAIL: 拉起后仍无响应,请查看 %s" % logfile(args.port))
    return 1


if __name__ == "__main__":
    sys.exit(main())
