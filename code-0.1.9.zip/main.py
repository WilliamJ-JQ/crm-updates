# -*- coding: utf-8 -*-
"""外贸客户工作台 —— 启动入口。

运行:
  python main.py                # 启动后自动打开浏览器操作台
  python main.py --no-browser   # 只启动服务(不弹浏览器)
  python main.py --port 9000    # 换端口

说明:界面是本地网页(只在你电脑上),数据全在本地 data/crm.db。

【更新机制】启动时先应用"已下载待更新"(update/pending/)—— 必须在
import app 之前做,这样新代码才会被加载。因此**重启即可生效**,不依赖
任何 .bat(taskkill/xcopy 在 Windows 上不可靠)。
"""
import argparse
import os
import shutil
import sys
import time

ROOT = os.path.dirname(os.path.abspath(__file__))


def _backup_db():
    """应用更新前,先把客户数据库备份一份(双保险;更新本就不碰数据)。"""
    cands = []
    env = (os.environ.get("CRM_DATA_DIR") or "").strip()
    if env:
        cands.append(os.path.join(env, "crm.db"))
    cands.append(os.path.join(ROOT, "data", "crm.db"))
    cands.append(os.path.join(os.path.expanduser("~"), "客户工作台数据", "crm.db"))
    for dbp in cands:
        if os.path.exists(dbp):
            try:
                shutil.copy2(dbp, dbp + ".bak-update-" + time.strftime("%Y%m%d-%H%M%S"))
                print("[update] 已备份数据库:", dbp)
            except Exception as e:
                print("[update] 备份数据库失败(继续):", e)
            return


def _apply_pending_update():
    """把 update/pending/ 里的新代码覆盖到软件目录。失败不影响启动。"""
    pend = os.path.join(ROOT, "update", "pending")
    if not os.path.isdir(pend):
        return
    try:
        _backup_db()
        for name in os.listdir(pend):
            src = os.path.join(pend, name)
            dst = os.path.join(ROOT, name)
            if os.path.isdir(src):
                shutil.copytree(src, dst, dirs_exist_ok=True)
            else:
                shutil.copy2(src, dst)
        shutil.rmtree(pend, ignore_errors=True)
        pj = os.path.join(ROOT, "update", "pending.json")
        if os.path.exists(pj):
            os.remove(pj)
        print("[update] 已应用上次下载的更新")
    except Exception as e:
        print("[update] 应用更新失败(不影响启动):", e)


_apply_pending_update()

from app import server   # noqa: E402  (必须在应用更新之后再导入)


def main():
    p = argparse.ArgumentParser(description="外贸客户工作台(本地版)")
    p.add_argument("--port", type=int, default=server.DEFAULT_PORT,
                   help=f"本地端口(默认 {server.DEFAULT_PORT})")
    p.add_argument("--no-browser", action="store_true",
                   help="启动后不自动打开浏览器")
    args = p.parse_args()
    server.run_server(port=args.port, open_browser=not args.no_browser)


if __name__ == "__main__":
    main()
