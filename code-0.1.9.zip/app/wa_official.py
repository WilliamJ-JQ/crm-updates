# -*- coding: utf-8 -*-
"""WhatsApp **官方** Cloud API 通道(替代已退役的非官方桥接)。

为什么换:非官方客户端(Baileys 协议)违反 WhatsApp 条款,实测导致账号被封。
官方 Cloud API 是 Meta 的正规接口 —— 合规、不会被封,代价是需要一次性配置。

本模块只做三件事:
  1) signature_ok()  校验 Meta 推送的 HMAC 签名(防伪造)
  2) parse_webhook() 把 Meta 的 webhook 载荷拆成一条条标准消息
  3) send_text()     发送(给后续「夜间回复」用;当前默认关闭)

⚠️ 重要事实:官方 Cloud API **不支持群聊**,只能一对一。
   所以群里那一路(运营建群 / SM 报价 / 老板 / 客户设计师)在官方通道下收不到,
   需要另外的人工或转发方案 —— 见项目文档。

配置项(都存在软件设置里):
    wa_mode            通道模式:official / none
    wa_verify_token    回填给 Meta 的验证口令(本模块自动生成)
    wa_app_secret      Meta App 的 App Secret(用于校验签名)
    wa_phone_number_id 发送用的号码 ID
    wa_access_token    Cloud API 访问令牌(发送时用)
"""
import hashlib
import hmac
import json
import secrets
import time
import urllib.request

from . import db, log

GRAPH = "https://graph.facebook.com/v21.0"


def ensure_settings():
    """首次运行时补齐官方通道需要的配置(验证口令自动生成)。"""
    changed = []
    if not db.get_setting("wa_mode", ""):
        db.set_setting("wa_mode", "official")
        changed.append("wa_mode=official")
    if not db.get_setting("wa_verify_token", ""):
        tok = secrets.token_hex(16)
        db.set_setting("wa_verify_token", tok)
        changed.append("wa_verify_token(已生成)")
    return changed


def signature_ok(raw_body, header):
    """校验 X-Hub-Signature-256(sha256=hex,基于 App Secret 的 HMAC)。"""
    secret = db.get_setting("wa_app_secret", "")
    if not secret:
        # 还没配置 App Secret:此时**拒绝**而不是放行(宁可收不到,不要收到伪造的)
        return False
    got = (header or "").strip()
    if not got.startswith("sha256="):
        return False
    want = hmac.new(secret.encode("utf-8"), raw_body or b"", hashlib.sha256).hexdigest()
    return hmac.compare_digest(got[7:], want)


def _ts(s):
    """Meta 给的是秒级 unix 时间戳 → 本地 'YYYY-MM-DD HH:MM:SS'。"""
    try:
        n = int(s)
    except (TypeError, ValueError):
        return db.now_iso()
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(n))


def _content_of(m):
    """把一条 Cloud API 消息转成文字(媒体只留标记,和桥接时代保持一致)。"""
    t = m.get("type")
    if t == "text":
        return (m.get("text") or {}).get("body") or ""
    if t == "button":
        return (m.get("button") or {}).get("text") or "(按钮)"
    if t == "interactive":
        i = m.get("interactive") or {}
        for k in ("button_reply", "list_reply"):
            if i.get(k):
                return (i[k].get("title") or "") + ""
        return "(交互消息)"
    if t == "image":
        return "【图片·未传内容】" + ((m.get("image") or {}).get("caption") or "")
    if t == "video":
        return "【视频·未传内容】" + ((m.get("video") or {}).get("caption") or "")
    if t == "audio":
        return "【语音·需在手机上听】"
    if t == "document":
        d = m.get("document") or {}
        return "【文件·未传内容】" + (d.get("filename") or "")
    if t == "sticker":
        return "【贴纸】"
    if t == "location":
        return "【位置】"
    if t == "contacts":
        return "【联系人名片】"
    return "【%s】" % (t or "未知类型")


def parse_webhook(data):
    """把 Meta 的 webhook 载荷拆成标准消息列表。

    返回 [{'phone','name','content','ts','wa_message_id'}...]
    (只取客户发来的消息;状态回执、模板回执等一律忽略)
    """
    out = []
    for entry in (data or {}).get("entry") or []:
        for ch in entry.get("changes") or []:
            v = ch.get("value") or {}
            if ch.get("field") != "messages":
                continue
            names = {}
            for c in v.get("contacts") or []:
                names[str(c.get("wa_id") or "")] = ((c.get("profile") or {}).get("name")
                                                    or "").strip()
            meta = v.get("metadata") or {}
            for m in v.get("messages") or []:
                frm = str(m.get("from") or "").strip()
                if not frm:
                    continue
                out.append({
                    "phone": "+" + frm,
                    "name": names.get(frm, ""),
                    "content": (_content_of(m) or "").strip(),
                    "ts": _ts(m.get("timestamp")),
                    "wa_message_id": m.get("id") or "",
                    "phone_number_id": meta.get("phone_number_id") or "",
                })
    return out


def send_text(to_phone, text):
    """发送一条文本(给后续「夜间回复」用)。

    ⚠️ 当前**不在任何自动流程里调用** —— 只有开关打开后由夜间回复调用。
    合规提醒:客户 24 小时窗口外必须用模板消息(收费),窗口内可自由回复。
    """
    if db.get_setting("night_reply_enabled", "0") != "1":
        log.warn("发送被拦 @wa_official.send_text", detail="夜间回复未启用,不发送到 %s" % to_phone)
        return {"ok": False, "error": "night_reply_enabled=0"}
    pid = db.get_setting("wa_phone_number_id", "")
    token = db.get_setting("wa_access_token", "")
    if not pid or not token:
        return {"ok": False, "error": "缺少 phone_number_id 或 access_token"}
    body = json.dumps({"messaging_product": "whatsapp", "to": to_phone.lstrip("+"),
                       "type": "text", "text": {"body": text[:4000]}}).encode("utf-8")
    req = urllib.request.Request(GRAPH + "/" + pid + "/messages", data=body,
                                 headers={"Content-Type": "application/json",
                                          "Authorization": "Bearer " + token})
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            return {"ok": True, "resp": json.loads(r.read().decode("utf-8"))}
    except Exception as e:
        log.warn("发送失败 @wa_official.send_text", e)
        return {"ok": False, "error": str(e)}


def status():
    """给界面用的通道状态。"""
    return {
        "mode": db.get_setting("wa_mode", "official"),
        "verify_token": db.get_setting("wa_verify_token", ""),
        "has_secret": bool(db.get_setting("wa_app_secret", "")),
        "has_token": bool(db.get_setting("wa_access_token", "")),
        "phone_number_id": db.get_setting("wa_phone_number_id", ""),
        "night_reply": db.get_setting("night_reply_enabled", "0"),
        "webhook_path": "/api/wa/webhook",
    }
