# -*- coding: utf-8 -*-
"""历史聊天导入器(纯代码,零 token)。

解决一个关键坑:**原导入器丢弃时间戳**,导致所有历史消息都记成"现在",
"最近跟进时间 / 分级节奏 / 今日跟进"全部失真。本模块保留真实日期时间。

支持格式:
  1) WhatsApp 导出(Android):  2026/9/9, 14:30 - 名字: 内容
     WhatsApp 导出(iOS):      [9/9/26, 2:30:15 PM] 名字: 内容
  2) 命令行简单格式:           IN: 内容   /   OUT: 内容
  3) 纯文本:                   每行一条(无时间戳)
续行(消息内部的换行)会自动接到上一条。

方向判定:按参与者名字区分——名字 == 客户(peer) 算"客户发来"(in),其余算"我方发出"(out)。
"""
import re
from datetime import datetime

from . import service

_HEADER_RE = re.compile(
    r"^\s*\[?"
    r"(?P<date>\d{1,4}[/.\-]\d{1,2}[/.\-]\d{1,4})"
    r"[,，]?\s+"
    r"(?P<time>\d{1,2}:\d{2}(?::\d{2})?)\s*(?P<ampm>[AaPp][Mm])?"
    r"\s*[\]\-–—]*\s*"
    r"(?P<name>[^:：]{1,40}?)\s*[:：]\s?"
    r"(?P<content>.*)$"
)


def _to_iso(date_s, time_s, ampm):
    """日期时间 → 'YYYY-MM-DD HH:MM:SS';解析不了返回 None。"""
    parts = re.split(r"[/.\-]", date_s)
    if len(parts) != 3:
        return None
    try:
        nums = [int(p) for p in parts]
    except ValueError:
        return None
    if len(parts[0]) == 4:          # YYYY/M/D
        y, mo, d = nums
    else:                            # M/D/YY(WhatsApp 常见)
        mo, d, y = nums
        if y < 100:
            y += 2000
    tp = time_s.split(":")
    try:
        hh, mm = int(tp[0]), int(tp[1])
        ss = int(tp[2]) if len(tp) > 2 else 0
    except ValueError:
        return None
    if ampm:
        ap = ampm.lower()
        if ap == "pm" and hh < 12:
            hh += 12
        if ap == "am" and hh == 12:
            hh = 0
    try:
        return datetime(y, mo, d, hh, mm, ss).strftime("%Y-%m-%d %H:%M:%S")
    except ValueError:
        return None


def parse_chat(text):
    """解析聊天文本。

    返回 {'messages': [{ts,name,content}], 'participants': {name: 条数}, 'has_ts': bool}
    """
    lines = [ln.rstrip() for ln in (text or "").splitlines()]
    has_header = any(_HEADER_RE.match(ln) for ln in lines if ln.strip())

    if not has_header:
        # 简单模式:每行一条;支持 IN:/OUT: 前缀
        msgs = []
        for ln in lines:
            if not ln.strip():
                continue
            up = ln.strip().upper()
            if up.startswith("IN:") or up.startswith("OUT:"):
                d = "in" if up.startswith("IN:") else "out"
                msgs.append({"ts": None, "name": "__DIR__:" + d,
                             "content": ln.split(":", 1)[1].strip()})
            else:
                msgs.append({"ts": None, "name": "", "content": ln.strip()})
        return {"messages": msgs, "participants": {}, "has_ts": False}

    # 头部模式:带续行合并
    msgs, participants, has_ts = [], {}, False
    cur = None
    for ln in lines:
        if not ln.strip():
            continue
        m = _HEADER_RE.match(ln)
        if m:
            ts = _to_iso(m.group("date"), m.group("time"), m.group("ampm"))
            name = m.group("name").strip()
            content = m.group("content").strip()
            if ts:
                has_ts = True
            cur = {"ts": ts, "name": name, "content": content}
            msgs.append(cur)
            participants[name] = participants.get(name, 0) + 1
        elif cur is not None:
            cur["content"] = (cur["content"] + "\n" + ln.strip()).strip()
        else:
            msgs.append({"ts": None, "name": "", "content": ln.strip()})
    return {"messages": msgs, "participants": participants, "has_ts": has_ts}


def pick_peer(participants, peer_name=None):
    """客户是谁:优先用指定名字;否则取发言最多的一方(通常是客户)。"""
    if peer_name:
        return peer_name
    if not participants:
        return None
    return max(participants.items(), key=lambda kv: kv[1])[0]


def import_chat(customer_id, text, peer_name=None, default_direction="in",
                source="import"):
    """解析并批量入库(保留时间戳)。返回统计信息。"""
    parsed = parse_chat(text)
    peer = pick_peer(parsed["participants"], peer_name)
    saved = 0
    for m in parsed["messages"]:
        if not m["content"].strip():
            continue
        nm = m["name"]
        if nm.startswith("__DIR__:"):
            direction = nm.split(":", 1)[1]
        elif peer:
            direction = "in" if nm.strip().lower() == peer.strip().lower() else "out"
        else:
            direction = default_direction
        service.process_message(customer_id, direction, m["content"], ts=m["ts"],
                                source=source)
        saved += 1
    return {"imported": saved, "peer": peer,
            "participants": parsed["participants"], "has_ts": parsed["has_ts"]}
