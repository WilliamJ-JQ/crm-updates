# -*- coding: utf-8 -*-
"""业务编排层:消息入库 → 规则分析 → 生成提醒建议。

核心原则:这条链路只"记录 + 建议",从不直接对客户发任何东西。
提醒要生效,必须由你在界面点【批准】(见 decide_reminder)。
"""
import re

from . import db, docs, profile, rules
from . import log

_CTRL_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f]")

# WhatsApp 导出里的“系统通知行”(导出群聊时常见,不是对话内容)
_WA_HEADER_RE = re.compile(r"^\s*\[[^\]]{6,50}\]\s*[-–—]?\s*")
_NOISE_MARKERS = ("已创建群组", "已添加", "已加入", "你已", "消息和通话已进行端到端加密",
                  "端到端加密", "已更改此群", "删除了此群", "已置顶")


def _is_noise(text):
    """过滤导出文件里的系统通知行(它们不是客户说的话)。"""
    t = (text or "").strip()
    if not t:
        return True
    if len(t) > 160 or not _WA_HEADER_RE.match(t):
        return False        # 不像导出行,不当噪声
    core = _WA_HEADER_RE.sub("", t)
    for m in _NOISE_MARKERS:
        if m in core:
            return True
    return not core.strip(" -–—")


def _looks_binary(text):
    """二进制/乱码内容不该入库。

    踩过的坑:用户把 WhatsApp 导出的 **.zip** 当文本粘进来,
    几百 KB 二进制混进消息表,污染分类、画像和以后的自动回复。
    """
    if not text or not text.strip():
        return True
    if text.startswith("PK\x03\x04") or "\x00" in text:
        return True
    n = max(1, len(text))
    bad = len(_CTRL_RE.findall(text)) + text.count("\ufffd")
    return (bad / n) > 0.02


# 媒体消息的标记 → 给消息打一个显眼标签,提醒“这条要去手机上翻”
_MEDIA_TAGS = (("【图片", "📎 图片(未传输)"), ("【视频", "📎 视频(未传输)"),
               ("【语音", "📎 语音(未传输)"), ("【文件", "📎 文件(未传输)"),
               ("【贴纸", "📎 贴纸(未传输)"), ("【名片", "📎 名片(未传输)"),
               ("【位置", "📎 位置(未传输)"))
_OLD_MEDIA = ("(图片)", "(语音)", "(视频)", "(贴纸)", "(名片)", "(位置)")


def _group_customer_name(chat):
    """群名 → 客户档案名(去掉日期前缀和公司词,保留客户/项目部分)。"""
    s = (chat or "").strip()
    if not s or "@" in s:              # 桥接没拿到群名时,chat 会是 JID
        return "群聊待归类"
    s = re.sub(r"^[Ww]?\s*\d{1,2}[.\-/]\d{1,2}\s*[丨|·\-\s]*", "", s)   # 日期前缀
    s = re.sub(r"^George\s*(Group|Vip|VIP)?\s*[&|丨·\-]*\s*", "", s, flags=re.I)
    s = s.strip(" &|丨·-")
    return (s or chat)[:60]


def media_tag(content):
    """媒体消息(内容不传输)→ 返回一个标记标签,普通文本返回空字符串。"""
    t = (content or "").strip()
    for pref, tag in _MEDIA_TAGS:
        if t.startswith(pref):
            return tag
    for old in _OLD_MEDIA:
        if t == old or t.startswith(old):
            return "📎 附件(未传输)"
    return ""


def process_message(customer_id, direction, content, ts=None, source="", source_ref="",
                    sender_phone="", sender_name="", sender_role="", fast=False):
    """把一条聊天消息入库:自动打高价值标签,并按规则生成提醒建议。

    sender_role: 谁说的(customer/designer/other/pm/sm/team)—— 见 db.add_message。
    我方 PM 和 SM 的消息都是 direction='out',入库后都会触发“待跟进是否已回复”的代码扫描。

    返回 dict:
      message    -> 已入库的消息(含 id)
      tags       -> 命中的标签(中文)
      hits       -> 命中明细 {标签: [词,...]}
      suggestion -> 生成的提醒建议(只建议,未生效);没有则为 None
    """
    if not content or not content.strip():
        return None
    if _looks_binary(content):
        return None
    if _is_noise(content):
        return None
    # 时间戳在这里定一次:消息和由它生成的提醒共用同一个时刻。
    # 踩过的坑:桥接/接口没带 ts 时,提醒的 src_ts 会是空 → 待跟进自动关闭
    # 拿不到“原话时间”就直接跳过,SM 的回复永远关不掉那条待跟进。
    if not ts:
        ts = db.now_iso()
    analysis = rules.analyze(content, direction)
    mtag = media_tag(content)
    if mtag:
        analysis["tags"] = list(analysis["tags"]) + [mtag]
    msg_id = db.add_message(customer_id, direction, content, ts=ts,
                            tags=analysis["tags"], source=source, source_ref=source_ref,
                            sender_phone=sender_phone, sender_name=sender_name,
                            sender_role=sender_role)
    if fast:
        # —— 批量历史导入快通道 ——
        # 只落库 + 打标签:不生成提醒建议、不进 AI 队列、不跑画像/文档。
        # 否则几千条老消息会刷出几千张卡 + 把本地模型打爆。导入完成后统一再分析。
        return {"message": db.get_message(msg_id), "tags": analysis["tags"],
                "hits": analysis["hits"], "suggestion": None, "docs_created": 0}
    suggestion = None
    if analysis["suggestion"]:
        s = analysis["suggestion"]
        rid = db.add_reminder(customer_id, kind=s["kind"], note=s["note"],
                              days=s.get("days"), quote=s.get("quote", ""),
                              src_ts=ts or "", src_direction=direction,
                              src_msg_id=msg_id)
        suggestion = {"id": rid, "kind": s["kind"], "note": s["note"],
                      "days": s.get("days"), "quote": s.get("quote", "")}
    # 代码先滤:像"待办"的消息才丢给后台 AI 识别(不阻塞 PM 聊天)
    try:
        from . import aiworker
        if aiworker.should_enqueue(content, direction, analysis):
            if db.queue_stats()["pending"] < aiworker.MAX_PENDING:
                db.enqueue_msg(msg_id, customer_id)
    except Exception as e:
        log.swallow("service.py:132", e)
    # 我方刚发出一条消息 → 立刻跑代码层,看能不能关掉某个待跟进(零成本、瞬间)
    if direction == "out":
        try:
            from . import followcheck
            followcheck.on_out_message(customer_id)
        except Exception as e:
            log.swallow("service.py:139", e)
    # 消息入库后,自动推导并更新客户档案(身份/时区/分级/跟进分类/下次跟进日,零 token)
    profile.enrich_customer(customer_id)
    # 客户文档:代码通道自动提炼(零 token);AI 通道默认关,需手动点
    docs_n = 0
    try:
        if db.get_setting("docs_auto", "1") == "1":
            docs_n = docs.extract_code_to_db(customer_id, content,
                                             direction=direction, msg_id=msg_id)
    except Exception:
        docs_n = 0
    return {
        "message": db.get_message(msg_id),
        "tags": analysis["tags"],
        "hits": analysis["hits"],
        "suggestion": suggestion,
        "docs_created": docs_n,
    }


def _peer_phone(chat_jid):
    """从会话 JID 里取**【对方】的号码**。

    私聊:remoteJid 就是对方号(12345678901@s.whatsapp.net)→ 取 12345678901。
    群聊(@g.us)→ 返回空(群号不是客户)。
    @lid 等内部身份 → 返回空 —— 绝不拿内部 id 当手机号(会建假客户)。
    """
    j = (chat_jid or "").strip()
    if not j or j.endswith("@g.us"):
        return ""
    if not (j.endswith("@s.whatsapp.net") or j.endswith("@c.us")):
        return ""
    num = j.split("@")[0].split(":")[0]
    d = db._digits(num)
    return d if len(d) >= 7 else ""


def ingest_message(data):
    """外部收信(WhatsApp 桥)统一入口:先判“谁发的 / 归哪个客户”,再入库。

    区分三类人:
      我方团队(team_members 名册里的 PM/SM/运营)   → direction=out,标注是谁回的
      客户本人(号码 = 客户档案号码)                     → direction=in, role=customer
      客户方其他人(群里同客户的另一个号:设计师/同事)  → direction=in, role=designer/other,
                                                          并入该客户档案的『相关人』,不另开档案

    返回 {ok, customer_id, message_id, role, sender} 或 {ok:False, skipped:原因}。
    跳过比建错档案好 —— 宁可少一条,不要脏数据。
    """
    def _skip(reason, ph=""):
        """跳过原因留痕 —— 批量导入出问题时，能直接看“到底为什么没进”。"""
        try:
            import os as _os
            path = _os.path.join(db.PROJECT_DIR, "data", "ingest-skips.log")
            with open(path, "a", encoding="utf-8") as f:
                f.write("%s\t%s\t%s\t%s\n" % (db.now_iso(), reason, ph,
                                              (content or "")[:40].replace("\n", " ")))
        except Exception as e:
            log.swallow("service.py:180", e)
        return {"ok": False, "skipped": reason}

    content = (data.get("content") or "").strip()
    if not content:
        return _skip("空内容")
    phone = (data.get("phone") or "").strip()
    # 【坑】历史导入里出现过 '+0' 这种垃圾号码 → 建出一个假客户。号码至少要 7 位数字。
    if phone and len(re.sub(r"\D", "", phone)) < 7:
        return _skip("号码不合理:%s" % phone, phone)
    name = (data.get("name") or "").strip()
    direction = "out" if str(data.get("direction") or "in") == "out" else "in"
    source = (data.get("source") or "direct").strip()
    chat = (data.get("chat") or data.get("group") or "").strip()
    chat_jid = (data.get("chat_jid") or "").strip()
    hint = (data.get("sender_role") or "").strip()
    bulk = bool(data.get("bulk"))     # 历史批量导入模式(只落库,不刷卡片)

    # 群聊还没绑定客户时,先拿群名去匹配已有客户(运营建群习惯把客户名写进群名);
    # 匹配不上且是**历史批量导入** → 按群名建一份「待归类」档案,
    # 否则这个群几千条历史永远进不来(之后用【合并到其他客户】一键并到真客户,可撤回)。
    if source == "group" and chat and not db.get_chat_customer(chat):
        guess = db.match_customer_by_group_name(chat)
        if guess:
            db.link_chat(chat, guess["id"])
        elif bulk:
            cid_new = db.create_customer({"name": _group_customer_name(chat),
                                          "phone": "", "source": "群聊导入"})
            db.link_chat(chat, cid_new)

    # ---- 1) 谁发的 ----
    tm = db.find_team_by_phone(phone) if phone else None
    if tm:
        role, direction = db.role_key(tm.get("role")), "out"
        sname = (tm.get("name") or name or "").strip()
    elif direction == "out" or hint == "me":
        role, direction = "pm", "out"
        sname = name or "我"
    else:
        role, sname = "customer", name

    # ---- 2) 归哪个客户 ----
    if role in ("pm", "sm", "team"):
        cid = None
        if chat:
            c = db.get_chat_customer(chat)      # 群 / 直聊 都支持“会话绑定”
            cid = c["id"] if c else None
        if not cid and chat_jid:
            # 【关键】私聊里 chat_jid 就是**对方**的号。我方发言时 sender 是我自己的
            # 国内号(+86),拿它找不到客户 → 这条回复就被丢了(用户实测:“我明明回了”)。
            peer = _peer_phone(chat_jid)
            if peer:
                c = db.find_customer_by_phone(peer)
                if not c:
                    p = db.find_person_by_phone(peer)
                    c = db.get_customer(p["customer_id"]) if p else None
                cid = c["id"] if c else None
        if not cid and phone:
            c = db.find_customer_by_phone(phone)
            if not c:
                # 【坑】我方的消息发给“相关人”(如某客户的设计师)时,
                # 号码不属于任何客户 → 以前直接丢掉,导致“我已回复”这件事看不见,
                # 待跟进也不会自动关闭。现在按相关人回所属客户。
                p = db.find_person_by_phone(phone)
                c = db.get_customer(p["customer_id"]) if p else None
            cid = c["id"] if c else None
        if cid and chat:
            db.link_chat(chat, cid)             # 记住这个会话,下次没号码也能归位
        if not cid:
            return _skip("我方消息,但这个会话还没绑定客户", phone)
    elif source == "group" and chat and db.get_chat_customer(chat):
        owner = db.get_chat_customer(chat)
        cid = owner["id"]
        if not phone:
            # 【坑】历史同步里有些群消息拿不到发送者 —— 以前会走到下面去建一条
            # 空号码的“相关人”,一次导入就刷出两千多条垃圾(实测 2905 条)。
            role = "other"
            sname = name or "群成员(未识别)"
        elif not (owner.get("phone") or "").strip():
            # 档案是从群名自动建的、还没有号码 —— 群里出现谁的真号,就当成客户本人补上。
            # (历史同步只给内部 LID,拿不到号;但实时消息带真号,这样会自动补全。)
            db.update_customer(cid, {"phone": phone})
            owner = db.get_customer(cid) or owner
            role = "customer"
            sname = name or owner.get("name") or phone
        elif not db.same_phone(owner.get("phone"), phone):
            if db._digits(phone).startswith("86"):
                # 【改】国内号在客户群里发言:以前**整条丢掉** —— 结果运营(某运营)
                # 给客户建的“资料卡”群连发 14 条,一条都没进来。现在照常入库
                # (记成我方同事发言),并把这个号挂进“待确认同事”,一键加名册。
                db.note_pending_team(phone, name)
                role = "team"
                sname = name or "我方(未署名)"
            else:
                # 群里同客户的另一个人(多数就是客户自带的设计师)
                lvl, quote = rules.designer_signal(content)
                old = db.find_person(cid, phone)
                manual = bool(old and old.get("source") == "human")
                if lvl == "strong" and not manual:
                    p = db.upsert_person(cid, phone, name or (old or {}).get("name", ""),
                                         "设计师", note=quote)
                else:
                    p = db.upsert_person(cid, phone, name or (old or {}).get("name", ""),
                                         (old or {}).get("role") or "其他",
                                         note=quote if lvl == "mention" else "")
                prole = (p or {}).get("role") or "其他"
                role = "designer" if prole == "设计师" else "other"
                sname = (p or {}).get("name") or name or phone
    elif not phone and source == "group" and chat:
        # 历史同步里有的群消息拿不到发送者(桥接已尽力) —— 只要这个群已绑定客户,
        # 就归到该客户名下并标「群成员(未识别)」,不丢数据也不建假客户。
        owner = db.get_chat_customer(chat)
        if not owner:
            return _skip("群成员未识别,且这个群还没绑定客户(chat=%s)" % chat, phone)
        cid = owner["id"]
        role = "other"
        sname = name or "群成员(未识别)"
    elif not phone and source == "direct" and chat and db.get_chat_customer(chat):
        # 直聊里对方是 LID、拿不到号码 → 靠会话绑定归属(桥接已尽力保留)
        owner = db.get_chat_customer(chat)
        cid = owner["id"]
        role = "other"
        sname = name or owner.get("name") or "对方"
    elif phone and db.find_person_by_phone(phone):
        # 已经并到某个客户名下的相关人(如某客户的设计师)再发消息 →
        # 回原客户名下,不能又建一份新档案(否则又是“同人两号”)
        person = db.find_person_by_phone(phone)
        cid = person["customer_id"]
        role = "designer" if person.get("role") == "设计师" else "other"
        sname = person.get("name") or name or phone
        if source == "direct" and chat:
            db.link_chat(chat, cid)             # 相关人的直聊也绑住
    else:
        cust = db.find_customer_by_phone(phone) if phone else None
        if cust:
            cid = cust["id"]
            if name and (not cust.get("name") or cust["name"] in (phone, "新客户")):
                db.update_customer(cid, {"name": name})
        elif db._digits(phone).startswith("86") or hint == "unknown86":
            # 【改】未在名册的国内号:如果是在**群里**发的(多半是运营/同事在给客户
            # 建群、写资料),就按群名建档并把这句记下;私聊的国内号仍然跳过(防骚扰)。
            if source == "group" and chat:
                cid_new = db.create_customer({"name": _group_customer_name(chat),
                                              "phone": "", "source": "群聊导入"})
                db.link_chat(chat, cid_new)
                cid = cid_new
                db.note_pending_team(phone, name)
                role = "team"
                sname = name or "我方(未署名)"
            else:
                # 【改 2026-09-16】私聊的国内号:以前直接丢掉(当成同事/骚扰),
                # 结果“连上了却收不到消息、不建档”。现在一律建档——
                # 同事请在【设置 → 团队名册】里登记,登记过的才算我方,不会建客户档。
                cid = db.create_customer({"name": name or phone or "国内号",
                                          "phone": phone, "source": "WhatsApp"})
        else:
            cid = db.create_customer({"name": name or phone or "新客户",
                                      "phone": phone, "source": "WhatsApp"})
        if source == "group" and chat:
            db.link_chat(chat, cid)   # 群 → 客户:以后同群的人自动归到他名下

    # 重复导入防护(重要):重新扫码会把同一批历史再推一次 → 内容相同就跳过,
    # 这样“补扫一次把 Marvin 救回来”不会把其他客户的记录变成两份。
    if bulk:
        _con = db.connect()
        _dup = _con.execute(
            "SELECT id FROM messages WHERE customer_id=? AND IFNULL(ts,'')=IFNULL(?,'')"
            " AND content=? LIMIT 1",
            (cid, data.get("ts"), content)).fetchone()
        _con.close()
        if _dup:
            return {"ok": True, "customer_id": cid, "message_id": _dup["id"],
                    "dup": True, "bulk": True}

    # 【坑】运营/PM 在群里说的话,方向必须是“我方发出”。以前只看 fromMe,
    # 结果运营介绍 PM 的那句话被当成客户需求 → 生成“客户要求”待办,
    # PM 后面打了招呼也判成“我没回复”。
    if role in ("pm", "sm", "team") and direction != "out":
        direction = "out"

    res = process_message(cid, direction, content, ts=data.get("ts"),
                          source=source, source_ref=chat, sender_phone=phone,
                          sender_name=sname, sender_role=role, fast=bulk)
    return {"ok": True, "customer_id": cid,
            "message_id": (res or {}).get("message", {}).get("id"),
            "role": role, "sender": sname, "bulk": bulk}


def approve_reminder(rid, notify_date=None):
    """批准一条提醒建议。

    - 承诺类(带 days):按"承诺 N 天内 + 提前 lead 天提醒"自动算出提醒日。
      例:3天内报价,lead=1 → 提醒日 = 今天 + (3-1)= 2 天后。
    - 行程类/手动(无 days):必须由你给定提醒日期 notify_date(YYYY-MM-DD)。
    返回更新后的提醒 dict;参数不合法返回 None。
    """
    r = db.get_reminder(rid)
    if not r:
        return None
    if r.get("days") is not None:
        try:
            lead = max(1, int(db.get_setting("reminder_lead_default", "1") or 1))
        except ValueError:
            lead = 1
        from datetime import date, timedelta
        offset = max(0, r["days"] - lead)
        notify_date = (date.today() + timedelta(days=offset)).isoformat()
        return db.set_reminder_status(rid, db.R_APPROVED, notify_date)
    # 无天数:必须给日期
    if not notify_date:
        return None
    return db.set_reminder_status(rid, db.R_APPROVED, notify_date)


def cancel_reminder(rid):
    return db.set_reminder_status(rid, db.R_CANCELLED)


def mark_done(rid):
    return db.set_reminder_status(rid, db.R_DONE)


def create_manual_reminder(customer_id, kind, note, notify_date):
    """手动新建一条提醒(直接进入"已批准",到点提醒)。notify_date 必填。"""
    if not notify_date:
        return None
    return db.add_reminder(customer_id, kind, note, days=None,
                           status=db.R_APPROVED, notify_date=notify_date)
