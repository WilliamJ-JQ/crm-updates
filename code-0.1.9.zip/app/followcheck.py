# -*- coding: utf-8 -*-
"""待跟进自动关闭(三层判定)。

工作流(用户 2026-09-15 重定):
  第 1 层(代码,零成本、100% 准):
      这条待跟进之后,我方有没有发过消息?没有 → 一定没回复。
      有 → 再粗判“是否符合”(内容实质、非敷衍、非复杂)。符合 → 直接已处理(代码判 + 依据)。
  第 2 层(本地 AI):
      代码判不了(敷衍/不确定)→ 让 AI 判“回复是否解决客户需求”。
      AI 判“已解决” → 直接已处理(AI 判 + 依据)。
  第 3 层(人工):
      报价/方案/合同这类复杂回复 → 一律交人工;AI 判不出 → 交 PM 手动选依据。

铁律:自动完成的动作永远要能追到“我方哪条原话”,追不到就不许自动关闭。
(现在代码/AI 判符合会自动进已处理;都能撤回,且每条都留 reply_quote 作为依据。)
"""
import re
from datetime import datetime, timedelta

from . import ai as ai_mod
from . import db

# 回帖窗口:承诺几天内 → 允许的回复窗口至少 3 天
# 踩过的坑:代码层只看“之后有没有我方消息”,结果把 **8 天后** 的一条无关消息
# 当成了对客户问题的回复(隔 8 天不可能是对话回应)。
MIN_WINDOW_DAYS = 3

# 这些属于"复杂回复":涉及钱和承诺,AI 不自动判,必须人工看
_COMPLEX_RE = re.compile(
    r"报价|价格|单价|折扣|付款|定金|合同|交期|货期|方案|设计|图纸|cad|效果图|"
    r"quote|price|quotation|payment|deposit|contract|lead\s?time|design|drawing",
    re.I)

_SYS = (
    "你是外贸业务助理。判断【我方的这条回复】是否**已经回应**了客户的那个问题。\n"
    "只回答三种:\n"
    "- yes:我方回复直接回应了那个问题(给了价格/资料/明确答复/安排了事项)\n"
    "- no:我方回复只是寒暄、确认收到、或答非所问\n"
    "- unclear:看不出来\n"
    '只输出 JSON:{"answer":"yes","why":"一句话原因"}'
)


# 我方人员的显示名:PM=我 / SM=销售经理 / team=团队
_WHO = {"pm": "我(PM)", "sm": "销售经理", "team": "团队",
        "designer": "客户设计师", "other": "客户方成员", "customer": "客户"}


def who_label(name, role):
    """把「谁回的」变成人能看懂的一行字,例:张三(SM) / 我(PM)。"""
    base = _WHO.get((role or "").strip(), "")
    nm = (name or "").strip()
    if nm and nm != base:
        return "%s(%s)" % (nm, base) if base else nm
    return base or nm


def is_complex(rem):
    """是不是"复杂回复"(涉及钱/承诺)→ 必须人工。"""
    blob = (rem.get("note") or "") + " " + (rem.get("quote") or "")
    return bool(_COMPLEX_RE.search(blob))


def _set_decided_by(rid, val):
    """更正 decided_by:它应该表示“谁判了回复”,不是“谁分类的”。"""
    con = db.connect()
    con.execute("UPDATE reminders SET decided_by=? WHERE id=?", (val, rid))
    con.commit()
    con.close()


def _adequate(content):
    """代码层“回复是否符合”的粗判:内容实质、不是敷衍,且不涉及复杂回复。

    复杂(报价/方案/合同)一律返回 False —— 交给 AI 或人工,代码不自动判。
    """
    c = (content or "").strip().lower()
    if not c or len(c) < 12:
        return False
    if _COMPLEX_RE.search(c):
        return False
    trivial = {"ok", "ok.", "okay", "yes", "noted", "got it", "received",
               "thanks", "thank you", "will do", "sure", "1", "好的", "收到",
               "没问题", "ok thanks", "ok noted", "ok 👍"}
    return c not in trivial


def code_scan(customer_id=None, limit=100):
    """第 1 层:纯代码判断"我方有没有在合理时间内回复"。

    返回 (检查数, 找到回复数)。这一步零成本,可以先跑,把没回复的直接定死。
    """
    rows = db.list_reminders(status=db.R_APPROVED, limit=limit)
    checked = found = 0
    con = db.connect()
    outs_cache = {}      # customer_id → 我方消息(按 ts,id 升序);一次读好,避免 N+1
    try:
        for r in rows:
            if customer_id and r["customer_id"] != customer_id:
                continue
            src_ts = (r.get("src_ts") or "").strip()
            if not src_ts:
                continue          # 没有原话时间,不敢自动判
            checked += 1
            try:
                days = int(r.get("days")) if r.get("days") not in (None, "") else 0
            except (TypeError, ValueError):
                days = 0
            win = max(MIN_WINDOW_DAYS, days)
            try:
                start = datetime.fromisoformat(src_ts)
            except ValueError:
                continue
            end = start + timedelta(days=win)
            # 同一秒内的先后靠 id 判(消息入库顺序)—— 只比 ts 会把“同秒回复”漏掉
            try:
                src_mid = int(r.get("src_msg_id")) if r.get("src_msg_id") not in (None, "") else 0
            except (TypeError, ValueError):
                src_mid = 0
            if src_mid:
                where, qargs = ("(ts > ? OR (ts = ? AND id > ?))",
                                (r["customer_id"], src_ts, src_ts, src_mid,
                                 end.isoformat(" ")))
            else:
                where, qargs = ("ts > ?",
                                (r["customer_id"], src_ts, end.isoformat(" ")))
            cid = r["customer_id"]
            if cid not in outs_cache:
                outs_cache[cid] = [dict(x) for x in con.execute(
                    "SELECT id, ts, content, sender_role, sender_name FROM messages"
                    " WHERE customer_id=? AND direction='out'"
                    " ORDER BY ts, id", (cid,)).fetchall()]
            outs = outs_cache[cid]
            end_s = end.isoformat(" ")
            m = None
            for x in outs:              # 窗口内最后一条我方消息(同秒靠 id 判先后)
                xts = x["ts"] or ""
                if xts > end_s:
                    break
                if xts > src_ts or (src_mid and xts == src_ts
                                    and (x["id"] or 0) > src_mid):
                    m = x
            if m:
                # 已由 AI/人工定论、且**证据没变**(还是同一条消息)→ 保持结论,
                # 不要每轮重设(否则会与 AI 层来回震荡、界面也闪)
                if (r.get("reply_state") in ("answered_ai", "needs_human", "not_answered")
                        and str(m["id"]) == str(r.get("reply_msg_id") or "")):
                    continue
                found += 1
                try:
                    gap = (datetime.fromisoformat(m["ts"]) - start).days
                except ValueError:
                    gap = None
                who = who_label(m["sender_name"], m["sender_role"])
                if _adequate(m["content"]):
                    # 代码判“符合”→ 直接进已处理(代码判 + 依据),不再等 PM 点
                    db.set_reminder_reply(
                        r["id"], "replied", m["id"], m["content"],
                        "代码判:窗口内我方已实质回复(%s · %s),符合要求 → 自动完成"
                        % (who, m["ts"]),
                        reply_by=who, reply_role=(m["sender_role"] or ""))
                    con2 = db.connect()
                    con2.execute("UPDATE reminders SET decided_by='code', status=?, decided_at=?"
                                 " WHERE id=? AND status='approved'",
                                 (db.R_DONE, db.now_iso(), r["id"]))
                    con2.commit(); con2.close()
                else:
                    db.set_reminder_reply(
                        r["id"], "replied", m["id"], m["content"],
                        "代码判:原话之后 %s 天内有我方消息(%s · %s),是否切题待 AI/人工"
                        % (gap if gap is not None else "?", who, m["ts"]),
                        reply_by=who, reply_role=(m["sender_role"] or ""))
                continue
            # 窗口外还有消息 → 单独标出来(调试期一眼能看出为什么没算回复)
            late = None
            for x in outs:
                if (x["ts"] or "") > end_s:
                    late = x
                    break
            if late:
                try:
                    gap = (datetime.fromisoformat(late["ts"]) - start).days
                except ValueError:
                    gap = None
                who_late = who_label(late["sender_name"], late["sender_role"])
                db.set_reminder_reply(
                    r["id"], "later_reply", late["id"],
                    "%s 天后才有消息(超出 %s 天回复窗口,未算回复):%s"
                    % (gap if gap is not None else "?", win, late["content"]),
                    "代码判:%s 天窗口内无我方消息;最近一条在 %s 天后(%s · %s,由 %s 发出)—— 隔太久,不算对这句话的回复"
                    % (win, gap if gap is not None else "?", who_late, late["ts"], win),
                    reply_by=who_late, reply_role=(late["sender_role"] or ""))
            else:
                db.set_reminder_reply(
                    r["id"], "no_reply", "", "",
                    "代码判:原话(%s)之后 %s 天窗口内,我方没有任何消息"
                    % (src_ts, win))
    finally:
        con.close()
    return checked, found


def ai_confirm(rid):
    """第 2 层:让本地 AI 判断那条回复是否真的回应了问题。

    复杂回复(报价/方案/合同)**不交给 AI**,直接标 needs_human。
    """
    rem = db.get_reminder(rid) if hasattr(db, "get_reminder") else None
    if not rem:
        con = db.connect()
        try:
            row = con.execute("SELECT * FROM reminders WHERE id=?", (rid,)).fetchone()
            rem = dict(row) if row else None
        finally:
            con.close()
    if not rem:
        return "no-reminder"
    if rem.get("reply_state") != "replied":
        return "not-replied"
    if is_complex(rem):
        db.set_reminder_reply(rid, "needs_human", rem.get("reply_msg_id"),
                              rem.get("reply_quote"),
                              "本地AI未参与:内容涉及报价/交期/方案/合同 —— "
                              "按规则这类复杂回复不自动判,直接交你确认")
        _set_decided_by(rid, "")     # AI 没参与,别再留着创建时的 ai 标记
        return "needs_human"
    ask = "客户那边的要求:%s\n原文:%s\n我方的回复:%s" % (
        rem.get("note") or "", (rem.get("quote") or "")[:200],
        (rem.get("reply_quote") or "")[:300])
    try:
        out = ai_mod._call_api([{"role": "system", "content": _SYS},
                                {"role": "user", "content": ask}])
    except Exception:
        return "error"
    if isinstance(out, list):
        out = out[0] if out and isinstance(out[0], dict) else {}
    ans = str((out or {}).get("answer") or "").strip().lower()
    why = str((out or {}).get("why") or "").strip()[:120]
    if ans == "yes":
        db.set_reminder_reply(rid, "answered_ai", rem.get("reply_msg_id"),
                              rem.get("reply_quote"),
                              "本地AI判:答复切题" + (("(" + why + ")") if why else ""))
        # 工作流:AI 判“已解决”→ 直接进已处理(AI 判 + 依据)
        con = db.connect()
        con.execute("UPDATE reminders SET decided_by='ai', status=?, decided_at=?"
                    " WHERE id=? AND status='approved'",
                    (db.R_DONE, db.now_iso(), rid))
        con.commit(); con.close()
        return "answered_ai"
    if ans == "no":
        db.set_reminder_reply(rid, "not_answered", rem.get("reply_msg_id"),
                              rem.get("reply_quote"),
                              "本地AI判:答非所问" + (("(" + why + ")") if why else ""))
        _set_decided_by(rid, "ai")
        return "not_answered"
    db.set_reminder_reply(rid, "needs_human", rem.get("reply_msg_id"),
                          rem.get("reply_quote"),
                          "本地AI也看不出来" + (("(" + why + ")") if why else "") +
                          " —— 交你确认")
    _set_decided_by(rid, "")
    return "needs_human"


def on_out_message(customer_id):
    """我方刚发出一条消息 → 先跑代码层(瞬间),把候选标出来。"""
    try:
        return code_scan(customer_id=customer_id)
    except Exception:
        return (0, 0)


def next_ai_candidate():
    """找一条"已回复但还没经 AI 判断"的待跟进(给后台 worker 用)。"""
    con = db.connect()
    try:
        row = con.execute(
            "SELECT id FROM reminders WHERE status=? AND reply_state='replied'"
            " ORDER BY id LIMIT 1", (db.R_APPROVED,)).fetchone()
        return row["id"] if row else None
    finally:
        con.close()


def stats():
    con = db.connect()
    try:
        def n(state):
            return con.execute(
                "SELECT COUNT(*) n FROM reminders WHERE status=? AND reply_state=?",
                (db.R_APPROVED, state)).fetchone()["n"]
        return {"no_reply": n("no_reply"), "replied": n("replied"),
                "answered_ai": n("answered_ai"), "needs_human": n("needs_human"),
                "not_answered": n("not_answered")}
    finally:
        con.close()
