# -*- coding: utf-8 -*-
"""渐进上下文(纯代码) —— 别急着把不确定的丢给 AI。

一个承诺往往不是一句话能说清的:主句讲"我们发报价",时间却在上一段
("客户在催" / "他说这周要")。所以做法是 **缺什么就往外扩一层找**:

    L0 本句  →  L1 同段(±3 条)  →  L2 前后 10 条  →  L3 本客户前 2 天  →  L4 交给 AI

判断标准是"**要素齐不齐**"(代码能解释的确定性判断):
    ① 主体  我方 / 客户      —— 由 direction 直接确定
    ② 动作  报价 / 寄样 / 发资料 / 安排 —— 词表
    ③ 时间  N 天内 / 周五 / 明天 / 具体日期 —— 代码解析(**最常缺的就是这个**)
    ④ 对象  产品 / 数量 / 金额 —— 词表

齐了 → 代码直接建档(零成本、可解释);
不齐 → 把**扩好的窗口**一起交给本地 AI(比只给一句准得多)。
"""
import json
import re
from datetime import date, datetime, timedelta

from . import db

# ---------- ① 时间解析(英文 + 中文) ----------

_WEEKDAYS = {"monday": 1, "tuesday": 2, "wednesday": 3, "thursday": 4,
             "friday": 5, "saturday": 6, "sunday": 7}

_PATTERNS = [
    # 相对天
    (r"\b(?:today|tonight)\b", 0), (r"\btomorrow\b", 1),
    (r"\bday after tomorrow\b", 2),
    (r"今天|今晚", 0), (r"明天", 1), (r"后天", 2),
    # within / in N days|weeks|months
    (r"\bwithin\s+(\d{1,2})\s*(day|days)\b", None),
    (r"\bwithin\s+(\d{1,2})\s*(week|weeks)\b", None),
    (r"\bin\s+(\d{1,2})\s*(day|days)\b", None),
    (r"\bin\s+(\d{1,2})\s*(week|weeks)\b", None),
    (r"(\d{1,2})\s*天内", None), (r"(\d{1,2})\s*周内", None), (r"(\d{1,2})\s*个?月内", None),
    # 下周/下周内/月底
    (r"\bnext\s+week\b|下周", 7), (r"\bnext\s+month\b|下个?月", 30),
    (r"\bthis\s+week\b|本周", 3), (r"\bend of (?:the )?month\b|月底", 15),
    # by / on <weekday>
    (r"\b(?:by|on|before)\s+(monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b", None),
    (r"\bnext\s+(monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b", None),
    # 明确日期 2026-09-11 / 9/11 / 09/11/2026
    (r"\b(\d{4})-(\d{1,2})-(\d{1,2})\b", None),
    (r"\b(\d{1,2})/(\d{1,2})(?:/(\d{2,4}))?\b", None),
]


def _base_date(base_ts=None):
    if base_ts:
        try:
            return datetime.fromisoformat(str(base_ts).replace("T", " ")).date()
        except ValueError:
            pass
    return date.today()


def find_deadline(text, base_ts=None):
    """从文本里找“什么时候”。返回 (days, 命中的原词)。找不到 → (None, '')。

    只认**确定性**表达;含糊的(soon / asap / 尽快 / 看情况)不算时间,留给下一层或 AI。
    多个命中取**最早**的那个(承诺以最早的为准)。
    """
    if not text:
        return None, ""
    low = text.lower()
    base = _base_date(base_ts)
    cands = []

    def add(d, w):
        if d is not None and d >= 0:
            cands.append((d, w))

    # 相对天
    for pat, d in ((r"\btoday\b|\btonight\b", 0), (r"\btomorrow\b", 1),
                   (r"今天|今晚", 0), (r"明天", 1), (r"后天", 2)):
        for m in re.finditer(pat, low):
            add(d, m.group(0))
    # within / in N days|weeks
    for m in re.finditer(r"\b(?:within|in)\s+(\d{1,2})\s*(day|days|week|weeks)\b", low):
        n = int(m.group(1))
        unit = m.group(2)
        add(n * (7 if unit.startswith("week") else 1), m.group(0))
    # N 天内 / 周内 / 个月内
    for m in re.finditer(r"(\d{1,2})\s*(天|周|个?月)内", low):
        n = int(m.group(1))
        u = m.group(2)
        add(n * (7 if u == "周" else (30 if "月" in u else 1)), m.group(0))
    # 下周 / 下月 / 本周 / 月底
    for pat, d in ((r"\bnext\s+week\b|下周", 7), (r"\bnext\s+month\b|下个?月", 30),
                   (r"\bthis\s+week\b|本周", 3), (r"\bend of (?:the )?month\b|月底", 15)):
        for m in re.finditer(pat, low):
            add(d, m.group(0))
    # 星期几
    for m in re.finditer(
            r"\b(?:by|on|before|next)\s+"
            r"(monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b", low):
        wd = _WEEKDAYS.get(m.group(1))
        if wd:
            d = (wd - base.isoweekday()) % 7
            add(d if d > 0 else 7, m.group(0))
    # 明确日期:2026-09-11
    for m in re.finditer(r"\b(\d{4})-(\d{1,2})-(\d{1,2})\b", low):
        try:
            add((date(int(m.group(1)), int(m.group(2)), int(m.group(3))) - base).days,
                m.group(0))
        except ValueError:
            pass
    # 明确日期:9/11 或 09/11/2026
    for m in re.finditer(r"\b(\d{1,2})/(\d{1,2})(?:/(\d{2,4}))?\b", low):
        try:
            y = int(m.group(3)) if m.group(3) else base.year
            if y < 100:
                y += 2000
            add((date(y, int(m.group(1)), int(m.group(2))) - base).days, m.group(0))
        except ValueError:
            pass
    if not cands:
        return None, ""
    cands.sort(key=lambda x: x[0])
    return cands[0]


# ---------- ② 要素齐不齐(code 判定) ----------

_ACTION_GROUPS = ("inquiry_terms", "trade_terms", "commit_terms", "decision_terms",
                  "sourcing_terms")
_OBJECT_GROUPS = ("product_terms", "qty_terms")


def _hits(text, groups):
    low = (text or "").lower()
    out = []
    for g in groups:
        for t in db.get_group_terms(g):
            if t and t.lower() in low:
                out.append(t)
    return out


def elements(text, direction, base_ts=None):
    """返回要素齐全度。complete=True 表示"谁 + 做什么 + 什么时候"都齐了。"""
    action = _hits(text, _ACTION_GROUPS)
    obj = _hits(text, _OBJECT_GROUPS)
    days, when = find_deadline(text, base_ts)
    has_time = days is not None
    return {"subject": "out" if direction == "out" else "in",
            "action": bool(action), "action_hits": action[:4],
            "object": bool(obj), "object_hits": obj[:4],
            "days": days, "when": when,
            "complete": bool(action) and has_time}


# ---------- ③ 渐进窗口 ----------

LEVELS = [("L0", 0), ("L1", 3), ("L2", 10), ("L3", None)]


def _all_msgs(customer_id, limit=2000):
    return db.list_messages(customer_id=customer_id, limit=limit)


def window_for(customer_id, msg_id, level, msgs=None):
    """按层级取上下文窗口。L3 = 该客户前 2 天。

    msgs 可选:外部已经把该客户的消息读好了就传进来。
    ——踩过的坑:每层都重新 list_messages(limit=2000),60 条消息要 16 秒。
    """
    name, span = LEVELS[level]
    if msgs is None:
        msgs = _all_msgs(customer_id)
    idx = None
    for i, m in enumerate(msgs):
        if m["id"] == msg_id:
            idx = i
            break
    if idx is None:
        return msgs[-1:]
    if span is None:                      # L3:按时间扩到前 2 天
        try:
            end = datetime.fromisoformat(str(msgs[idx].get("ts")).replace("T", " "))
        except (ValueError, TypeError):
            end = datetime.now()
        start = end - timedelta(days=2)
        lo = idx
        while lo > 0:
            try:
                t = datetime.fromisoformat(str(msgs[lo - 1].get("ts")).replace("T", " "))
            except (ValueError, TypeError):
                break
            if t < start:
                break
            lo -= 1
        return msgs[lo:idx + 1]
    lo = max(0, idx - span)
    hi = min(len(msgs), idx + span + 1)
    return msgs[lo:hi]


def resolve(customer_id, msg_id, content, direction, ts=None):
    """渐进式解析:逐层扩窗,直到"要素齐"为止。

    返回 {level, level_name, window, elements, complete, text}
    """
    last = None
    msgs = _all_msgs(customer_id)          # 只读一次库,四层共用(性能)
    for i, (name, _) in enumerate(LEVELS):
        win = window_for(customer_id, msg_id, i, msgs=msgs)
        text = "\n".join((m.get("content") or "") for m in win)[-1800:]
        el = elements(text, direction, ts or (win[-1].get("ts") if win else None))
        last = {"level": i, "level_name": name, "window": win,
                "elements": el, "complete": el["complete"], "text": text}
        if el["complete"]:
            return last
    return last           # 仍未齐 → 交给 AI(带上这个窗口)


def stats(customer_id=None, limit=200):
    """统计:各层能解决多少(用真实数据看渐进上下文值不值)。"""
    from collections import Counter
    msgs = _all_msgs(customer_id) if customer_id else None
    rows = []
    if msgs is None:
        con = db.connect()
        try:
            rows = [dict(r) for r in con.execute(
                "SELECT id, customer_id, direction, content, ts FROM messages"
                " ORDER BY id DESC LIMIT ?", (limit,)).fetchall()]
        finally:
            con.close()
    else:
        rows = msgs[-limit:]
    lv = Counter()
    need_ai = 0
    for m in rows:
        r = resolve(m["customer_id"], m["id"], m.get("content") or "",
                    m.get("direction") or "in", m.get("ts"))
        if r["complete"]:
            lv[r["level_name"]] += 1
        else:
            need_ai += 1
    return {"tested": len(rows), "by_level": dict(lv), "need_ai": need_ai}
