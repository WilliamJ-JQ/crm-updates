# -*- coding: utf-8 -*-
"""联网更新(你控制后台,PM 端一键更新)。

后台只需要放两个静态文件:
  latest.json  {"version":"0.2.0","url":"code-0.2.0.zip","sha256":"...",
                "notes":"修了X;加了Y","date":"2026-09-20"}
  code-0.2.0.zip   代码包(见 publish_update.py 生成)

原则:
  - 只更新“代码”,绝不动 data/(客户数据)、ai-models/、python/、node/。
  - 下载后先校验 sha256,再解压到 update/pending/。
  - Windows 上由 apply-update.bat 在停机后替换并重启(运行中不能可靠自替换)。
"""
import hashlib
import json
import os
import shutil
import sys
import time
import urllib.request
import zipfile

from . import db
from . import log
from .version import APP_VERSION

# 代码包白名单(只允许这些路径进 zip/被应用;防止误伤数据与模型)
ALLOW_TOP = ("app/", "main.py", "keepalive.py", "bridge/")
DENY_BRIDGE = ("bridge/auth", "bridge/qr",
               "bridge/status.json", "bridge/pairing", "bridge/labels.json",
               "bridge/lid2pn.json", "bridge/oldest.json", "bridge/bridge.lock",
               "bridge/bridge.log", "bridge/creds")


def update_url():
    """更新后台地址:优先用设置里的;否则用随包的 update.json(发版时写死后台地址)。"""
    u = (db.get_setting("update_url", "") or "").strip()
    if u:
        return u
    p = os.path.join(db.PROJECT_DIR, "update.json")
    if os.path.exists(p):
        try:
            with open(p, encoding="utf-8") as f:
                return (json.load(f).get("update_url") or "").strip()
        except Exception as e:
            log.swallow("updater.update_url.file", e)
    return ""


def _opener():
    """按设置的「网络代理」打开请求(没配则直连;大陆自建代理时才有用)。"""
    px = (db.get_setting("bridge_proxy", "") or "").strip()
    if px:
        return urllib.request.build_opener(
            urllib.request.ProxyHandler({"http": px, "https": px}))
    return urllib.request.build_opener()


def _ver(v):
    out = []
    for p in str(v or "").strip().split("."):
        try:
            out.append(int(p))
        except ValueError:
            out.append(0)
    return tuple(out) or (0,)


def check():
    """拉后台版本清单,和当前版本比。返回 {ok, current, latest, has_update, notes, url, sha256}"""
    url = update_url()
    if not url:
        return {"ok": False, "error": "还没配置更新地址(后台 latest.json 的网址)"}
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "CustomerDesk"})
        with _opener().open(req, timeout=15) as r:
            man = json.loads(r.read().decode("utf-8"))
    except Exception as e:
        log.swallow("updater.check", e)
        return {"ok": False, "error": "连不上更新服务器:%s" % e}
    if not isinstance(man, dict):
        return {"ok": False, "error": "后台返回格式不对"}
    latest = str(man.get("version") or "")
    return {"ok": True, "current": APP_VERSION, "latest": latest,
            "has_update": _ver(latest) > _ver(APP_VERSION),
            "notes": str(man.get("notes") or ""), "date": str(man.get("date") or ""),
            "url": str(man.get("url") or ""), "sha256": str(man.get("sha256") or "").lower()}


def _sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _safe(name):
    """zip 内路径安全:必须在白名单顶层内,且不许 .. 穿越。"""
    n = name.replace("\\", "/").lstrip("/")
    if ".." in n.split("/"):
        return False
    if not n.startswith(ALLOW_TOP):
        return False
    for d in DENY_BRIDGE:
        if n.startswith(d):
            return False
    return True


def stage(man=None):
    """下载 + 校验 + 解压到 update/pending/。返回 {ok,...}"""
    if not man:
        man = check()
    if not man.get("ok"):
        return man
    if not man.get("has_update"):
        return {"ok": False, "error": "已经是最新版(%s)" % APP_VERSION}
    url = man.get("url") or ""
    if not url:
        return {"ok": False, "error": "后台清单里没有下载地址"}
    root = db.PROJECT_DIR
    updir = os.path.join(root, "update")
    zipf = os.path.join(updir, "download.zip")
    pend = os.path.join(updir, "pending")
    os.makedirs(updir, exist_ok=True)
    # ① 下载
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "CustomerDesk"})
        with _opener().open(req, timeout=180) as r, open(zipf, "wb") as f:
            shutil.copyfileobj(r, f)
    except Exception as e:
        log.swallow("updater.stage.download", e)
        return {"ok": False, "error": "下载失败:%s" % e}
    # ② 校验
    want = (man.get("sha256") or "").lower()
    got = _sha256(zipf)
    if want and got != want:
        try:
            os.remove(zipf)
        except OSError:
            pass
        return {"ok": False, "error": "校验失败(文件损坏或被改过),已丢弃"}
    # ③ 解压(只取白名单)
    if os.path.isdir(pend):
        shutil.rmtree(pend)
    os.makedirs(pend, exist_ok=True)
    n_ok = 0
    try:
        with zipfile.ZipFile(zipf) as z:
            for n in z.namelist():
                if n.endswith("/") or not _safe(n):
                    continue
                z.extract(n, pend)
                n_ok += 1
    except Exception as e:
        log.swallow("updater.stage.unzip", e)
        return {"ok": False, "error": "解压失败:%s" % e}
    if not n_ok:
        return {"ok": False, "error": "压缩包里没有可更新的代码文件"}
    ver = man.get("version") or man.get("latest") or ""
    with open(os.path.join(updir, "pending.json"), "w", encoding="utf-8") as f:
        json.dump({"version": ver, "notes": man.get("notes") or "",
                   "files": n_ok}, f, ensure_ascii=False, indent=2)
    try:
        os.remove(zipf)
    except OSError:
        pass
    return {"ok": True, "staged": True, "version": ver,
            "files": n_ok, "notes": man.get("notes") or ""}


def staged_info():
    """有没有已下载待应用的更新。"""
    root = db.PROJECT_DIR
    pend = os.path.join(root, "update", "pending")
    pj = os.path.join(root, "update", "pending.json")
    if not os.path.isdir(pend) or not os.path.exists(pj):
        return {"staged": False}
    try:
        with open(pj, encoding="utf-8") as f:
            d = json.load(f)
    except Exception:
        d = {}
    return {"staged": True, "version": d.get("version") or "", "notes": d.get("notes") or ""}


def run_apply():
    """应用已下载的更新:启动一个独立助手,退出当前进程;助手稍后重启软件——
    新代码在 main.py 启动时被应用(比 .bat 的 taskkill/xcopy 可靠得多,
    而且即使自动重启失败,用户手动重启也会生效)。"""
    info = staged_info()
    if not info.get("staged"):
        return {"ok": False, "error": "没有已下载的更新"}
    root = db.PROJECT_DIR
    import subprocess
    import threading
    py = sys.executable or "python"
    helper = ("import time,subprocess,sys;time.sleep(3);"
              "subprocess.Popen([%r,'main.py'],cwd=%r)" % (py, root))
    kw = ({"creationflags": 0x00000008} if os.name == "nt"
          else {"start_new_session": True})
    try:
        subprocess.Popen([py, "-c", helper], cwd=root, **kw)
    except Exception as e:
        log.swallow("updater.run_apply", e)
        return {"ok": False, "error": "启动重启助手失败:%s" % e}

    # 稍等片刻,让响应先回到界面,再退出当前进程(助手会重启)
    def _die():
        time.sleep(1.5)
        os._exit(0)
    threading.Thread(target=_die, daemon=True).start()
    return {"ok": True, "applying": True, "version": info.get("version")}
