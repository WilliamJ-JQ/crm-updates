# -*- coding: utf-8 -*-
"""客户画像 v2 —— 段落级代码分类 + 翻译,AI 只做兜底。

设计(按用户要求):
  1) **段落化**:把聊天按"说话人 + 时间接近"合成一段(不是单句)
  2) **代码分类**:一段话里关键词/文档分类**聚集**到某个板块才判定
     —— 不拿单个单词定生死
  3) **翻译**:分类好的段落交给(本地)模型翻译+压缩成中文画像
     —— 翻译是"窄任务",小模型比"归纳"可靠得多
  4) **兜底**:代码分不出来的段落,才整段丢给 AI 理解分类
  5) **可核实**:每节都带**原文段落**(逐字,代码可追),PM 一眼能看出对不对
  6) **人工修改**:PM 改过的节标"✏️ 人工修改",保留原稿可还原

成本原则:画像用本地模型/代码;钱花在**夜间自动回复**那一步。
"""
import json
import re
from collections import Counter

from . import db

# ---------- 画像标准(可在设置 profile_standard 里改) ----------
# 每个板块:标题 + 来自哪些"文档分类" + 来自哪些"关键词组"
DEFAULT_STANDARD = [
    {"key": "overview", "title": "客户概况",
     "cats": ["客户背景"], "groups": ["sourcing_terms"]},
    {"key": "business", "title": "业务与项目",
     "cats": ["需求详情", "产品规格", "数量与预算"], "groups": ["inquiry_terms", "qty_terms"]},
    {"key": "pricing", "title": "报价与价格口径",
     "cats": ["价格与条款", "数量与预算"], "groups": ["trade_terms"]},
    {"key": "preferences", "title": "产品偏好与标准",
     "cats": ["偏好与标准", "产品规格"], "groups": ["product_terms"]},
    {"key": "decision", "title": "决策链与关键人物",
     "cats": ["决策与角色"], "groups": ["decision_terms"]},
    {"key": "style", "title": "沟通风格与注意", "cats": [], "groups": []},
    {"key": "timeline", "title": "关键时间线",
     "cats": ["时间与交期", "物流与目的地"], "groups": ["travel_places"]},
    {"key": "status", "title": "当前状态与下一步",
     "cats": ["下一步行动", "时间与交期"], "groups": ["commit_terms"]},
    {"key": "risks", "title": "风险与顾虑",
     "cats": ["顾虑与障碍"], "groups": []},
]
MIN_SCORE = 2          # 一段话至少要有 2 个"聚集信号"才算分类成功
PARA_JOIN_MINUTES = 45  # 同一个人 45 分钟内的连续消息合成一段


def _standard():
    raw = db.get_setting("profile_standard", "")
    if raw:
        try:
            data = json.loads(raw)
            if isinstance(data, list) and data:
                return data
        except (ValueError, TypeError):
            pass
    return DEFAULT_STANDARD


def section_titles():
    return [(s["key"], s["title"]) for s in _standard()]


# ---------- 1) 段落化 ----------

def build_paragraphs(customer_id):
    """把消息合成段落:同一说话人 + 时间接近 + 不跨天。"""
    msgs = db.list_messages(customer_id=customer_id, limit=1000)
    paras = []
    cur = None
    for m in msgs:
        content = (m.get("content") or "").strip()
        if not content:
            continue
        day = (m.get("ts") or "")[:10]
        same = (cur and cur["direction"] == m["direction"] and cur["day"] == day)
        if same:
            cur["parts"].append(content)
            cur["ts_end"] = m.get("ts")
        else:
            if cur:
                paras.append(cur)
            cur = {"direction": m["direction"], "day": day,
                   "ts": m.get("ts"), "ts_end": m.get("ts"), "parts": [content]}
    if cur:
        paras.append(cur)
    for i, p in enumerate(paras):
        p["idx"] = i
        p["text"] = " ".join(p["parts"]).strip()
    return paras


# ---------- 2) 代码分类(段落级聚集) ----------

def _cat_map():
    m = {}
    for s in _standard():
        for c in s.get("cats") or []:
            m.setdefault(c, []).append(s["key"])
    return m


def classify_paragraphs(customer_id, paras):
    """给每段打板块标签。返回 (已分类列表, 未分类列表)。

    信号来源两处,都要求"聚集"(≥MIN_SCORE):
      a) 该段命中的**文档分类**(文档本身就是代码逐句分类出来的)
      b) 该段命中的**关键词组**(按整套词表命中数)
    """
    from . import rules as _rules
    docs = db.list_docs(customer_id=customer_id, limit=800)
    cats = _cat_map()
    std = _standard()
    # 文档 → 段落:用引用原文定位(逐字包含)
    para_cats = {p["idx"]: Counter() for p in paras}
    for d in docs:
        q = (d.get("quote") or "").strip()
        if len(q) < 6:
            continue
        for p in paras:
            if q in p["text"]:
                for key in cats.get(d.get("category") or "", []):
                    para_cats[p["idx"]][key] += 1
    # 关键词组命中
    group_keys = set()
    for s in std:
        group_keys.update(s.get("groups") or [])
    terms = {g: db.get_group_terms(g) for g in group_keys}

    done, todo = [], []
    for p in paras:
        low = p["text"].lower()
        score = Counter()
        for key, n in para_cats[p["idx"]].items():
            score[key] += n * 2      # 文档信号权重更高
        for s in std:
            for g in s.get("groups") or []:
                hits = sum(1 for t in terms.get(g, []) if _rules.match_term(low, t))
                if hits:
                    score[s["key"]] += hits
        if score:
            best, n = score.most_common(1)[0]
            if n >= MIN_SCORE:
                p["section"] = best
                p["by"] = "code"
                done.append(p)
                continue
        todo.append(p)
    return done, todo


# ---------- 3) AI 兜底分类 + 翻译 ----------

_CLS_SYS = (
    "你是外贸客户资料分类助手。给你几段客户聊天,请把每段归到一个板块。\n"
    "板块只能从这些 key 里选:\n{sections}\n"
    "无法归类的用 key=\"none\"。只输出 JSON:"
    '{"items":[{"idx":0,"section":"business"}]}'
)

_TR_SYS = (
    "你是翻译助手。把下面这节外贸聊天原文翻译成**简体中文**,用于客户画像。\n"
    "要求:\n"
    "1) 忠实翻译,不添加原文没有的信息;数字、型号、人名、品牌保留原样;\n"
    "2) 多段合并成 2-4 句通顺的概括,不要逐句罗列;\n"
    "3) 语气中立的商务书面语。\n"
    '只输出 JSON:{"zh":"<中文概括>"}'
)


def _call_ai(messages):
    from . import ai as ai_mod
    return ai_mod._call_api(messages)


def _cls_sys_msg():
    """分类提示词的 system 消息。

    【坑】提示词里带 JSON 示例(花括号)—— 不能用 str.format,
    否则示例里的 {"items":...} 会被当成占位符 → KeyError → 整个画像 500。
    统一用 replace 填槽。
    """
    sections_txt = "\n".join("- %s(%s)" % (s["key"], s["title"]) for s in _standard())
    return _CLS_SYS.replace("{sections}", sections_txt)


def _classify_chunk(chunk, out, depth=0):
    """给一小批段落分类。模型偶尔会返回空/摆烂 → 重试一次;还不行就把这批拆半再试。"""
    if not chunk:
        return
    listing = "\n".join("#%d %s" % (p["idx"], p["text"][:300]) for p in chunk)
    items = []
    for _ in range(2):
        try:
            res = _call_ai([{"role": "system", "content": _cls_sys_msg()},
                            {"role": "user", "content": listing}])
        except Exception:
            res = None
        items = (res or {}).get("items") or []
        if items:
            break
    got = 0
    for it in items:
        try:
            idx = int(it.get("idx"))
        except (TypeError, ValueError):
            continue
        raw_sec = str(it.get("section") or "").strip()
        if not raw_sec or raw_sec.lower() == "none":
            continue
        out[idx] = _norm_section(raw_sec) or raw_sec   # 容忍模型回中文标题
        got += 1
    if got == 0 and depth < 1 and len(chunk) > 6:
        mid = len(chunk) // 2
        _classify_chunk(chunk[:mid], out, depth + 1)
        _classify_chunk(chunk[mid:], out, depth + 1)


def ai_classify(todo):
    """把代码分不出来的段落交给 AI 分类。返回 {idx: section}。"""
    if not todo:
        return {}
    out = {}
    for i in range(0, len(todo), 25):
        _classify_chunk(todo[i:i + 25], out)
    return out


def _norm_section(v):
    """把模型给的板块名归一化成标准 key(容忍大小写/空格/它自己编的中文标题)。"""
    s = str(v or "").strip().lower()
    if not s:
        return ""
    for it in _standard():
        if s in (str(it["key"]).lower(), str(it.get("title") or "").strip().lower()):
            return it["key"]
    return ""


def _pick_translation(res, key=""):
    """从模型返回里挑出译文。

    【坑】本地小模型会把**键也一并翻译**(实测返回过 {"接待与安排": "..."}),
    原来按键取值 → 对不上 → 译文被静默丢弃、页面显示英文原文。
    所以:先认 key/中文标题,再认常见包装字段,最后“只回了一个字符串就认它是译文”。
    """
    if res is None:
        return ""
    if isinstance(res, str):
        return res.strip()[:400]
    if isinstance(res, list):
        res = res[0] if res and isinstance(res[0], dict) else {}
    if not isinstance(res, dict):
        return ""
    if key:
        want = _norm_section(key)
        for k, v in res.items():
            if isinstance(v, str) and v.strip() and _norm_section(k) == want:
                return v.strip()[:400]
    for name in ("zh", "translation", "text", "result", "中文", "内容"):
        v = res.get(name)
        if isinstance(v, str) and v.strip():
            return v.strip()[:400]
    inner = res.get("sections")
    if isinstance(inner, dict):
        got = _pick_translation(inner, key)
        if got:
            return got
    vals = [v for v in res.values() if isinstance(v, str) and v.strip()]
    if len(vals) == 1:
        return vals[0].strip()[:400]      # 一次只问一节 → 就这一个字符串
    return ""


def ai_translate(by_section):
    """把各板块的原文段落翻译+压缩成中文。返回 {key: 中文文本}。

    **一次只翻一节**:小载荷时本地模型才稳(大载荷时它会自己编中文小节名)
    而且一节一call 时“唯一那个字符串”就是答案,不用猜键。
    """
    out = {}
    for key, paras in (by_section or {}).items():
        if not paras:
            continue
        text = "\n".join("- " + p["text"][:400] for p in paras[:12])[:1600]
        try:
            res = _call_ai([{"role": "system", "content": _TR_SYS},
                            {"role": "user", "content": text}])
        except Exception:
            continue
        zh = _pick_translation(res, key)
        if zh:
            out[key] = zh
    return out


# ---------- 4) 组装生成 ----------

def _blank():
    return {s["key"]: {"text": "", "evidence": [], "verified": True,
                       "source": "code", "edited": False}
            for s in _standard()}


def generate(customer_id, use_ai=True):
    """生成画像。返回 {status, sections, stats}。"""
    if not db.get_customer(customer_id):
        return {"status": "no-customer"}
    paras = build_paragraphs(customer_id)
    if not paras:
        return {"status": "no-material"}

    done, todo = classify_paragraphs(customer_id, paras)
    ai_todo = {}
    classified = {p["idx"]: p["section"] for p in done}

    from . import ai as ai_mod
    ai_on = use_ai and ai_mod.enabled()
    if ai_on and todo:
        # AI 只是“兜底”:它出错也必须能出画像(降级为纯代码版),不能整单失败
        try:
            ai_todo = ai_classify(todo)
        except Exception:
            ai_todo = {}
        for idx, sec in ai_todo.items():
            classified[idx] = sec
        for p in todo:
            if p["idx"] in ai_todo:
                p["section"] = ai_todo[p["idx"]]
                p["by"] = "ai"

    by_section = {}
    for p in paras:
        key = classified.get(p["idx"])
        if key:
            by_section.setdefault(key, []).append(p)

    sections = _blank()
    # 原文段落 = 逐字依据(代码可追)
    for key, plist in by_section.items():
        if key not in sections:
            continue
        sections[key]["evidence"] = [p["text"][:400] for p in plist[:4]]
        sections[key]["verified"] = True
        sections[key]["source"] = ("ai" if any(p.get("by") == "ai" for p in plist)
                                   else "code")

    try:
        translated = ai_translate(by_section) if ai_on else {}
    except Exception:
        translated = {}
    for key, sec in sections.items():
        if translated.get(key):
            sec["text"] = translated[key][:400]
            sec["source"] = "ai"
        elif by_section.get(key):
            # 没有 AI:直接给原文段落(不翻译,但保证可读可改)
            sec["text"] = "\n".join("- " + p["text"][:180] for p in by_section[key][:3])
            sec["source"] = "code"
            sec["untranslated"] = True

    stats = {"paragraphs": len(paras), "code_classified": len(done),
             "ai_classified": len(ai_todo), "unclassified": len(todo) - len(ai_todo),
             "translated": len(translated)}
    db.save_profile_doc(customer_id, sections,
                        model=(db.get_setting("ai_model", "") if translated else "code"))
    return {"status": "ok", "sections": sections, "stats": stats}


# ---------- 5) 人工修改(保留原稿 + 溯源标记) ----------

def edit_section(customer_id, key, text, editor="pm"):
    """人工修改某一节:保留原稿,标 edited=True。"""
    p = db.get_profile_doc(customer_id)
    if not p:
        return {"status": "no-profile"}
    secs = p.get("sections") or {}
    sec = secs.get(key)
    if not sec:
        return {"status": "no-section"}
    if not sec.get("edited"):
        sec["original_text"] = sec.get("text", "")
    sec["text"] = (text or "")[:1500]
    sec["edited"] = True
    sec["edited_by"] = editor
    sec["edited_at"] = db.now_iso()
    db.save_profile_doc(customer_id, secs, model=p.get("model") or "")
    return {"status": "ok", "section": sec}


def revert_section(customer_id, key):
    """还原成模型/代码原稿。"""
    p = db.get_profile_doc(customer_id)
    if not p:
        return {"status": "no-profile"}
    secs = p.get("sections") or {}
    sec = secs.get(key)
    if not sec:
        return {"status": "no-section"}
    if sec.get("original_text") is not None:
        sec["text"] = sec.pop("original_text")
    sec["edited"] = False
    sec.pop("edited_by", None)
    db.save_profile_doc(customer_id, secs, model=p.get("model") or "")
    return {"status": "ok", "section": sec}


def get(customer_id):
    return db.get_profile_doc(customer_id)
