# -*- coding: utf-8 -*-
"""精炼客户档案 —— 用 AI 把聊天"归纳"成一份关键信息档案。

为什么需要它(和 customer_docs 的分工):
  - customer_docs:按句抽取,一条一句原话(量多,适合追溯)
  - customer_brief:归纳成档 —— 关键时间节点 / 报价与条款 / 偏好与标准 /
    决策链 / 顾虑与障碍 / 下一步行动(量少,适合一眼看懂)

关键:AI 只负责"理解和归纳",不负责"编"。所有输出都要过代码硬闸门:
  1) 结构:分类必须在固定名单内;text/quote 缺一不可
  2) 逐字引用:quote 必须能在该客户的原始材料里逐字找到(对不上 → 丢弃)
  3) 条数上限:每类最多 6 条,防止"什么都往里塞"

AI 不可用时,自动退回"代码归纳"(把已有文档按分类归并),保证永远有东西看。
"""
import json

from . import db, guard

# 档案分区(key, 中文名, 说明)
SECTIONS = [
    ("timeline", "关键时间节点", "什么时候要什么(交期/行程/截止)"),
    ("quotes", "报价与条款", "报了什么价、什么条件、是否已发"),
    ("preferences", "偏好与标准", "材质/规格/风格/认证等要求"),
    ("decisions", "决策链", "谁拍板、预算谁批、有几个角色"),
    ("concerns", "顾虑与障碍", "担心什么、卡在哪"),
    ("next", "下一步行动", "接下来该谁做什么"),
]
SECTION_KEYS = [k for k, _, _ in SECTIONS]
MAX_PER_SECTION = 6

_SYS = (
    "你是外贸客户资料分析师。根据【材料】把客户情况归纳成一份结构化档案。\n"
    "分区只能从这些 key 里选:\n"
    + "\n".join("- %s(%s):%s" % (k, label, desc) for k, label, desc in SECTIONS)
    + "\n规则:\n"
    "1) 每条必须给 quote = 【材料】里的原文原句(**逐字复制**,不许改写、不许翻译);\n"
    "2) 材料里没提到的一律不要写;禁止推测、禁止补充常识;\n"
    "3) text 尽量精炼(<=40字),用中文写;数字/型号保留原文;\n"
    "4) 每类最多 4 条,宁少勿多;没有就留空数组。\n"
    '只输出 JSON: {"items":[{"section":"timeline","text":"","quote":""}]}'
)


def _corpus(customer_id):
    """该客户的全部原始材料(用于逐字校验 + 喂给 AI)。"""
    docs = db.list_docs(customer_id=customer_id, limit=400)
    msgs = db.list_messages(customer_id=customer_id, limit=400)
    parts = []
    for d in docs:
        parts.append("[%s] %s" % (d.get("category", ""), d.get("title") or ""))
        if d.get("quote"):
            parts.append(d["quote"])
    for m in msgs:
        parts.append(m.get("content") or "")
    return docs, msgs, "\n".join(parts)


def _material(docs, msgs, limit=6000):
    """喂给 AI 的材料:优先用已提炼的文档(带分类),再补最近对话。"""
    lines = []
    for d in docs[:120]:
        lines.append("[%s] %s" % (d.get("category", ""), d.get("title") or ""))
        if d.get("quote"):
            lines.append("   原话: %s" % d["quote"])
    lines.append("--- 最近对话 ---")
    for m in msgs[-120:]:
        who = "客户" if m.get("direction") == "in" else "我方"
        lines.append("%s: %s" % (who, (m.get("content") or "")[:300]))
    return "\n".join(lines)[-limit:]


def code_fallback(customer_id):
    """没有 AI 时的退路:把已有文档按分区归并(纯代码,零 token)。"""
    docs = db.list_docs(customer_id=customer_id, limit=400)
    mapping = {
        "时间与交期": "timeline", "物流与目的地": "timeline",
        "价格与条款": "quotes", "数量与预算": "quotes",
        "产品规格": "preferences", "偏好与标准": "preferences",
        "决策与角色": "decisions",
        "顾虑与障碍": "concerns",
        "下一步行动": "next",
    }
    out = {k: [] for k in SECTION_KEYS}
    for d in docs:
        key = mapping.get(d.get("category") or "")
        if not key:
            continue
        if len(out[key]) >= MAX_PER_SECTION:
            continue
        out[key].append({"text": d.get("title") or "", "quote": d.get("quote") or "",
                         "src": "code"})
    return out


def generate(customer_id, force=False):
    """生成精炼档案。返回 {status, sections, stats}。"""
    customer = db.get_customer(customer_id)
    if not customer:
        return {"status": "no-customer"}
    docs, msgs, corpus = _corpus(customer_id)
    if not corpus.strip():
        return {"status": "no-material"}

    from . import ai as ai_mod
    if not ai_mod.enabled():
        sections = code_fallback(customer_id)
        n = sum(len(v) for v in sections.values())
        db.save_brief(customer_id, sections, model="code", item_count=n)
        return {"status": "code-only", "sections": sections,
                "stats": {"kept": n, "dropped": 0},
                "hint": "未开启 AI:这是代码归纳。开启 AI 后会归纳得更好。"}

    if ai_mod.usage()["left"] <= 0:
        return {"status": "capped", "sections": code_fallback(customer_id),
                "hint": "今日 AI 额度已用完,先用代码归纳。"}

    try:
        out = ai_mod._call_api([
            {"role": "system", "content": _SYS},
            {"role": "user", "content": "【材料】\n" + _material(docs, msgs)},
        ])
    except Exception as exc:
        db.add_ai_log(customer_id, "brief", "", "", "error", str(exc)[:200])
        return {"status": "error", "detail": str(exc)[:200],
                "sections": code_fallback(customer_id)}

    sections = {k: [] for k in SECTION_KEYS}
    kept = dropped = 0
    items = (out or {}).get("items") or []
    for it in (items if isinstance(items, list) else [])[:60]:
        it = it or {}
        key = str(it.get("section") or "").strip()
        text = str(it.get("text") or "").strip()
        quote = str(it.get("quote") or "").strip()
        if key not in SECTION_KEYS or not text or not quote:
            dropped += 1
            db.add_ai_log(customer_id, "brief", text[:40], quote, "rejected",
                          "结构不合规(分区/摘要/引用必须齐全)")
            continue
        if not guard.quote_in(quote, corpus, min_len=6):
            dropped += 1
            db.add_ai_log(customer_id, "brief", text[:40], quote, "rejected",
                          "引用在原始材料里找不到(疑似编造)")
            continue
        if len(sections[key]) >= MAX_PER_SECTION:
            dropped += 1
            continue
        sections[key].append({"text": text[:120], "quote": quote[:300], "src": "ai"})
        kept += 1
        db.add_ai_log(customer_id, "brief", text[:40], quote, "ok", "")

    if kept == 0:
        sections = code_fallback(customer_id)
        kept = sum(len(v) for v in sections.values())
        db.save_brief(customer_id, sections, model="code", item_count=kept)
        return {"status": "ai-empty-code-fallback", "sections": sections,
                "stats": {"kept": kept, "dropped": dropped},
                "hint": "AI 没给出可核实的条目,已用代码归纳兜底。"}

    db.save_brief(customer_id, sections,
                  model=db.get_setting("ai_model", "deepseek-chat"),
                  item_count=kept)
    return {"status": "ok", "sections": sections,
            "stats": {"kept": kept, "dropped": dropped}}


def get(customer_id):
    """读取已保存的精炼档案;没有就返回 None。"""
    return db.get_brief(customer_id)
