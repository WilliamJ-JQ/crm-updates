# -*- coding: utf-8 -*-
"""客户文档库 —— 把聊天里"有价值的信息"提炼成结构化文档。

和"聊天流水"的区别:
  - 聊天流水 = 原样存所有消息(消息页,给别人看上下文);
  - 客户文档 = 提炼后的**结论**(如"客户要 500㎡ 木地板,发迪拜,6 月前交货"),
    每条都带**原文引用**,能追溯到是哪条消息说的。

两个通道:
  1) 代码通道(零 token,默认开):规则匹配句子,命中即建档,原句逐字保留;
  2) AI 通道(默认关,手动点):代码认不出的复杂信息交给 AI 提炼,
     再过 guard 硬校验(逐字引用校验),不通过的**直接丢弃,不写库**。

安全:这里只写本地数据库,不接触任何外发通道。
"""
import re

from . import db, guard

# 句子切分:只认句末标点 + 换行。
# 注意:不要按 ASCII 逗号切 —— 英文逗号在句内,会切出 "I want a large" 这种碎句。
_SPLIT = re.compile(r"(?<=[.!?;。！？；，、])|\n+")
MAX_SENT = 400

# 代码通道:分类 → 命中正则(中英双语)。命中即把**整句**建档,原文逐字保留。
# 顺序即优先级:越靠前越优先(一句最多归一类)。
# "特定角色/顾虑"排在"数量/产品"前面,否则 "Our boss will approve the budget"
# 会被 budget 抢去"数量与预算",而它其实是决策信号。
RULES = [
    ("决策与角色",
     r"(?i)(\b(my boss|our (boss|manager|ceo|director|client)|decision|approve|"
     r"management|partner|architect|designer|contractor|consultant)\b)"
     r"|(老板|领导|决策|审批|合伙人|设计师|施工方|甲方)"),
    ("顾虑与障碍",
     r"(?i)(\b(concern|issue|problem|worry|risk|delay|complaint|too expensive)\b)"
     r"|(问题|担心|顾虑|风险|延期|太贵|贵了)"),
    ("时间与交期",
     r"(?i)\b(by|before|until|deadline|eta|lead\s?time|ship(ping)?\s?(date|deadline)|"
     r"next\s+(week|month)|this\s+(week|month)|asap|urgent)\b|(交期|交货|工期|月底|下个?月|尽快|赶工)"),
    ("物流与目的地",
     r"(?i)\b(fob|cif|cfr|ddp|exw|port|ship\s?to|deliver(y)?\s?to|destination|"
     r"dubai|riyadh|jeddah|doha|kuwait|manila|jakarta|bangkok|london|sydney|nairobi)\b"
     r"|(海运|目的港|发到|运到|清关|到港)"),
    ("价格与条款",
     r"(?i)(\b(price|quote|quotation|discount|payment|deposit|t/?t|l/?c|invoice|"
     r"proforma|pi)\b)|(报价|价格|付款|定金|折扣|账期|发票)"),
    ("数量与预算",
     r"(?i)(\d[\d,\.]*\s*(sqm|sq\.?\s?m|m2|square\s?met|cbm|pcs|pieces|sets?|units?|containers?|20ft|40ft|40hq))"
     r"|(\b(quantity|budget|target price|total amount)\b)|(预算|数量|总价|一共|多少钱|平米|平方|套|件|个柜)"),
    ("产品规格",
     r"(?i)(\b(size|dimension|thickness|grade|series|model|color|finish|material|"
     r"ceramic|porcelain|marble|granite|timber|wood|spc|laminate|wpc|aluminium|"
     r"glass|mosquito|tile|skirting)\b)|(尺寸|规格|厚度|材质|颜色|型号|系列|陶瓷|"
     r"大理石|花岗岩|木地板|铝|玻璃|瓷砖|踢脚线)"),
    ("偏好与标准",
     r"(?i)(\b(i (prefer|like|want)|we (prefer|like|want)|must be|"
     r"requirement|standard|certificat(e|ion)|saso|iso|fireproof|waterproof)\b)"
     r"|(要求|标准|认证|证书|偏好|级别|防火|防水)"),
    ("下一步行动",
     r"(?i)(\b(please (send|provide|quote|confirm|advise|share)|send me|let me know|"
     r"waiting for|get back|follow up)\b)|(请发|麻烦|发我|确认一下|等我|回头|接下来|下步)"),
    ("客户背景",
     r"(?i)(\b(we are|i am|our company|we specialize|we import|we export|"
     r"distributor|wholesaler|retailer|importer)\b)|(我们公司|我是|我们做|我们专门|"
     r"经销商|批发|连锁)"),
    ("需求详情",
     r"(?i)\b(project|villa|apartment|hotel|resort|mall|office|building|hospital|"
     r"school|tower|compound)\b|(项目|别墅|公寓|酒店|度假|商场|写字楼|大楼|医院|学校)"),
]

# 分类优先级(越靠前越优先;一句最多归一类)
# 决策/顾虑排前面:"Our boss will approve the budget" 是决策信号,不该被 budget 抢走。
# 数量排"时间/物流"前面:"We need 500 sqm ... in Dubai" 的数量信息比目的地更有用。
PRIORITY = ["决策与角色", "顾虑与障碍", "数量与预算", "产品规格", "时间与交期",
            "物流与目的地", "价格与条款", "偏好与标准", "下一步行动",
            "客户背景", "需求详情"]
_RX = {cat: re.compile(pat) for cat, pat in RULES}
_COMPILED = [(cat, _RX[cat]) for cat in PRIORITY if cat in _RX]

AI_SYS = (
    "你是外贸客户资料整理员。从【客户对话】提炼\"高价值信息\",写成结构化条目。\n"
    "类别只能从这些里选:\n" + "/".join(db.DOC_CATEGORIES) + "\n"
    "规则:\n"
    "1) 只提炼对业务有用的信息(需求/规格/数量/预算/交期/物流/条款/角色/偏好/顾虑/下一步/背景);\n"
    "2) 每条必须给 quote = 对话里的原文原句(**逐字复制**,不许改写、不许翻译);\n"
    "3) 对话里没提到的**一律不要写**,禁止推测、禁止补充;\n"
    "4) title 不超过 40 字,content 一句话说清;\n"
    "5) 宁少勿多:不确定就跳过。\n"
    '只输出 JSON: {"items":[{"category":"","title":"","content":"","quote":""}]}'
)


def _sentences(text):
    out = []
    for part in _SPLIT.split(text or ""):
        s = (part or "").strip()
        if len(s) >= 6:
            out.append(s[:MAX_SENT])
    return out


def _title_of(sent):
    t = " ".join(sent.split()).strip(" ,，、。；;.!！")
    return t if len(t) <= 60 else t[:57] + "..."


def extract_code(content, direction="in", limit=6):
    """代码通道:把一条消息里命中的句子抽成文档条目(不调 AI,零 token)。

    一句最多归一个分类(取第一个命中的),避免同一句刷出多条。
    """
    out = []
    for sent in _sentences(content)[:limit]:
        for cat, rx in _COMPILED:
            if rx.search(sent):
                out.append({
                    "category": cat,
                    "title": _title_of(sent),
                    "content": sent,
                    "quote": sent,
                    "source": "code:" + ("in" if direction == "in" else "out"),
                })
                break
    return out


def extract_code_to_db(customer_id, content, direction="in", msg_id=None):
    """提炼一条消息并写库,返回新建条数。"""
    n = 0
    for item in extract_code(content, direction):
        # 闸门:引用必须逐字存在于原文(自检,防止规则本身出错)
        if not guard.quote_in(item["quote"], content, min_len=6):
            continue
        did = db.add_doc(customer_id, item["category"], item["title"],
                         item["content"], quote=item["quote"],
                         source=item["source"], msg_id=msg_id)
        if did:
            n += 1
    return n


def extract_ai(customer_id, limit_msgs=40):
    """AI 通道:代码认不出的复杂信息交给 AI 提炼,再逐条过硬校验。"""
    from . import ai as ai_mod
    if db.get_setting("docs_ai_auto", "0") != "1":
        return {"status": "off"}
    if not ai_mod.enabled():
        db.add_ai_log(customer_id, "doc", "", "", "disabled", "AI 未开启或未配密钥")
        return {"status": "disabled"}
    if ai_mod.usage()["left"] <= 0:
        db.add_ai_log(customer_id, "doc", "", "", "capped", "已达每日上限")
        return {"status": "capped"}
    msgs = db.list_messages(customer_id=customer_id, limit=limit_msgs)
    if not msgs:
        return {"status": "no-messages"}
    plain = "\n".join((m["content"] or "") for m in msgs)
    try:
        out = ai_mod._call_api([
            {"role": "system", "content": AI_SYS},
            {"role": "user", "content": "【客户对话】\n" + plain[-6000:]},
        ])
    except Exception as exc:
        db.add_ai_log(customer_id, "doc", "", "", "error", str(exc)[:200])
        return {"status": "error", "detail": str(exc)[:200]}

    accepted = rejected = 0
    items = (out or {}).get("items") or []
    for it in (items if isinstance(items, list) else [])[:20]:
        it = it or {}
        cat = str(it.get("category") or "").strip()
        title = str(it.get("title") or "").strip()[:80]
        content = str(it.get("content") or "").strip()
        quote = str(it.get("quote") or "").strip()
        if cat not in db.DOC_CATEGORIES or not title or not content or not quote:
            rejected += 1
            db.add_ai_log(customer_id, "doc", title or cat, quote, "rejected",
                          "结构不合规(分类/标题/内容/引用必须齐全)")
            continue
        if not guard.quote_in(quote, plain, min_len=6):
            rejected += 1
            db.add_ai_log(customer_id, "doc", title, quote, "rejected",
                          "引用在原文里找不到(疑似编造)")
            continue
        did = db.add_doc(customer_id, cat, title, content, quote=quote,
                         source="ai", dedupe=True)
        if did:
            accepted += 1
            db.add_ai_log(customer_id, "doc", title, quote, "ok", "")
        else:
            rejected += 1
            db.add_ai_log(customer_id, "doc", title, quote, "rejected", "重复条目")
    return {"status": "ok", "accepted": accepted, "rejected": rejected,
            "usage": ai_mod.usage()}
