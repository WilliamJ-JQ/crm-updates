# -*- coding: utf-8 -*-
"""AI 增强层 —— 代码认不出时,调 DeepSeek 补齐建档字段。

强约束(全部代码级,不靠提示词自觉):
  - 枚举锁死:身份/分级/分类只能从固定名单选
  - 引用锁死:每个结论必须带逐字原文引用,对不上就拒
  - 知识库锁死:分级标准/身份定义/术语从知识库读给 AI
  - 硬信息锁死:价格/交期/认证只从知识库取,AI 不许生成
  - 每日上限:默认 15 条待办字段,超了不调
  - 全部落日志:成功/被拒/unknown 都记,半月导出审计

成本原则:代码能认的绝不调 AI;只在"认不出"时按需调用。
"""
import json
import os
import re
import subprocess
import time
import urllib.request

from . import db
from . import log, guard

# 任务 → 允许的枚举(AI 只许从这里面选)
AI_ENUMS = {
    "identity": ["业主", "建筑商", "中介", "设计师", "采购商", "其他"],
    "followup": ["等待客户确认", "挑选款式", "待我出方案/搭配",
                 "待我报价", "待客户付款", "待发货", "其他"],
    "grade": ["A", "B", "C"],
}
# 任务 → 客户档案字段名
FIELD_MAP = {"identity": "identity", "followup": "followup_category",
             "grade": "grade"}


def enabled():
    """AI 是否可用。

    注意:本地模型(如 llama.cpp 的 127.0.0.1:8080)**不需要密钥**,
    所以只要开关开了、要么有 key 要么指向本地地址,就算可用。
    (之前只认 key,导致本地模型被误判为"未开启"而走代码兑底。)
    """
    if db.get_setting("ai_enabled", "0") != "1":
        return False
    return bool(db.get_setting("ai_api_key", "")) or bool(local_base())


def usage():
    """今日 AI 用量:{used, limit, left}。used=今天实际处理过的字段条数。"""
    try:
        limit = int(db.get_setting("ai_daily_limit", "15") or 15)
    except ValueError:
        limit = 15
    used = db.ai_log_today_count()
    return {"used": used, "limit": limit, "left": max(0, limit - used)}


# ---------- 本地模型:内置自启(不用手动开) ----------

def local_base():
    """返回本地模型地址;不是本地配置则返回 ''。"""
    base = (db.get_setting("ai_base_url", "") or "").strip()
    if "127.0.0.1:" in base or "localhost:" in base:
        return base.rstrip("/")
    return ""


def local_port():
    base = local_base()
    m = re.search(r":(\d{2,5})", base or "")
    return int(m.group(1)) if m else 8080


def local_running(timeout=2):
    """本地模型是否已在跑(探测 /v1/models)。"""
    base = local_base()
    if not base:
        return None
    try:
        with urllib.request.urlopen(base + "/models", timeout=timeout):
            return True
    except Exception:
        return False


def local_command():
    """本地模型启动命令。优先随包(llama-server + 模型在软件目录);可用 ai_local_cmd 覆盖。"""
    custom = (db.get_setting("ai_local_cmd", "") or "").strip()
    if custom:
        return custom
    home = os.path.expanduser("~")
    root = getattr(db, "PROJECT_DIR", "") or os.path.dirname(
        os.path.dirname(os.path.abspath(__file__)))
    exe = "llama-server.exe" if os.name == "nt" else "llama-server"

    def _find_model(mdir):
        if not os.path.isdir(mdir):
            return ""
        for f in sorted(os.listdir(mdir)):
            if f.endswith(".gguf") and "00001-of" not in f and "00002" not in f:
                return os.path.join(mdir, f)
        for f in sorted(os.listdir(mdir)):
            if f.endswith(".gguf"):
                return os.path.join(mdir, f)
        return ""

    # 候选服务端 → (server, model_dir):先随包,再回退 WSL/Linux 路径
    pairs = [
        (os.path.join(root, "ai-llama", exe), os.path.join(root, "ai-models")),
        (os.path.join(home, ".local/llama/llama-b10889", "llama-server"),
         os.path.join(home, "models")),
    ]
    base_dir = os.path.join(home, ".local/llama")
    if os.path.isdir(base_dir):
        for d in sorted(os.listdir(base_dir), reverse=True):
            p = os.path.join(base_dir, d, "llama-server")
            if os.path.exists(p):
                pairs.append((p, os.path.join(home, "models")))
    server = model = ""
    for srv, mdir in pairs:
        if os.path.exists(srv):
            m = _find_model(mdir)
            if m:
                server, model = srv, m
                break
    if not (server and model):
        return ""
    return ('"%s" -m "%s" --host 127.0.0.1 --port %d -c 8192 -t 10 --no-webui -ngl 0'
            % (server, model, local_port()))


def ensure_local(wait=120, force=False):
    """确保本地模型在跑(内置自启)。返回 {ok, started, detail}。"""
    if db.get_setting("ai_autostart", "1") != "1" and not force:
        return {"ok": True, "detail": "autostart off"}
    if not local_base():
        return {"ok": True, "detail": "not local"}
    if local_running():
        return {"ok": True, "started": False}
    cmd = local_command()
    if not cmd:
        return {"ok": False, "detail": "找不到 llama-server 或模型文件"}
    logfile = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                           "..", "data", "local-ai.log")
    logfile = os.path.abspath(logfile)
    try:
        with open(logfile, "ab") as f:
            _kw = ({"creationflags": 0x00000008} if os.name == "nt"
                   else {"start_new_session": True})
            subprocess.Popen(cmd, shell=True, stdout=f, stderr=f, **_kw)
    except Exception as exc:
        return {"ok": False, "detail": str(exc)[:200]}
    for _ in range(max(1, int(wait / 3))):
        time.sleep(3)
        if local_running():
            return {"ok": True, "started": True}
    return {"ok": False, "detail": "启动超时,看 data/local-ai.log"}


def translate_quotes(pairs):
    """批量把原话翻成中文(一次调用搞定多条,省时间也省钱)。

    pairs: {id: 原文} -> {id: 中文}
    翻译是“窄任务”,小模型比归纳可靠得多。
    """
    if not pairs:
        return {}
    sys_msg = ("你是翻译助手。把每条外贸聊天原文翻译成简体中文:忠实翻译,不添加原文没有的信息,"
               "数字/型号/品牌/人名保留原样,语气用中立的商务书面语。"
               '只输出 JSON:{"items":[{"id":"<原样id>","zh":"<中文>"}]}')
    user = json.dumps([{"id": k, "text": v} for k, v in pairs.items()],
                      ensure_ascii=False)
    try:
        out = _call_api([{"role": "system", "content": sys_msg},
                         {"role": "user", "content": user}])
    except Exception:
        return {}
    res = {}
    items = out
    if isinstance(out, dict):
        items = out.get("items") or out.get("sections") or out
    if isinstance(items, dict):
        # 形如 {"40": "中文"}
        for k, v in items.items():
            txt = str(v or "").strip()
            if str(k).strip() and txt:
                res[str(k).strip()] = txt
    elif isinstance(items, list):
        # 形如 [{"id":"40","zh":"..."}] 或 [{"key":..,"text":..}]
        for it in items:
            if not isinstance(it, dict):
                continue
            k = str(it.get("id") or it.get("key") or "").strip()
            zh = str(it.get("zh") or it.get("text") or "").strip()
            if k and zh:
                res[k] = zh
    return res


def _timeout():
    """请求超时(秒)。本地模型跑在 CPU 上,一份档案可能要几分钟
    —— 所以默认 60 秒对云端够用,本地要调到 600。"""
    try:
        return max(20, int(db.get_setting("ai_timeout", "60") or 60))
    except (TypeError, ValueError):
        return 60


def _call_api(messages, allow_cloud=False):
    """调用 OpenAI 兼容的 chat/completions。

    【成本护栏】默认**只允许本地模型**。要把请求发到云端(api.deepseek.com 等),
    必须同时满足:① 设置 cloud_ai_enabled=1 ② 调用方显式 allow_cloud=True。
    这样除“夜间回复”以外的任何路径(分类/建档/判定)都不可能意外花钱。

    默认地址也改成了本地 —— 以前缺设置就会默默打 api.deepseek.com。
    """
    base = db.get_setting("ai_base_url", "http://127.0.0.1:8080/v1").rstrip("/")
    _is_local = ("127.0.0.1:" in base) or ("localhost:" in base)
    if not _is_local and not (allow_cloud and db.get_setting("cloud_ai_enabled", "0") == "1"):
        log.warn("云端调用被拦 @ai._call_api",
                 detail="0 成本模式:云端未启用,已拒绝 %s" % base)
        raise RuntimeError("云端 AI 未启用(0 成本模式)—— 当前只有“夜间回复”允许走云端")
    key = db.get_setting("ai_api_key", "")
    # 本地模型:调用前自动拉起(内置,不用手动开)
    if local_base() and not local_running():
        ensure_local()
    body = {
        "model": db.get_setting("ai_model", "deepseek-chat"),
        "temperature": 0,
        "messages": messages,
    }
    # 强制 JSON 输出。部分本地运行时/网关不认这个参数,可用 ai_json_mode=0 关掉。
    if db.get_setting("ai_json_mode", "1") == "1":
        body["response_format"] = {"type": "json_object"}
    # 本地模型输出慢:不限制生成长度时偶尔会跑飞,给个上限
    try:
        body["max_tokens"] = max(256, int(db.get_setting("ai_max_tokens", "900") or 900))
    except (TypeError, ValueError):
        pass
    req = urllib.request.Request(
        base + "/chat/completions",
        data=json.dumps(body).encode("utf-8"),
        headers={"Content-Type": "application/json",
                 "Authorization": "Bearer " + (key or "local")},
        method="POST")
    with urllib.request.urlopen(req, timeout=_timeout()) as r:
        data = json.loads(r.read().decode("utf-8"))
    content = data["choices"][0]["message"]["content"]
    # 本地小模型常犯:外面包一层 markdown 代码块,去掉再解析
    content = (content or "").strip()
    if content.startswith("```"):
        content = re.sub(r"^```[a-zA-Z]*\s*", "", content)
        content = re.sub(r"```\s*$", "", content).strip()
    return json.loads(content)


def _kb_context():
    """把知识库里跟判断相关的条目抽成约束文本(给 AI 当标准答案)。"""
    want = ("客户规则", "术语对照", "组织与角色", "收录规则", "公司档案")
    lines = []
    for it in db.list_kb():
        if it["category"] in want:
            lines.append("[%s] %s\n%s" % (it["category"], it["title"],
                                          it["content"]))
    return "\n\n".join(lines)[:4000]


def build_prompt(msgs, kb):
    chat = []
    for m in msgs:
        who = "客户" if m["direction"] == "in" else "我方"
        chat.append("%s: %s" % (who, (m["content"] or "").strip()))
    chat_text = "\n".join(chat)[-4000:]
    sys = (
        "你是外贸客户档案助手。根据【客户对话】和【知识库】判断客户三项信息。\n"
        "规则:\n"
        "1) identity 只能从[业主/建筑商/中介/设计师/采购商/其他]选;\n"
        "2) followup 只能从[等待客户确认/挑选款式/待我出方案/搭配/待我报价/待客户付款/待发货/其他]选;\n"
        "3) grade 只能从[A/B/C]选,标准以知识库为准;\n"
        "4) 每个结论必须给出 quote=客户对话里的原文原句(逐字复制);没有证据就 value=\"unknown\"、quote=\"\";\n"
        "5) 禁止编造,禁止推理出对话里没有的内容。\n"
        '只输出 JSON: {"identity":{"value":"","quote":""},"followup":{"value":"","quote":""},"grade":{"value":"","quote":""}}'
    )
    user = "【知识库】\n%s\n\n【客户对话】\n%s" % (kb, chat_text)
    return [{"role": "system", "content": sys},
            {"role": "user", "content": user}]


def process_customer(customer_id):
    """对某客户认不出的字段跑一次 AI(受上限约束),返回处理摘要。"""
    if not enabled():
        db.add_ai_log(customer_id, "batch", "", "", "disabled", "AI 未开启或未配密钥")
        return {"status": "disabled"}
    u = usage()
    if u["left"] <= 0:
        db.add_ai_log(customer_id, "batch", "", "", "capped", "已达每日上限")
        return {"status": "capped"}
    msgs = db.list_messages(customer_id=customer_id, limit=30)
    if not msgs:
        return {"status": "no-messages"}
    msgs_text = "\n".join((m["content"] or "") for m in msgs)
    try:
        out = _call_api(build_prompt(msgs, _kb_context()))
    except Exception as exc:
        db.add_ai_log(customer_id, "batch", "", "", "error", str(exc)[:200])
        return {"status": "error", "detail": str(exc)[:200]}

    results, updates = {}, {}
    for task, enum in AI_ENUMS.items():
        item = (out or {}).get(task) or {}
        value = str(item.get("value") or "").strip()
        quote = str(item.get("quote") or "").strip()
        if value in ("", "unknown", "None", "未知", "null"):
            results[task] = "unknown"
            db.add_ai_log(customer_id, task, "", "", "unknown", "AI 也无法确定")
            continue
        if value not in enum:
            results[task] = "bad-enum"
            db.add_ai_log(customer_id, task, value, quote, "rejected", "不在枚举内")
            continue
        if not guard.quote_in(quote, msgs_text, min_len=4):
            results[task] = "no-quote"
            db.add_ai_log(customer_id, task, value, quote, "rejected",
                          "引用不在对话原文里")
            continue
        results[task] = value
        updates[FIELD_MAP[task]] = value
        db.add_ai_log(customer_id, task, value, quote, "ok", "")
    if updates:
        db.apply_profile(customer_id, **updates)
    return {"status": "ok", "results": results, "usage": usage()}
