# -*- coding: utf-8 -*-
"""自动导入:把 WhatsApp 导出的 .txt 丢进「收件文件夹」就自动入库。

为什么不从协议里拉历史:非官方客户端反复请求历史,正是账号被封的加速器之一。
改用 WhatsApp **官方导出** → 文件自动导入 —— 没有协议风险,且时间戳完整。

用法(全自动):
   1) 手机上:聊天 → 导出聊天 → 存到「与电脑同步的文件夹」
   2) 把该文件夹指给本软件:设置 import_inbox_dir(默认 data/import-inbox)
   3) 之后只要文件落进该文件夹,软件**每 20 秒扫一次**,自动导入

文件名约定(强烈建议):
    「客户名(或群名) 手机号.txt」 → 例:示例客户 +12345678901.txt
    带号码就能精确归到客户;不带号码则按名字匹配已有客户。
"""
import os
import re
import shutil
import threading
import time

from . import chatimport, db, log

DEFAULT_INBOX = os.path.join(db.PROJECT_DIR, "data", "import-inbox")


def inbox_dir():
    d = (db.get_setting("import_inbox_dir", "") or "").strip() or DEFAULT_INBOX
    return d


def _phone_from_name(fname):
    """从文件名里抠手机号(如 '示例客户 +12345678901.txt')。"""
    m = re.search(r"(\+?\d[\d\s\-]{6,})", os.path.splitext(fname)[0])
    if not m:
        return ""
    digits = db._digits(m.group(1))
    return ("+" + digits) if len(digits) >= 8 else ""


def _peer_from_name(fname):
    """去掉号码后的剩余部分当作客户名。"""
    stem = os.path.splitext(fname)[0]
    stem = re.sub(r"\+?\d[\d\s\-]{6,}", "", stem).strip(" _-·|")
    return stem.strip()


def _read_text(path):
    for enc in ("utf-8-sig", "utf-8", "utf-16", "gb18030", "latin-1"):
        try:
            with open(path, encoding=enc) as f:
                return f.read()
        except (UnicodeDecodeError, UnicodeError):
            continue
        except OSError:
            return ""
    return ""


def import_text(name, text, phone="", peer=""):
    """按文件名(可含号码)+ 文本导入。收件夹与「一次性导入」共用这一套。

    返回 {ok, customer_id, customer, imported, has_ts, matched_by, file} 或 {ok:False,error}
    """
    name = name or "粘贴内容.txt"
    if not (text or "").strip() or len(text.strip()) < 20:
        return {"ok": False, "error": "内容为空或太短", "file": name}
    phone = phone or _phone_from_name(name)
    peer = peer or _peer_from_name(name)
    cust = None
    matched_by = ""
    if phone:
        cust = db.find_customer_by_phone(phone)
        matched_by = "phone"
    if not cust and peer:
        cust = db.find_customer_by_name(peer)
        matched_by = "name"
    if cust:
        cid = cust["id"]
        if phone and not (cust.get("phone") or "").strip():
            db.update_customer(cid, {"phone": phone})
    else:
        cid = db.create_customer({"name": peer or phone or "导入客户",
                                  "phone": phone, "source": "导出导入"})
        matched_by = "new"
    res = chatimport.import_chat(cid, text, peer_name=peer or None, source="import")
    return {"ok": True, "customer_id": cid, "matched_by": matched_by,
            "imported": res.get("imported"), "has_ts": res.get("has_ts"),
            "customer": (db.get_customer(cid) or {}).get("name"), "file": name}


def import_one(path, move_done=True):
    """导入一个 .txt 文件(收件夹用)。"""
    name = os.path.basename(path)
    text = _read_text(path)
    out = import_text(name, text)
    if not out.get("ok"):
        return out
    if move_done:
        done = os.path.join(inbox_dir(), "done")
        os.makedirs(done, exist_ok=True)
        try:
            shutil.move(path, os.path.join(done, name))
        except OSError as e:
            log.swallow("autoimport.move", e)
    try:
        with open(os.path.join(db.PROJECT_DIR, "data", "import-log.tsv"),
                  "a", encoding="utf-8") as f:
            f.write("%s\t%s\t%s\t%s\t%s\t%s\n" % (db.now_iso(), name, out.get("customer"),
                                                  out.get("imported"), matched_by,
                                                  out.get("error") or ""))
    except OSError as e:
        log.swallow("autoimport.log", e)
    return out


def scan_once(limit=5):
    """扫一次收件夹,导入最多 limit 个文件。返回结果列表。"""
    d = inbox_dir()
    if not os.path.isdir(d):
        try:
            os.makedirs(d, exist_ok=True)
        except OSError:
            return []
    done = os.path.join(d, "done")
    outs = []
    n = 0
    for fn in sorted(os.listdir(d)):
        if n >= limit:
            break
        p = os.path.join(d, fn)
        if not os.path.isfile(p):
            continue
        if fn.startswith(".") or fn.lower().endswith((".md", ".log", ".tsv")):
            continue
        if not fn.lower().endswith((".txt", ".text")):
            continue
        try:
            r = import_one(p)
        except Exception as e:            # 单个文件坏了不影响别的
            log.swallow("autoimport.scan:%s" % fn, e)
            r = {"ok": False, "error": str(e), "file": fn}
        outs.append(r)
        n += 1
        time.sleep(0.2)
    return outs


def stats():
    """给界面看:收件夹位置 + 待处理数量。"""
    d = inbox_dir()
    pend = 0
    try:
        pend = len([f for f in os.listdir(d)
                    if os.path.isfile(os.path.join(d, f))
                    and f.lower().endswith((".txt", ".text"))])
    except OSError:
        pass
    return {"inbox": d, "pending": pend}


_thread = None
_stop = threading.Event()


def _loop():
    while True:
        try:
            scan_once()
        except Exception as e:
            log.swallow("autoimport.loop", e)
        if _stop.wait(20):      # 每 20 秒看一次收件夹
            return


def start_background():
    """启动后台扫描线程(幂等)。零成本:只读文件夹。"""
    global _thread
    if _thread and _thread.is_alive():
        return
    _stop.clear()
    try:
        os.makedirs(inbox_dir(), exist_ok=True)
    except OSError as e:
        log.swallow("autoimport.mkdir", e)
    _thread = threading.Thread(target=_loop, daemon=True)
    _thread.start()
