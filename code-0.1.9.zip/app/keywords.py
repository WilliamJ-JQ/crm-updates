# -*- coding: utf-8 -*-
"""规则词表默认值 —— 按 本公司真实经营范围定制(除水泥沙外几乎全品类)。

经营范围:门窗、地板(木/岩板/瓷砖/天然石材)、软装(墙板/地毯/窗帘/百叶)、
家具、卫浴、定制柜、金属玻璃、电器、天然石材、灯饰,以及 sourcing 全品类代采。

所有词表都可在软件的【设置】页里直接修改,修改后存进本地数据库,下次分析立刻生效。
匹配规则(见 rules.py):中文词按"包含"匹配;英文单词按"整词"匹配(兼容复数);
多词短语(如 lead time)按"包含"匹配。太短的词(中文 1 字 / 英文 2 字母)自动忽略,避免误报。
"""

DEFAULT_GROUPS = {
    # ---- 产品词(按品类分组,方便你以后删改) ----
    "product_terms": (
        # 门窗 / 幕墙
        "window, door, 门窗, 铝合金, aluminum, aluminium, upvc, sliding door, 推拉门, "
        "系统窗, 幕墙, curtain wall, 阳光房, sunroom, 纱窗, 天窗, skylight, "
        "防盗门, security door, 木门, wooden door, 防火门, "
        # 地板 / 墙地材
        "flooring, 地板, 木地板, 实木地板, engineered wood, laminate, spc, wpc, 强化地板, "
        "岩板, sintered stone, 瓷砖, tile, porcelain, ceramic, 陶瓷, 天然石材, stone, "
        "marble, 大理石, granite, 花岗岩, travertine, 洞石, quartz, 石英石, 木纹砖, "
        "mosaic, 马赛克, wall panel, 墙板, 护墙板, 木饰面, "
        # 软装
        "软装, soft furnishing, curtain, 窗帘, blinds, 百叶, 地毯, rug, carpet, "
        "wallpaper, 壁纸, 墙布, 布艺, upholstery, cushion, 抱枕, decor, 装饰, "
        "artwork, 挂画, accessory, 摆件, 床品, "
        # 家具
        "furniture, 家具, sofa, 沙发, bed, 床, bed frame, 床架, headboard, 床头, "
        "wardrobe, 衣柜, closet, dining table, 餐桌, coffee table, 茶几, side table, 边几, "
        "tv unit, media unit, tv wall, 电视柜, desk, 书桌, chair, 椅子, stool, 吧椅, "
        "bar stool, cabinet, 柜, 橱柜, kitchen cabinet, 榻榻米, custom, 定制, "
        "countertop, 台面, 台面石, "
        # 卫浴
        "sanitary, 卫浴, toilet, 马桶, basin, 洗手盆, faucet, 龙头, shower, 淋浴, "
        "shower enclosure, 淋浴房, bathtub, 浴缸, vanity, 浴室柜, bidet, 花洒, "
        "智能马桶, sink, 水槽, "
        # 金属 / 玻璃
        "metal, 金属, steel, 不锈钢, stainless steel, iron, 铁艺, glass, 玻璃, "
        "mirror, 镜子, railing, 栏杆, staircase, 楼梯, handrail, 扶手, partition, 隔断, "
        "屏风, 铝单板, 铝板, "
        # 电器
        "appliance, 家电, 电器, air conditioner, 空调, refrigerator, 冰箱, "
        "washing machine, 洗衣机, oven, 烤箱, range hood, 油烟机, dishwasher, 洗碗机, "
        "电视, smart home, 智能家居, 新风, 地暖, 净水, 热水器, "
        # 灯饰 / 电气
        "lighting, 灯饰, chandelier, 吊灯, pendant light, ceiling light, 吸顶灯, "
        "wall light, 壁灯, downlight, 筒灯, spotlight, 射灯, led strip, 灯带, "
        "switch, 开关, socket, 插座, panel light, 面板灯, 线性灯, "
        # 其他建材/辅料
        "五金, hardware, hinge, 合页, 防水, waterproof, 卷材, membrane, 涂料, paint, "
        "油漆, coating, 吊顶, ceiling, 石膏板, gypsum, insulation, 保温, 隔音, 美缝"
    ),
    # 询盘意向词
    "inquiry_terms": (
        "buy, purchase, order, need, want, 采购, 需要, 想买, 询价, 要货, supply, "
        "price, 价格, quotation, 报价, quote, interested, 感兴趣, 请提供, "
        "looking for, 求购, 预算, budget"
    ),
    # 数量/规模词
    "qty_terms": (
        "pcs, pieces, sets, units, cartons, tons, 吨, container, 柜, 40hq, 20gp, "
        "sqm, m2, 平方米, 件, 套, 箱, qty, quantity, moq, 起订量, "
        "整栋, 全屋, room, 房间, 客房"
    ),
    # 交易条件词
    "trade_terms": (
        "fob, cif, ddp, exw, l/c, t/t, 信用证, 付款, payment, 定金, deposit, 预付款, "
        "尾款, 分期, 账期, 付款方式, payment terms, 海运, shipping, freight, 运费, "
        "incoterms, 认证, certificate, sgs, iso, 样品费, courier, 快递费, "
        "proforma, pi, 形式发票"
    ),
    # 决策信号词
    "decision_terms": (
        "验厂, factory audit, audit, visit factory, 样品, sample, 展会, 广交会, "
        "canton fair, exhibition, 合同, contract, po, purchase order, 下单, place order, "
        "confirm, 确认, exclusive, 独家, agent, 代理, 合作, "
        "proposal, 方案, 设计方案, 效果图, 3d render, floor plan, 平面图, mood board, "
        "报价单, 试单, 首批, 大货"
    ),
    # 整装 / 代采信号(你们 sourcing 部门的招牌业务)
    "sourcing_terms": (
        "sourcing, 代采, 采购代理, buying agent, 一站式, one-stop, 整装, "
        "whole house, whole villa, whole-villa, full house, turnkey, 交钥匙, "
        "package price, 打包价, project price, 工程单, 集采, 批量采购, 整体方案"
    ),
    # 承诺词(用于识别"我答应客户 X 天内做某事")
    "commit_terms": (
        "报价, 发报价, 给报价, quotation, quote, 回复, 答复, 寄样, 发样, 发货, 交货, "
        "交期, deliver, delivery, lead time, 安排, 打样, 出方案, proposal, send, 明天给你"
    ),
    # 客户行程地点词
    "travel_places": (
        "中国, china, 广州, guangzhou, canton, 佛山, foshan, 上海, shanghai, 深圳, "
        "shenzhen, 香港, hong kong, 工厂, factory, 展会, fair, exhibition, 广交会, "
        "来中国, 到中国, 到广州, 来广州, 参观工厂, visit china, coming to china"
    ),
}
