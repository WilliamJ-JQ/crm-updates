# -*- coding: utf-8 -*-
"""硬约束层(Code Guard):AI 的输出在进入系统之前,必须通过的机械校验。

关键点:这里全部是普通 Python 代码 —— 不经过模型、不读提示词。
所以提示词写得再细或再糙,都绕不过它。

三道机械闸门:
  1) 结构校验:字段形状必须合规(缺字段/空值直接拒)
  2) 引用校验:每个结论附带的 quote 必须逐字出现在来源里
     —— 对不上就丢弃(这是防"编造事实"的主力)
  3) 事实来源校验:价格/交期/认证/付款条件等"硬信息",只能引用知识库原文,
     不允许 AI 自由生成

边界说明(诚实交代):机械校验能消灭"编造事实",但消灭不了"理解偏差"
(例如把玩笑当成真意向)。所以高风险字段一律要求:引用 + 人工确认。
"""
import re

# 硬信息字段:只能引用知识库原文,不允许 AI 生成
HARD_FIELDS = {
    "price", "价格", "报价", "单价", "lead_time", "交期", "交货期",
    "certification", "认证", "证书", "payment_terms", "付款条件",
    "moq", "起订量", "warranty", "质保",
}

# 归一化时忽略的标点(中英文都要,避免"标点差异"造成误判)
_PUNCT = "，。、；：：“”‘’（）《》【】！？…·,.;:\"'()<>[]!?-—_/ \u3000"


def normalize(text):
    """归一化:去空白、转小写、去标点。用于做"逐字存在"检查。"""
    if not text:
        return ""
    s = str(text).lower()
    s = re.sub(r"\s+", "", s)
    return "".join(ch for ch in s if ch not in _PUNCT)


def quote_in(quote, source, min_len=4):
    """quote 是否逐字存在于 source(容忍标点/空白/大小写差异)。

    min_len 下限用来堵住"引用一个 a/的/."这类无意义片段。
    """
    q, s = normalize(quote), normalize(source)
    if len(q) < min_len:
        return False
    return q in s


def verify_fields(fields, message_text="", kb_resolver=None):
    """校验一批 AI 抽取结果。

    fields: [{"name": 字段名, "value": 值, "quote": 原文片段,
              "source": "message" 或 "kb:<条目id>"}]
    message_text: 来源消息原文
    kb_resolver: 函数 kid -> 知识库条目 dict(含 content),用于校验 kb: 来源

    返回 {"ok": bool, "accepted": [...], "rejected": [{"field","reason"}]}
    只要有任何字段被拒,ok=False —— 调用方应整体丢弃或标记待人工处理。
    """
    if not isinstance(fields, list):
        return {"ok": False, "accepted": [],
                "rejected": [{"field": "*", "reason": "不是列表结构"}]}

    accepted, rejected = [], []
    for f in fields:
        f = f or {}
        name = str(f.get("name", "")).strip()
        value = f.get("value", "")
        quote = str(f.get("quote", "") or "")
        source = str(f.get("source", "message") or "message")

        # ---- 闸门1:结构 ----
        if not name or value is None or str(value).strip() == "":
            rejected.append({"field": name or "?", "reason": "字段名缺失或值为空"})
            continue
        if not quote.strip():
            rejected.append({"field": name, "reason": "没有原文引用(无引用不算数)"})
            continue

        # ---- 闸门3:硬信息必须来自知识库 ----
        if name in HARD_FIELDS and not source.startswith("kb:"):
            rejected.append({"field": name,
                             "reason": "硬信息必须引用知识库,不允许 AI 生成"})
            continue

        # ---- 闸门2:引用必须真实存在 ----
        if source.startswith("kb:"):
            kid = source.split(":", 1)[1].strip()
            item = kb_resolver(int(kid)) if (kb_resolver and kid.isdigit()) else None
            if not item or not quote_in(quote, item.get("content", "")):
                rejected.append({"field": name,
                                 "reason": "引用的知识库片段不存在"})
                continue
        else:
            if not quote_in(quote, message_text):
                rejected.append({"field": name,
                                 "reason": "引用片段在消息原文里找不到(疑似编造)"})
                continue

        accepted.append({"name": name, "value": value, "quote": quote,
                         "source": source})

    return {"ok": not rejected, "accepted": accepted, "rejected": rejected}
