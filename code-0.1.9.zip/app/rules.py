# -*- coding: utf-8 -*-
"""规则引擎:识别高价值信号 + 生成提醒建议。

纯代码、可解释、结果透明 —— 每一条判断都能说清"因为命中了哪个词"。
词表存本地库(设置页可改),匹配逻辑如下:
 - 中文词/英文短语:原文包含该词即命中(中文词长>=2,避免"来/到"误报)
 - 英文单词:按整词匹配(忽略大小写,自动兼容复数)
 - 过短的英文词(<=2 字母)不参与匹配,避免 "ce" 撞进 "price" 之类误报
"""
import re

from . import db

# 这些组命中后,会作为"高价值信号标签"打到消息上(界面里显示彩色标签)
GROUP_LABELS = [
    ("product_terms", "产品匹配"),
    ("inquiry_terms", "询盘意向"),
    ("qty_terms", "数量/规模"),
    ("trade_terms", "交易条件"),
    ("decision_terms", "决策信号"),
    ("sourcing_terms", "整装/代采信号"),
]

# 行程意图上下文词:与"地点词"同时出现,才判断为"客户要来的行程",
# 避免客户随口提到国家名(如 "made in china")就误报。
_TRAVEL_SINGLE = {"来", "到", "将", "会", "飞"}
_TRAVEL_PHRASES = [
    "计划", "打算", "安排", "准备", "下月", "下周", "下个月", "月底", "月初",
    "明天", "后天", "coming", "planning", "plan", "will", "next month",
    "next week", "visit", "参观", "拜访", "考察", "前往",
]

RE_ZH_DUR = re.compile(r"(\d+)\s*(个?工作日|天内|日内|天|周|小时)")
RE_EN_DUR = re.compile(
    r"\b(?:within|in|after)\s+(\d+)\s*(business\s+days?|days?|weeks?|hours?)\b"
    r"|\b(\d+)\s*(business\s+days?|days?|weeks?)\b")

UNIT_DAYS = {
    "工作日": 1, "business days": 1, "天内": 1, "日内": 1, "天": 1,
    "days": 1, "day": 1, "周": 7, "weeks": 7, "week": 7,
    "小时": 1, "hours": 1, "hour": 1,
}


def _is_cjk(text):
    return any("\u4e00" <= ch <= "\u9fff" for ch in text)


def match_term(content_low, term):
    """返回 True/False:某条消息是否命中某个关键词。"""
    t = term.strip().lower()
    if not t:
        return False
    if _is_cjk(t):
        return len(t) >= 2 and t in content_low
    if len(t) <= 2:
        return False
    if " " in t:  # 英文短语(如 lead time)按包含匹配
        return t in content_low
    # 英文单词:整词匹配,兼容复数
    return re.search(r"(?<![a-z0-9])" + re.escape(t) + r"s?(?![a-z0-9])",
                     content_low) is not None


def _extract_days(low):
    """从消息里找出最早出现的时长(如"3天"/"within 5 days"),换算成天数。找不到返回 None。"""
    found = []
    for m in RE_ZH_DUR.finditer(low):
        n = int(m.group(1))
        found.append((m.start(), n * UNIT_DAYS.get(m.group(2), 1)))
    for m in RE_EN_DUR.finditer(low):
        if m.group(1):
            n, unit = int(m.group(1)), m.group(2)
        elif m.group(3):
            n, unit = int(m.group(3)), m.group(4)
        else:
            continue
        found.append((m.start(), n * UNIT_DAYS.get(unit, 1)))
    if not found:
        return None
    found.sort(key=lambda x: x[0])
    return found[0][1]


def _travel_context_hit(low):
    for w in _TRAVEL_SINGLE:
        if w in low:
            return True
    for p in _TRAVEL_PHRASES:
        if p in low:
            return True
    return False


def _sentence_with(text, terms):
    """找出包含任一命中词的整句 —— 用作"原话引用",让你一眼看到依据。"""
    for sent in re.split(r"(?<=[.!?;。！？；])|\n+", text or ""):
        s = (sent or "").strip()
        if not s:
            continue
        low = s.lower()
        for t in terms:
            if match_term(low, t):
                return s[:200]
    return (text or "").strip()[:200]


# 强承诺句式:只有"写明天数"或出现这种句式,才算真承诺。
# (否则光出现 quote/send 这类词会刷出一堆无意义建议 —— 导入几百条聊天时尤其明显)
_STRONG_RE = re.compile(
    r"\b(i|we|i'll|we'll)\s*(will|shall|can|are going to|'ll)?\s*"
    r"(send|quote|offer|arrange|provide|prepare|share|check|confirm)\b"
    r"|\b(will|shall)\s+(send|quote|offer|arrange|provide)\b"
    r"|(寄样|打样|报价|发报价|出报价|安排|尽快发|稍后发|今天发|明天发|下周发)",
    re.IGNORECASE)


# 客户自带的设计师/建筑师 —— 客户群里除了客户本人,常常还有甲方设计方在说话。
# 识别分两档:
#   strong  = 自我介绍句(「我是设计师 / I'm the designer」)→ 可直接标『客户设计师』
#   mention = 顺带提到(my designer / 我们设计师会联系你)→ 线索,交人工确认
_DESIGNER_STRONG_RE = re.compile(
    r"(i\s*am|i'm|this\s+is|we['\u2019]?re|我是|这边是|这里是|我们是)\s*"
    r"[^。.!?;,\n]{0,12}"
    r"(interior\s+designer|designer|architect|设计师|设计总监|设计负责人|设计方)",
    re.I)
_DESIGNER_MENTION_RE = re.compile(
    r"\b(my|our|their|his|her|the)\s+(interior\s+designer|designer|architect)\b"
    r"|设计师|建筑师|design\s+team", re.I)


# ---- 七类跟进需求(用户 2026-09-15 定)----
SEVEN_KINDS = ["客户提问", "客户询价", "客户催促",
               "我方承诺报价", "我方承诺出方案", "我方承诺回复", "线上会议"]
_QUOTE_RE = re.compile(r"报价|价格|单价|quote|quotation|price|offer|cost|usd|rmb", re.I)
_PROPOSAL_RE = re.compile(r"方案|设计|图纸|效果图|目录|产品知识|catalog|catalogue|brochure|design|drawing|layout|cad|3d", re.I)
_URGENT_RE = re.compile(r"urgent|asap|hurry|尽快|紧急|催|急|as soon as possible", re.I)
_MEETING_RE = re.compile(r"zoom|meeting|会议|线上|视频|电话会议|来访|参观|行程|见面", re.I)


def kind_of(direction, text):
    """把一条消息归一到七类(direction: in=客户发来,out=我方发出)。"""
    low = (text or "").lower()
    if _MEETING_RE.search(low):
        return "线上会议"
    if direction == "out":
        if _QUOTE_RE.search(low):
            return "我方承诺报价"
        if _PROPOSAL_RE.search(low):
            return "我方承诺出方案"
        return "我方承诺回复"
    if _QUOTE_RE.search(low):
        return "客户询价"
    if _URGENT_RE.search(low):
        return "客户催促"
    return "客户提问"


def designer_signal(text):
    """这句话里有没有“设计师”信号。

    返回 (level, quote):level ∈ 'strong' / 'mention' / ''(没有)。
    只做线索识别,不自动改档案 —— 归类要么代码强信号,要么人工点。
    """
    t = (text or "").strip()
    if not t:
        return ("", "")
    m = _DESIGNER_STRONG_RE.search(t)
    if m:
        return ("strong", _sentence_with(t, [m.group(0)]))
    m = _DESIGNER_MENTION_RE.search(t)
    if m:
        return ("mention", _sentence_with(t, [m.group(0)]))
    return ("", "")


def analyze(content, direction="in"):
    """分析一条消息。

    direction: "in"=客户发来,"out"=我方发出。这个区分很重要:
      - 我方发出 里出现"报价/寄样" → 是"我方承诺"(承诺类提醒);
      - 客户发来 里出现 "please quote" → 是"客户在要"(待办类提醒)。
      两者搞混,会把客户的要求误记成我们的承诺。

    返回 dict:
      tags        -> 高价值信号标签列表(中文名,用于打标签)
      hits        -> {标签中文名: [命中的词,...]},供界面展示"为什么这么判断"
      suggestion  -> None 或 {kind, note, days} 提醒建议(仅建议,需你批准)
    """
    low = content.strip().lower()
    result = {"tags": [], "hits": {}, "suggestion": None}

    if not low:
        return result

    # 1) 高价值信号标签
    for key, label in GROUP_LABELS:
        matched = [t for t in db.get_group_terms(key) if match_term(low, t)]
        if matched:
            result["hits"][label] = matched
            result["tags"].append(label)

    # 2) 提醒建议:承诺优先,其次行程
    commit_hits = [t for t in db.get_group_terms("commit_terms") if match_term(low, t)]
    if commit_hits:
        days = _extract_days(low)
        # 排误报:写明天数 或 强承诺句式 才算"真承诺"
        if days is None and not _STRONG_RE.search(low):
            commit_hits = []
    if commit_hits:
        is_quote = any(("报价" in t or "quotation" in t or "quote" in t or "offer" in t)
                       for t in commit_hits)
        kind = kind_of(direction, low)      # 七类归一
        head = "我方承诺" if direction == "out" else "客户要求"
        # 卡片要一眼看清"是什么事":用简短动词短语,不堆关键词
        if is_quote:
            what = "提供报价"
        elif any(("sample" in t or "样" in t) for t in commit_hits):
            what = "寄送样品"
        elif direction == "in" and any(k in low for k in
                ("catalog", "catalogue", "brochure", "目录", "产品知识", "方案",
                 "design", "drawing", "layout", "3d")):
            what = "出方案/发目录"
        else:
            what = "跟进回复"
        if direction == "in":
            # 客户的要求:限时按“要什么”定 —— 要报价 2 日内;要目录/方案 当日完成。
            if is_quote:
                days = days or 2
            elif what == "出方案/发目录":
                days = 0
            limit_txt = "限时当日完成" if days == 0 else (
                "限时 %d 天内" % days if days else "未写明天数")
        else:
            # 不拼“0 天内 / 未写明天数”这种废话:限时由卡片统一按“当日完成 / 2 日内”显示,
            # 只有当真的解析出天数(如“20 天内”)才写进来
            limit_txt = (" · %d 天内" % days) if days else ""
        # 卡片头部已有客户名,这里只写“需求 + 限时”,不重复客户名
        note = head + ":" + what + " · " + limit_txt
        result["suggestion"] = {"kind": kind, "note": note, "days": days,
                                "quote": _sentence_with(content, commit_hits)}
        return result

    places = [t for t in db.get_group_terms("travel_places") if match_term(low, t)]
    # 【坑】客户行程只能由**客户方**的话触发。以前不看方向,运营在群里介绍 PM 的
    # 那句(“我介绍下我们 PM…”)被当成“客户行程”,还会反过来怪 PM 没回复。
    if direction == "in" and places and _travel_context_hit(low):
        note = "线上会议/来访 · 未定日期(批准时请选)"
        result["suggestion"] = {"kind": "线上会议", "note": note, "days": None,
                                "quote": _sentence_with(content, places)}
    return result
