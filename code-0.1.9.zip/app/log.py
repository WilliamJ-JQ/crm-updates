# -*- coding: utf-8 -*-
"""轻量日志(不依赖任何外部服务)。

为什么需要它:代码里原本有 30+ 处 `except Exception: pass`,出错时**什么都不留**,
排障只能靠猜(今天「消息记录整页空白」就是这么被吞掉的)。

用法:
    from . import log
    try: ...
    except Exception as e: log.swallow("模块:位置", e)

日志写到 data/app.log(单文件,超过 1MB 自动截断),同时打到 stderr。
"""
import os
import threading
import traceback
from datetime import datetime

_LOCK = threading.Lock()
_MAX_BYTES = 1024 * 1024


def _path():
    # 放在应用目录下的 data/app.log
    base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    d = os.path.join(base, "data")
    try:
        os.makedirs(d, exist_ok=True)
    except OSError:
        return None
    return os.path.join(d, "app.log")


def warn(where, exc=None, detail=""):
    """记一条警告(一般不中断流程)。"""
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    msg = "[%s] WARN %s" % (ts, where)
    if exc is not None:
        msg += " | %s: %s" % (type(exc).__name__, exc)
    if detail:
        msg += " | " + str(detail)[:300]
    p = _path()
    with _LOCK:
        try:
            if p and os.path.exists(p) and os.path.getsize(p) > _MAX_BYTES:
                with open(p, "a", encoding="utf-8") as f:
                    f.write("[%s] (日志超 1MB,已截断)\n" % ts)
                os.replace(p, p + ".1")
            if p:
                with open(p, "a", encoding="utf-8") as f:
                    f.write(msg + "\n")
        except OSError:
            pass
        print(msg, flush=True)
    return msg


def swallow(where, exc=None):
    """吞掉异常但**留下痕迹** —— 用于原本 `except Exception: pass` 的地方。"""
    return warn("吞掉异常 @" + str(where), exc)


def error(where, exc=None, tb=False):
    """记一条错误(可带堆栈)。"""
    if tb and exc is not None:
        return warn(where, exc, detail=traceback.format_exc().splitlines()[-1])
    return warn(where, exc)


def tail(n=40):
    p = _path()
    if not p or not os.path.exists(p):
        return ""
    with open(p, encoding="utf-8", errors="replace") as f:
        return "".join(f.readlines()[-n:])
