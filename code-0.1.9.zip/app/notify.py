# -*- coding: utf-8 -*-
"""软件内提醒引擎(纯代码,不依赖任何外部服务 / 不依赖 OpenClaw)。

后台线程每隔 N 秒扫描一次:
  1) 到点的提醒(状态=已批准 且 提醒日期 <= 今天)
  2) 今日应跟进的客户(按 A/B/C 分级节奏算出)
命中就写入"通知中心";界面轮询后弹横幅 + 响铃。

去重:同一件事同一天只通知一次(靠 notifications 表的唯一 key)。

成本:零。不调用任何模型,不产生任何 token。
"""
import threading
import time

from . import db, profile
from . import log

_thread = None
_stop = threading.Event()


def scan():
    """扫描一次,返回本次新增通知条数。"""
    today = db.today_iso()
    created = 0
    # 1) 到点提醒
    for r in db.due_reminders(today):
        key = "reminder:%d:%s" % (r["id"], today)
        if not db.notification_exists(key):
            text = "【%s】%s" % (r.get("customer_name") or "客户",
                              r.get("note") or r.get("kind") or "该跟进了")
            db.add_notification(key, "提醒到点", text, r["customer_id"])
            created += 1
    # 2) 今日跟进(A/B/C 节奏)
    for c in profile.today_followups():
        key = "followup:%d:%s" % (c["id"], today)
        if not db.notification_exists(key):
            bits = [c.get("name") or "客户", c.get("identity") or ""]
            if c.get("followup_category"):
                bits.append(c["followup_category"])
            db.add_notification(key, "今日跟进(%s级)" % c.get("grade", ""),
                                " · ".join([b for b in bits if b]), c["id"])
            created += 1
    return created


def _loop():
    while not _stop.wait(_interval()):
        try:
            scan()
        except Exception as e:
            log.swallow("notify.py:51", e)


def _interval():
    try:
        return max(15, int(db.get_setting("notify_interval_seconds", "60") or 60))
    except ValueError:
        return 60


def start_background():
    """在服务进程里启动后台扫描线程(幂等)。"""
    global _thread
    if _thread and _thread.is_alive():
        return
    _stop.clear()
    _thread = threading.Thread(target=_loop, daemon=True)
    _thread.start()
