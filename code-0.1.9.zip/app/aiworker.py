# -*- coding: utf-8 -*-
"""边聊边跑的 AI 识别队列(后台 worker)。

设计要点(按用户纠正后的版本):
  - 消息是**一条条散着来**的,不是所有消息都要 AI;实测十条里 1~2 条才需要
  - **代码先滤**(每条、瞬间、免费):像"待办"的才进队列
  - 队列丢给**后台线程**慢慢跑本地模型 —— PM 一边聊,AI 一边跑,**不阻塞**
  - 跑完自动归档:
      · 我方承诺  → 进【承诺审批】(等 PM 批;卡片必须一眼看清"承诺是什么")
      · 客户提问  → 直接进【待跟进】,标「系统直判」(可撤回)
  - 云端(DeepSeek)默认**不参与识别**,把成本留给夜间回复

成本:代码 0 元 → 本地模型 0 元。这一层不需要花钱。
"""
import json
import re
import threading
import time

from . import ai as ai_mod
from . import log
from . import db
from . import rules

# 队列上限:积压太多就不再往里塞,避免把本地 CPU 压死
MAX_PENDING = 40
POLL_SECONDS = 12

_QUESTION_HINTS = ("?", "吗", "怎么", "如何", "多少", "能不能", "可不可以",
                   "是否", "请问", "请", "麻烦", "需要", "希望", "什么时候",
                   "尽快", "给我", "发我", "确认", "报价", "价格", "样品",
                   "could you", "can you", "please", "need", "want", "require",
                   "looking for", "send me", "when will", "lead time", "advise",
                   "confirm", "update")


def should_enqueue(text, direction, analysis):
    """代码先滤:这条消息值不值得让 AI 看一眼?

    实测教训:“Hi, how are you today?” 这种寒暄不能进队列(否则十条里有几条
    都是废话,白白占着本地 CPU)。所以要求 **先有业务信号**,再谈像不像提问。
    """
    low = (text or "").lower().strip()
    if len(low) < 8:
        return False
    tags = (analysis or {}).get("tags") or []
    has_biz = bool(tags)          # 代码识别出的产品/询盘/数量/交易/决策信号
    if direction == "in":
        # 先要求有业务信号(挡掉“Hi, how are you”这类寒暄),再看像不像提问/要求。
        # 注意:请求词要放宽 —— “please send me the quotation”没有问号,但绝对是需求。
        if not has_biz:
            return False
        return any(h in low for h in _QUESTION_HINTS)
    # 我方消息:像承诺但代码写不出天数的(语义不明,交给 AI 认)
    sug = (analysis or {}).get("suggestion")
    if sug and not sug.get("days"):
        return True
    return False


_CLS_SYS = (
    "你是外贸业务助理。判断这条消息里有没有【待办】,并概括出来。\n"
    "分类只能三种:\n"
    "- promise:【我方】(我司/业务员)答应了客户要做什么(报价/寄样/发资料/安排…)\n"
    "- question:【客户】在提问或提要求(要报价/要尺寸/要方案/问交期…)\n"
    "- none:只是寒暄、确认、闲聊,或只是背景信息\n"
    "注意:说话人方向由输入里的【谁说的】决定,不要自己猜。\n"
    "promise 字段(**promise 和 question 两种都要填**):用**不超过 25 个汉字**说清"
    "『这件事是什么』(例:“报价”“寄样”“提供CAD图纸”“确认交期”)。可以留空**只限** kind=none。\n"
    '只输出 JSON:{"kind":"promise","promise":"提供CAD图纸"}'
)


def classify(text, direction="in"):
    """让本地模型判断这条消息。返回 {"kind":..., "promise":...}。

    已踩坑:模型会把**客户**说的“can you send me the quotation”也判成 promise。
    所以:①告诉它谁说的话题;②代码再按方向归一化。
    """
    who = "客户发来的" if direction == "in" else "我方发出的"
    try:
        out = ai_mod._call_api([
            {"role": "system", "content": _CLS_SYS},
            {"role": "user", "content": "【" + who + "】\n" + (text or "")[:600]},
        ])
    except Exception:
        return {"kind": "", "promise": ""}
    if isinstance(out, list):
        out = out[0] if out and isinstance(out[0], dict) else {}
    if not isinstance(out, dict):
        return {"kind": "", "promise": ""}
    kind = str(out.get("kind") or "").strip().lower()
    promise = str(out.get("promise") or "").strip()[:40]
    if kind not in ("promise", "question", "none"):
        kind = ""
    # 按方向归一化:客户的话不可能是我方承诺;我方的话既可能是承诺、也可能是在等客户回
    if kind == "promise" and direction == "in":
        kind = "question"
    if not kind and promise and direction == "in":
        kind = "question"
    return {"kind": kind, "promise": promise}


def _fallback_summary(text, direction):
    """模型没给摘要时的代码兜底 —— 绝不因为“摘要为空”就把一条真待办丢掉。"""
    low = (text or "").lower()
    for pat, label in ((r"报价|价格|quote|price|quotation|offer", "报价"),
                       (r"样品|样板|sample|swatch", "寄样"),
                       (r"cad|图纸|design|方案|效果图|render", "设计图纸/方案"),
                       (r"交期|货期|lead time|delivery|什么时候", "交期"),
                       (r"尺寸|size|measure|毫米|mm|cm", "尺寸确认"),
                       (r"付款|定金|deposit|payment", "付款条件"),
                       (r"视频|图片|photo|video|picture", "图片/视频资料")):
        if re.search(pat, low):
            return label
    t = re.sub(r"\s+", " ", (text or "")).strip()
    return (t[:22] + ("…" if len(t) > 22 else "")) or ("客户提问" if direction == "in" else "我方承诺")


def apply_result(customer_id, direction, content, ts, res, msg_id=None):
    """按 AI 判断归档:承诺 → 承诺审批;客户提问 → 直接进待跟进;拿不准 → 交 PM 审批。"""
    kind = (res.get("kind") or "").strip().lower()
    promise = (res.get("promise") or "").strip()
    if kind == "none" or not kind:
        # AI 拿不准(能进队列 = 已有业务信号)→ 冒出来给 PM 审批,并留痕日志(方便调模型)
        summary = promise or _fallback_summary(content, direction) or (content or "")[:40]
        db.add_reminder(customer_id, "客户提问", "❓待PM确认:" + summary,
                        days=None, status=db.R_SUGGESTED,
                        quote=(content or "")[:300], src_ts=ts or "",
                        src_direction=direction, auto="ai", src_msg_id=msg_id,
                        decided_by="review")
        db.add_ai_log(customer_id, "classify_unclear", "unclear",
                      (content or "")[:200], "unclear",
                      detail="代码+AI 都拿不准(有业务信号),交 PM 审批")
        return "待PM审批"
    if not promise:
        promise = _fallback_summary(content, direction)
    if kind == "promise" and direction == "out":
        db.add_reminder(customer_id,
                        rules.kind_of("out", (promise or "") + " " + (content or "")),
                        "我方承诺:" + promise, days=None, status=db.R_SUGGESTED,
                        quote=(content or "")[:300], src_ts=ts or "",
                        src_direction=direction, auto="ai", src_msg_id=msg_id,
                        decided_by="ai")
        return "承诺审批"
    if kind == "question" and direction == "in":
        # 客户提问 → 直接进待跟进,标「系统直判」,2 天后提醒
        from datetime import date, timedelta
        rid = db.add_reminder(customer_id,
                              rules.kind_of("in", (promise or "") + " " + (content or "")),
                              "客户要求:" + promise,
                              days=None, status=db.R_APPROVED,
                              notify_date=(date.today() + timedelta(days=2)).isoformat(),
                              quote=(content or "")[:300], src_ts=ts or "",
                              src_direction=direction, auto="ai", src_msg_id=msg_id,
                              decided_by="ai")
        # 时序补丁:待跟进是异步才创建的,可能错过“我方已回复”那一刻 —— 立刻补扫一次
        try:
            from . import followcheck
            followcheck.code_scan(customer_id=customer_id)
        except Exception as e:
            log.swallow("aiworker.py:146", e)
        return "待跟进"
    return ""


def _is_quote(promise, content):
    s = (promise or "") + (content or "")[:200]
    return bool(re.search(r"报价|价格|quote|price|quotation", s, re.I))


def run_once():
    """处理一条队列消息。返回 True 表示处理了东西。

    流程:① 渐进上下文(纯代码)先试 → 要素齐就直接建档,**不调 AI**;
          ② 不齐 → 把**扩好的窗口**(不是单句)交给本地 AI 再判。
    """
    item = db.next_queued_msg()
    if not item:
        return False
    cid = item["customer_id"]
    direction = item.get("direction") or "in"
    content = item.get("content") or ""
    ts = item.get("ts")
    ai_on = ai_mod.enabled() and ai_mod.usage()["left"] > 0

    # ① 渐进上下文(代码)
    r = None
    try:
        from . import ctx
        r = ctx.resolve(cid, item["mid"], content, direction, ts)
    except Exception:
        r = None

    kind = promise = ""
    where = ""
    if r and r.get("complete"):
        e = r["elements"]
        what = _fallback_summary(r.get("text") or content, direction)
        days = e.get("days")
        promise = what
        if direction == "out":
            kind = "promise"
            db.add_reminder(cid,
                            rules.kind_of("out", (promise or "") + " " + (content or "")),
                            "我方承诺:%s · %s 天内" % (what, days), days=days,
                            status=db.R_SUGGESTED, quote=content[:300],
                            src_ts=ts or "", src_direction=direction, auto="ai",
                            src_msg_id=item["mid"], decided_by="code")
            where = "承诺审批"
        else:
            kind = "question"
            from datetime import date, timedelta
            db.add_reminder(cid, rules.kind_of("in", (promise or "") + " " + (content or "")),
                            "客户要求:%s · %s 天内" % (what, days),
                            days=days, status=db.R_APPROVED,
                            notify_date=(date.today() + timedelta(days=days)).isoformat(),
                            quote=content[:300], src_ts=ts or "",
                            src_direction=direction, auto="ai",
                            src_msg_id=item["mid"], decided_by="code")
            where = "待跟进"
        # 建档后补扫“我方是否已回复”
        try:
            from . import followcheck
            followcheck.code_scan(customer_id=cid)
        except Exception as e:
            log.swallow("aiworker.py:210", e)

    # ② 代码搞不定 → 本地 AI(带上扩好的窗口)
    if not where:
        if not ai_on:
            db.finish_queued(item["qid"], "skipped", "", "")
            return True
        window_text = ((r or {}).get("text") or content)[-1400:]
        res = classify(window_text, direction)
        kind, promise = res.get("kind") or "", res.get("promise") or ""
        where = apply_result(cid, direction, content, ts, res, msg_id=item.get("mid"))

    db.finish_queued(item["qid"], "done" if where else "skipped", kind, promise)
    if where:
        from . import profile
        try:
            profile.enrich_customer(cid)
        except Exception as e:
            log.swallow("aiworker.py:228", e)
    return True


_thread = None
_stop = False


# 同一条消息最多重试几次(超过就标 error 离开队列)
# 【教训】以前 run_once 报错 → 循环只 sleep 就重试同一条 → 18 小时把本地模型跑满 CPU
MAX_ATTEMPTS = 3


def _loop():
    while not _stop:
        try:
            if db.queue_stats()["pending"] > 0:
                try:
                    did = run_once()
                except Exception:
                    # 单条消息出错 → 记一次尝试;超过上限就标 error,绝不无限重试
                    q = db.next_queued_msg()
                    if q:
                        n = db.bump_queue_attempt(q["qid"])
                        if n >= MAX_ATTEMPTS:
                            db.finish_queued(q["qid"], "error", "", "")
                    time.sleep(POLL_SECONDS)
                    continue
                if not did:
                    time.sleep(POLL_SECONDS)   # 取不到东西也别空转
                continue
            from . import followcheck
            # 兜底:定期跑代码层(纯代码、瞬间、零成本)—— 不依赖“我方发消息”那一瞬
            try:
                followcheck.code_scan()
            except Exception as e:
                log.swallow("aiworker.py:264", e)
            # 队列空了 → 顺手做"待跟进自动关闭"的第 2 层(AI 确认)
            rid = followcheck.next_ai_candidate()
            if rid is not None:
                followcheck.ai_confirm(rid)
                continue
            time.sleep(POLL_SECONDS)
        except Exception:
            time.sleep(POLL_SECONDS)


def start_background():
    """启动后台 worker(幂等)。"""
    global _thread
    if _thread and _thread.is_alive():
        return
    _thread = threading.Thread(target=_loop, daemon=True)
    _thread.start()


def stats():
    s = db.queue_stats()
    s["running"] = bool(_thread and _thread.is_alive())
    s["ai_enabled"] = ai_mod.enabled()
    return s
