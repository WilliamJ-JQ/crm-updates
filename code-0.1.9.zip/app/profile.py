# -*- coding: utf-8 -*-
"""客户档案自动推导引擎 —— 纯代码,零 token,零模型调用。

从聊天记录里推导:
  - 身份(业主/建筑商/中介/设计师/采购商)
  - 地区 / 时区
  - 跟进内容分类(等待确认/挑款式/待出方案/待报价/待付款/待发货)
  - 客户分级 A/B/C(可付款周期)
  - 下次跟进日期(按分级节奏)

全部是关键词匹配 + 确定性计算。拿不准的字段留"未识别/未分级",由老板手动改。
以后若要更强的语义理解,再单独开"AI 增强"(默认关闭,才产生 token 成本)。
"""
import re
from datetime import date, datetime, timedelta

from . import ai, db
from . import log


def _hit(text, term):
    t = term.strip().lower()
    if not t:
        return False
    if any("\u4e00" <= ch <= "\u9fff" for ch in t) or " " in t:
        return t in text
    # 英文单词整词匹配(兼容复数,避免 ready 撞进 already)
    return re.search(r"(?<![a-z])" + re.escape(t) + r"s?(?![a-z])", text) is not None


# ---- 身份 ----
IDENTITY_RULES = [
    ("设计师", ["designer", "interior design", "architect", "architecture",
              "design studio", "设计", "室内设计", "建筑师", "设计公司"]),
    ("建筑商", ["contractor", "builder", "construction company", "developer",
              "总包", "施工方", "建筑商", "承建", "开发商", "工程公司"]),
    ("中介", ["agent", "broker", "intermediary", "sourcing agent", "buying agent",
              "中介", "代理采购", "贸易商", "trader", "中间商"]),
    ("采购商", ["buyer", "purchasing manager", "procurement", "importer", "进口商",
              "wholesale", "批发", "distributor", "采购", "采购商"]),
    ("业主", ["landlord", "my house", "my villa", "my home", "my apartment",
              "my own house", "我自己的房子", "业主", "自建房", "我的别墅",
              "装修自己", "my property"]),
]


def _sentences(text):
    return re.split(r"[.!?\n;；。！？]+", text or "")


# 自我介绍标记:只在带这些词的句子里识别身份,避免"我想要你们的designer"被误判
_SELF = ["i am", "i'm", "i run", "i own", "i have a", "we are", "we're",
         "we run", "we own", "our company", "my company", "my business",
         "我是", "我们是", "我们公司", "我公司", "我方", "我们这边", "本人", "自家",
         "我们是一家", "我是一家"]


def detect_identity(text):
    low = (text or "").lower()
    # 只考察"自我介绍句"(含第一人称/自称标记)
    pool = [s for s in _sentences(low) if any(m in s for m in _SELF)]
    for identity, words in IDENTITY_RULES:
        for s in pool:
            matched = [w for w in words if _hit(s, w)]
            if matched:
                return identity, matched
    return None, []


# ---- 地区 / 时区 ----
REGIONS = [
    ("加纳", ["ghana", "加纳"]),
    ("尼日利亚", ["nigeria", "尼日利亚"]),
    ("肯尼亚", ["kenya", "肯尼亚"]),
    ("阿联酋/迪拜", ["dubai", "uae", "united arab emirates", "阿联酋", "迪拜"]),
    ("沙特", ["saudi", "ksa", "沙特"]),
    ("卡塔尔", ["qatar", "卡塔尔"]),
    ("美国", ["usa", "united states", "america", "美国"]),
    ("英国", ["united kingdom", "london", "英国", "伦敦"]),
    ("澳大利亚", ["australia", "澳洲", "澳大利亚"]),
    ("加拿大", ["canada", "加拿大"]),
    ("菲律宾", ["philippines", "菲律宾"]),
    ("印度", ["india", "印度"]),
    ("巴基斯坦", ["pakistan", "巴基斯坦"]),
    ("南非", ["south africa", "南非"]),
    ("埃及", ["egypt", "埃及"]),
    ("摩洛哥", ["morocco", "摩洛哥"]),
    ("阿尔及利亚", ["algeria", "阿尔及利亚"]),
]

TIMEZONE_MAP = {
    "加纳": "Africa/Accra", "尼日利亚": "Africa/Lagos", "肯尼亚": "Africa/Nairobi",
    "阿联酋/迪拜": "Asia/Dubai", "沙特": "Asia/Riyadh", "卡塔尔": "Asia/Qatar",
    "美国": "America/New_York", "英国": "Europe/London",
    "澳大利亚": "Australia/Sydney", "加拿大": "America/Toronto",
    "菲律宾": "Asia/Manila", "印度": "Asia/Kolkata", "巴基斯坦": "Asia/Karachi",
    "南非": "Africa/Johannesburg", "埃及": "Africa/Cairo",
    "摩洛哥": "Africa/Casablanca", "阿尔及利亚": "Africa/Algiers",
}

# 电话国家码 → (地区, 时区)。长前缀优先(避免 +1 吃掉 +1809 之类)
PHONE_REGIONS = [
    ("+233", "加纳", "Africa/Accra"),
    ("+234", "尼日利亚", "Africa/Lagos"),
    ("+254", "肯尼亚", "Africa/Nairobi"),
    ("+255", "坦桑尼亚", "Africa/Dar_es_Salaam"),
    ("+256", "乌干达", "Africa/Kampala"),
    ("+250", "卢旺达", "Africa/Kigali"),
    ("+260", "赞比亚", "Africa/Lusaka"),
    ("+263", "津巴布韦", "Africa/Harare"),
    ("+258", "莫桑比克", "Africa/Maputo"),
    ("+244", "安哥拉", "Africa/Luanda"),
    ("+237", "喀麦隆", "Africa/Douala"),
    ("+225", "科特迪瓦", "Africa/Abidjan"),
    ("+221", "塞内加尔", "Africa/Dakar"),
    ("+27", "南非", "Africa/Johannesburg"),
    ("+20", "埃及", "Africa/Cairo"),
    ("+212", "摩洛哥", "Africa/Casablanca"),
    ("+213", "阿尔及利亚", "Africa/Algiers"),
    ("+216", "突尼斯", "Africa/Tunis"),
    ("+218", "利比亚", "Africa/Tripoli"),
    ("+971", "阿联酋/迪拜", "Asia/Dubai"),
    ("+966", "沙特", "Asia/Riyadh"),
    ("+974", "卡塔尔", "Asia/Qatar"),
    ("+965", "科威特", "Asia/Kuwait"),
    ("+968", "阿曼", "Asia/Muscat"),
    ("+973", "巴林", "Asia/Bahrain"),
    ("+962", "约旦", "Asia/Amman"),
    ("+961", "黎巴嫩", "Asia/Beirut"),
    ("+964", "伊拉克", "Asia/Baghdad"),
    ("+90", "土耳其", "Europe/Istanbul"),
    ("+92", "巴基斯坦", "Asia/Karachi"),
    ("+91", "印度", "Asia/Kolkata"),
    ("+880", "孟加拉", "Asia/Dhaka"),
    ("+94", "斯里兰卡", "Asia/Colombo"),
    ("+60", "马来西亚", "Asia/Kuala_Lumpur"),
    ("+65", "新加坡", "Asia/Singapore"),
    ("+62", "印尼", "Asia/Jakarta"),
    ("+63", "菲律宾", "Asia/Manila"),
    ("+66", "泰国", "Asia/Bangkok"),
    ("+84", "越南", "Asia/Ho_Chi_Minh"),
    ("+86", "中国", "Asia/Shanghai"),
    ("+852", "中国香港", "Asia/Hong_Kong"),
    ("+853", "中国澳门", "Asia/Macau"),
    ("+886", "中国台湾", "Asia/Taipei"),
    ("+81", "日本", "Asia/Tokyo"),
    ("+82", "韩国", "Asia/Seoul"),
    ("+61", "澳大利亚", "Australia/Sydney"),
    ("+64", "新西兰", "Pacific/Auckland"),
    ("+44", "英国", "Europe/London"),
    ("+353", "爱尔兰", "Europe/Dublin"),
    ("+33", "法国", "Europe/Paris"),
    ("+34", "西班牙", "Europe/Madrid"),
    ("+39", "意大利", "Europe/Rome"),
    ("+49", "德国", "Europe/Berlin"),
    ("+31", "荷兰", "Europe/Amsterdam"),
    ("+32", "比利时", "Europe/Brussels"),
    ("+41", "瑞士", "Europe/Zurich"),
    ("+43", "奥地利", "Europe/Vienna"),
    ("+48", "波兰", "Europe/Warsaw"),
    ("+30", "希腊", "Europe/Athens"),
    ("+7", "俄罗斯", "Europe/Moscow"),
    ("+380", "乌克兰", "Europe/Kyiv"),
    ("+40", "罗马尼亚", "Europe/Bucharest"),
    ("+351", "葡萄牙", "Europe/Lisbon"),
    ("+46", "瑞典", "Europe/Stockholm"),
    ("+47", "挪威", "Europe/Oslo"),
    ("+45", "丹麦", "Europe/Copenhagen"),
    ("+358", "芬兰", "Europe/Helsinki"),
    ("+52", "墨西哥", "America/Mexico_City"),
    ("+55", "巴西", "America/Sao_Paulo"),
    ("+54", "阿根廷", "America/Argentina/Buenos_Aires"),
    ("+56", "智利", "America/Santiago"),
    ("+57", "哥伦比亚", "America/Bogota"),
    ("+51", "秘鲁", "America/Lima"),
    ("+1", "美国", "America/New_York"),
]


def normalize_phone(phone):
    """把 WhatsApp 号码规范化成 +国家码数字 形式。"""
    p = (phone or "").strip()
    if not p:
        return ""
    p = p.split("@")[0]                     # 去掉 @s.whatsapp.net
    p = re.sub(r"[^\d+]", "", p)
    if p.startswith("00"):
        p = "+" + p[2:]
    if not p.startswith("+"):
        p = "+" + p
    return p


def region_by_phone(phone):
    """由电话号码判断 (地区, 时区)。认不出返回 (None, None)。"""
    p = normalize_phone(phone)
    if not p:
        return None, None
    best = None
    for code, region, tz in PHONE_REGIONS:
        if p.startswith(code) and (best is None or len(code) > len(best[0])):
            best = (code, region, tz)
    return (best[1], best[2]) if best else (None, None)


def detect_region(text):
    low = (text or "").lower()
    for canonical, aliases in REGIONS:
        if any(a in low for a in aliases):
            return canonical
    return None


def timezone_for(region, phone):
    if region and region in TIMEZONE_MAP:
        return TIMEZONE_MAP[region]
    return region_by_phone(phone)[1]


# ---- 跟进内容分类(按销售阶段从后往前) ----
FOLLOWUP_RULES = [
    ("待发货", ["发货", "交货", "deliver", "ship", "shipment", "物流", "货期", "eta"]),
    ("待客户付款", ["付款", "payment", "deposit", "定金", "balance", "尾款",
                 "invoice", "发票", "paid"]),
    ("待我报价", ["报价", "quote", "quotation", "price", "价格", "offer", "pi",
               "proforma", "发价格"]),
    ("待我出方案/搭配", ["方案", "设计", "design", "proposal", "搭配", "mood board",
                     "效果图", "3d", "layout", "平面图", "render", "图纸"]),
    ("挑选款式", ["款式", "花色", "颜色", "样式", "sample", "catalog", "choose",
               "select", "color", "style", "pattern", "系列", "选"]),
    ("等待客户确认", ["确认", "confirm", "approve", "agreed", "revert", "check",
                  "考虑", "think", "review", "再看看", "verify", "反馈"]),
]


def classify_followup(text):
    low = (text or "").lower()
    for category, words in FOLLOWUP_RULES:
        if any(_hit(low, w) for w in words):
            return category
    return None


# ---- 分级 A/B/C ----
A_SIGNALS = ["this month", "this week", "asap", "as soon as possible", "urgent",
             "ready", "budget approved", "approved", "ready to order", "order now",
             "place order", "定金", "本月", "这个月", "马上", "尽快", "立即", "下单"]
C_SIGNALS = ["next year", "明年", "long term", "未来", "in the future", "not sure",
             "just looking", "了解一下", "先了解", "先看看", "planning", "计划中",
             "one year", "later phase", "不着急"]
B_SIGNALS = ["project", "项目", "construction", "施工", "tender", "招标", "phase",
             "阶段", "分期", "contract", "合同", "resort", "hotel", "酒店", "度假村"]


def suggest_grade(messages):
    a = b = c = 0
    a_hit = b_hit = c_hit = []
    for m in messages:
        if m.get("direction") != "in":
            continue          # 只看客户说的话,不被我方措辞带偏
        low = (m["content"] or "").lower()
        for w in A_SIGNALS:
            if _hit(low, w):
                a += 1
                a_hit = a_hit + [w] if len(a_hit) < 4 else a_hit
        for w in C_SIGNALS:
            if _hit(low, w):
                c += 1
                c_hit = c_hit + [w] if len(c_hit) < 4 else c_hit
        for w in B_SIGNALS:
            if _hit(low, w):
                b += 1
                b_hit = b_hit + [w] if len(b_hit) < 4 else b_hit
    if a:
        return "A", "命中A信号:" + "、".join(a_hit)
    if c:
        return "C", "命中C信号:" + "、".join(c_hit)
    if b:
        return "B", "命中B信号:" + "、".join(b_hit)
    return None, ""


def compute_next_followup(grade, last_contact):
    """按分级节奏算下次跟进日期(YYYY-MM-DD)。"""
    if grade not in ("A", "B", "C") or not last_contact:
        return None
    d = str(last_contact)[:10]
    try:
        base = date.fromisoformat(d)
    except ValueError:
        return None
    return (base + timedelta(days=db.grade_cadence(grade))).isoformat()


def enrich_customer(customer_id):
    """根据该客户的聊天记录,自动推导并写回档案字段(零 token)。"""
    customer = db.get_customer(customer_id)
    if not customer:
        return None
    msgs = db.list_messages(customer_id=customer_id)
    if not msgs:
        return customer

    updates = {}
    last = msgs[-1]
    updates["last_contact_at"] = last["ts"]

    # 身份:只当现在是"未识别"时,从客户发来的消息里推
    if (customer.get("identity") or "未识别") in ("未识别", "", None):
        for m in msgs:
            if m["direction"] == "in":
                ident, matched = detect_identity(m["content"])
                if ident:
                    updates["identity"] = ident
                    break

    # 地区:优先聊天正文,其次电话国家码(WhatsApp 号码本身就能判断国家/时区)
    region = (customer.get("country") or "").strip()
    if not region:
        for m in msgs:
            if m["direction"] == "in":
                r = detect_region(m["content"])
                if r:
                    region = r
                    break
    phone_region, phone_tz = region_by_phone(customer.get("phone") or "")
    if not region and phone_region:
        region = phone_region
    if region and region != (customer.get("country") or "").strip():
        updates["country"] = region

    # 时区:由地区推,其次电话国家码
    if not (customer.get("timezone") or "").strip():
        tz = timezone_for(region, customer.get("phone") or "") or phone_tz
        if tz:
            updates["timezone"] = tz

    # 跟进分类:取最新一条命中的分类(最新状态)
    latest_cat = None
    for m in msgs:
        cat = classify_followup(m["content"])
        if cat:
            latest_cat = cat
    if latest_cat and latest_cat != customer.get("followup_category"):
        updates["followup_category"] = latest_cat
        updates["followup_reason"] = _last_hit_sentence(msgs, latest_cat)

    # 看板阶段:根据聊天自动往前推(永不倒退,手动推过的不会被拉回)
    stage, stage_reason = suggest_stage(msgs)
    if stage and _stage_index(stage) > _stage_index(customer.get("stage")):
        updates["stage"] = stage
        updates["stage_reason"] = stage_reason

    # 意向产品:从聊天里出现最多、且靠谱的产品词(≥2 次才写,避免噪声)
    prod = derive_product(msgs)
    if prod and prod != (customer.get("product") or "").strip():
        updates["product"] = prod

    # 分级:只在"未分级"时自动建议,避免覆盖你的手动分级
    if (customer.get("grade") or "未分级") == "未分级":
        grade, reason = suggest_grade(msgs)
        if grade:
            updates["grade"] = grade
            updates["grade_reason"] = reason

    # 下次跟进日期:按分级节奏
    effective_grade = updates.get("grade") or customer.get("grade") or "未分级"
    nf = compute_next_followup(effective_grade, updates.get("last_contact_at")
                               or customer.get("last_contact_at"))
    if nf:
        updates["next_followup_at"] = nf

    # 先落代码能定的字段
    if updates:
        customer = db.apply_profile(customer_id, **updates)

    # AI 增强:代码认不出的,交给 AI(受每日上限 + 每人每日一次约束)
    unresolved = []
    if (customer.get("identity") or "未识别") in ("未识别", "", None):
        unresolved.append("identity")
    if not (customer.get("followup_category") or ""):
        unresolved.append("followup")
    if (customer.get("grade") or "未分级") == "未分级":
        unresolved.append("grade")
    if (unresolved and ai.enabled() and ai.usage()["left"] > 0
            and not db.ai_tried_today(customer_id)):
        ai.process_customer(customer_id)
        customer = db.get_customer(customer_id)
    return customer


# ---------- 看板阶段:根据聊天自动推进 ----------

# 看板阶段(与 db.STAGES 同序):新询盘 → 方案讨论中 → 报价中 → 谈价中 → 生产中 → 交付中
# 从“越往后”往前匹配:先命中交付/生产,再谈价/方案/报价。
_STAGE_RULES = [
    ("交付中", r"(?i)\b(deliver\w*|shipment|shipped|shipping|bill of lading|b/?l\b|"
              r"customs|clearance|container|purchase order|order confirmed|"
              r"deposit (paid|received)|paid the deposit|proforma invoice|pi signed)\b|"
              r"(发货|出货|装柜|到港|清关|提单|物流|交付|下单|订单已|定金已|已付定金|合同已签)"),
    ("生产中", r"(?i)\b(production|produce|manufactur\w*|in the factory|"
              r"factory (visit|audit|inspection)|audit our factory)\b"
              r"|(生产|排产|投产|产线|打样完成|验厂|看厂|审厂|参观工厂)"),
    ("谈价中", r"(?i)\b(discount|negotiat\w*|payment terms|deposit|t/?t\b|l/?c\b)\b"
              r"|(折扣|谈判|账期|付款方式|定金|谈价|价格太高)"),
    ("方案讨论中", r"(?i)\b(samples?|swatch|mock-?up|courier|design|drawing|layout|3d)\b"
                r"|(方案|设计|图纸|寄样|样板|打样|样品)"),
    ("报价中", r"(?i)\b(quotation|quote|quotes|pricing|price list|offer)\b|(报价|价格表|报价单)"),
]



def _stage_index(stage):
    try:
        return db.STAGES.index(stage or "")
    except ValueError:
        return 0


def suggest_stage(msgs):
    """根据聊天记录推出看板阶段。返回 (stage, 依据句子);推不出返回 (None, "")。

    只往前走:调用方会比较阶段序号,不倒退(不覆盖你手动推进的结果)。
    """
    best = None
    quote = ""
    for stage, pat in _STAGE_RULES:
        for m in msgs or []:
            content = m.get("content") or ""
            if re.search(pat, content):
                if best is None or _stage_index(stage) > _stage_index(best):
                    best, quote = stage, content.strip()[:120]
                break
    return best, quote


def derive_product(msgs, min_hits=2, top=3):
    """意向产品:从词表里找出现最多且达到 min_hits 的产品词。

    为什么要设门槛:只提一次的产品很可能是随口一说,写到档案上反而误导。
    """
    try:
        terms = db.get_group_terms("product_terms")
    except Exception:
        return ""
    if not terms:
        return ""
    low = " \n ".join((m.get("content") or "").lower() for m in (msgs or []))
    if not low.strip():
        return ""
    from . import rules as _rules
    counts = []
    for t in terms:
        t = (t or "").strip()
        if not t:
            continue
        try:
            n = len(re.findall(r"(?<![a-z0-9])" + re.escape(t.lower()) + r"s?(?![a-z0-9])", low)) \
                if not _rules._is_cjk(t) else low.count(t.lower())
        except re.error:
            n = low.count(t.lower())
        if n >= min_hits:
            counts.append((n, t))
    if not counts:
        return ""
    counts.sort(key=lambda x: -x[0])
    return " / ".join(t for _, t in counts[:top])


def _last_hit_sentence(msgs, category):
    """找出导致某个跟进分类的那句原话(供界面"为什么是这个分类"用)。"""
    for m in reversed(msgs or []):
        content = m.get("content") or ""
        if classify_followup(content) == category:
            return content.strip()[:160]
    return ""


def days_since(value):
    """距今天数;解析不了返回 None。"""
    s = (value or "")[:10]
    if not s:
        return None
    try:
        return (date.today() - date.fromisoformat(s)).days
    except ValueError:
        return None


def followup_reason(customer):
    """这条推荐跟进到底为什么推?返回 (reason, quote)。优先级:

      1) 承诺到点 —— 已批准且到期的提醒(附提醒里的原话引用)
      2) 太久没联系 —— 距上次已超过该分级节奏
      3) 客户在等回复 —— 最后一条是客户发的
    没有理由就返回 ("", "")。
    """
    cid = customer.get("id")
    today = date.today().isoformat()
    # 1) 承诺到点
    try:
        for r in db.list_reminders(status=db.R_APPROVED):
            if r.get("customer_id") == cid and (r.get("notify_date") or "") <= today:
                q = (r.get("quote") or "").strip() or (r.get("note") or "")
                return "承诺到点:%s" % (r.get("kind") or "跟进"), q
    except Exception as e:
        log.swallow("profile.py:505", e)
    # 2) 太久没联系
    grade = customer.get("grade") or "未分级"
    cadence = db.grade_cadence(grade) if grade in ("A", "B", "C") else None
    gap = days_since(customer.get("last_contact_at"))
    if cadence and gap is not None and gap > cadence:
        last = db.last_message(cid)          # 按时间取最新,不按 id(导入的旧消息 id 很大)
        q = (dict(last).get("content") or "")[:160] if last else ""
        return ("太久没联系:距上次 %d 天(%s 级节奏 %d 天)" % (gap, grade, cadence)), q
    # 3) 客户在等回复
    try:
        last = db.last_message(cid)
        if last and dict(last).get("direction") == "in":
            return "客户在等回复", (dict(last).get("content") or "")[:160]
    except Exception as e:
        log.swallow("profile.py:520", e)
    return "", ""


def due_text_for(need, quote=""):
    """限时规则:报价类 2 日内;Catalog/产品知识/方案类 当日完成。

    卡片写“客户名 + 需求 + 限时”,不用在下面重复客户名/还有几天。
    """
    t = ("%s %s" % (need or "", quote or "")).lower()
    if re.search(r"price|quote|quotation|报价", t):
        return "2 日内"
    if re.search(r"catalog|产品|方案|design|drawing|图纸|sample|样品|色卡", t):
        return "当日完成"
    return "2 日内"


def today_followups():
    """今日跟进清单,返回两类(都带 done 标记):

      - done=False —— 今日待跟进:已分级且 next_followup_at <= 今天(含逾期)
      - done=True  —— 已跟进:今天已经有往来(last_contact_at 是今天)

    排序:A→B→C;待跟进在前。前端直接按 done 分两栏展示。
    """
    today = date.today().isoformat()
    order = {"A": 0, "B": 1, "C": 2, "未分级": 3, "": 3}
    # 哪些客户有“已批准”的承诺提醒 → 卡片上显示“需求+限时”,并可延时一天
    rem_by_cust = {}
    try:
        for r in db.list_reminders(status=db.R_APPROVED):
            rem_by_cust.setdefault(r.get("customer_id"), r)
    except Exception as e:
        log.swallow("profile.py:553", e)
    pend, done = [], []
    for c in db.list_customers():
        last = (c.get("last_contact_at") or "")[:10]
        nxt = c.get("next_followup_at") or ""
        if last == today:
            row = dict(c)
            row["done"] = True
            row.setdefault("note", c.get("followup_category") or "今天已联系")
            row["reason"], row["quote"] = "今天已联系", ""
            done.append(row)
            continue
        # 待跟进:到期 或 太久没联系(两个理由都算)
        due = bool(nxt and nxt <= today and c.get("grade") in ("A", "B", "C"))
        reason, quote = followup_reason(c)
        stale = reason.startswith("太久没联系") or reason == "客户在等回复"
        # 严格:没真实往来的客户不推(避免把“只建了群、还没聊过”的列进来)
        if stale and int(c.get("msg_count") or 0) < 3:
            stale = False
        if due or stale:
            row = dict(c)
            row["done"] = False
            row["note"] = c.get("followup_category") or "待跟进"
            _r = rem_by_cust.get(c.get("id")) or {}
            if _r.get("id"):
                row["reminder_id"] = _r["id"]
                _n = (_r.get("note") or "")
                for _p in ("客户要求:", "我方承诺:", "客户要报价:"):
                    if _n.startswith(_p):
                        _n = _n[len(_p):]
            
                row["need_text"] = _n
                row["notify_date"] = _r.get("notify_date") or ""
                row["due_text"] = due_text_for(_n, _r.get("quote") or "")
            if not row.get("due_text"):
                row["due_text"] = due_text_for(row.get("followup_category") or "",
                                               row.get("quote") or "")
            row["reason"] = reason or ("跟进到点 · 按%s级节奏" % (c.get("grade") or "?"))
            row["quote"] = quote
            if due and nxt and nxt < today:
                row["reason"] += " · 已逾期 %d 天" % max(0, days_since(nxt) or 0)
            pend.append(row)
    pend.sort(key=lambda c: (order.get(c.get("grade"), 3),
                             c.get("next_followup_at") or ""))
    done.sort(key=lambda c: order.get(c.get("grade"), 3))
    # 今日推荐要“严格”:每天最多 15 条(设置 rec_daily_max 可改),A→B→C→未分级
    try:
        cap = int(db.get_setting("rec_daily_max", "15") or 15)
    except (ValueError, TypeError):
        cap = 15
    return pend[:max(1, cap)] + done
