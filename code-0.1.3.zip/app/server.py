# -*- coding: utf-8 -*-
"""本地 Web 服务:只监听 127.0.0.1,给操作台界面提供数据(JSON API)。

安全边界:
 - 只绑定本机回环地址,局域网/外网都访问不到;
 - 当前版本没有任何"发给客户"的通道 —— 所有接口只读、只写本地库、只生成建议。
"""
import json
import os
import re
import subprocess
import sys
import threading
import time
import webbrowser
from datetime import date, datetime, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

from . import ai, aiworker, brief, chatimport, db, docs, followcheck, notify, profile, profile_doc, rules, service
from . import log
from . import wa_official
from . import autoimport
from . import updater
from .version import APP_VERSION

HOST = "127.0.0.1"
DEFAULT_PORT = 8765
UI_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ui", "index.html")


def _json(obj):
    return json.dumps(obj, ensure_ascii=False).encode("utf-8")


# WhatsApp 标签名 → 客户分级(A/B/C)。只认明确的写法,不做臆测。
_GRADE_KEYS = [("A", ("a级", "a类", "a 级", "重点", "vip")),
               ("B", ("b级", "b类", "b 级", "次重点")),
               ("C", ("c级", "c类", "c 级", "普通"))]


def _grade_from_labels(names):
    """从标签名字里读出分级:名字是 A/B/C(或 A级/B级/C级、含“重点”等)才算。"""
    clean = [(n or "").strip() for n in names if (n or "").strip()]
    for g, keys in _GRADE_KEYS:
        for n in clean:
            low = n.lower()
            if n.upper() == g or low in keys or any(k in low for k in keys):
                return g
    return ""


def _route_parts(path):
    return [p for p in path.split("?")[0].split("/") if p]


class Api(BaseHTTPRequestHandler):
    server_version = "CustomerDesk/0.1"

    # ---- 基础工具 ----

    def log_message(self, *args):
        pass  # 安静运行,不刷日志

    def _send(self, code, body, ctype="application/json; charset=utf-8"):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _ok(self, obj, code=200):
        self._send(code, _json(obj))

    def _err(self, msg, code=400):
        self._send(code, _json({"error": msg}))

    def _body(self):
        length = int(self.headers.get("Content-Length") or 0)
        if length <= 0:
            return {}
        try:
            return json.loads(self.rfile.read(length).decode("utf-8"))
        except Exception:
            return {}

    def _raw_body(self):
        """原始字节 —— 校验 Meta 签名必须用原始 body(不能先 json 再序列化)。"""
        length = int(self.headers.get("Content-Length") or 0)
        if length <= 0:
            return b""
        return self.rfile.read(length)

    def _text(self, s, code=200):
        self._send(code, str(s).encode("utf-8"), "text/plain; charset=utf-8")

    def _query(self, name, default=None):
        q = self.path.split("?", 1)
        if len(q) < 2:
            return default
        m = re.search(r"(?:^|&)" + name + r"=([^&]*)", q[1])
        return m.group(1) if m else default

    # ---- 路由 ----

    def _handle(self, method):
        parts = _route_parts(self.path)
        try:
            if not parts:
                return self._serve_ui()
            if parts[0] == "widget" and method == "GET":
                return self._serve_widget()
            if parts[0] == "api":
                return self._route_api(method, parts[1:])
            if parts[0] == "index.html" and method == "GET":
                return self._serve_ui()
            return self._err("not found", 404)
        except BrokenPipeError:
            pass
        except Exception as exc:  # 兜底:任何内部错误都以 JSON 返回,不让界面白屏
            try:
                self._err(f"server error: {exc}", 500)
            except Exception as e:
                log.swallow("server.py:108", e)

    def _serve_ui(self):
        try:
            with open(UI_FILE, "rb") as f:
                self._send(200, f.read(), "text/html; charset=utf-8")
        except FileNotFoundError:
            self._err("ui/index.html missing", 500)

    def _serve_widget(self):
        wf = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ui", "widget.html")
        try:
            with open(wf, "rb") as f:
                self._send(200, f.read(), "text/html; charset=utf-8")
        except FileNotFoundError:
            self._err("ui/widget.html missing", 500)

    def _route_api(self, method, p):
        # ---- 客户 ----
        if p and p[0] == "customers" and len(p) == 1 and method == "GET":
            q = self._query("q", "") or ""
            return self._ok({"items": db.list_customers(q or None)})
        if p and p[0] == "customers" and len(p) == 1 and method == "POST":
            data = self._body()
            if not str(data.get("name", "")).strip():
                return self._err("客户姓名(name)不能为空")
            cid = db.create_customer(data)
            return self._ok({"customer": db.get_customer(cid)}, 201)
        if (p and p[0] == "customers" and len(p) == 2 and p[1] == "recompute"
                and method == "POST"):
            n = 0
            for c in db.list_customers():
                profile.enrich_customer(c["id"])
                n += 1
            return self._ok({"recomputed": n})
        if p and p[0] == "customers" and len(p) == 2 and method == "GET":
            c = db.get_customer(int(p[1]))
            return self._ok({"customer": c}) if c else self._err("客户不存在", 404)
        if p and p[0] == "customers" and len(p) == 2 and method == "PUT":
            data = self._body()
            if data.get("move") in ("next", "prev"):
                stage = db.update_customer(int(p[1]), {}, move=data["move"])
                if stage is None:
                    return self._err("客户不存在", 404)
                return self._ok({"stage": stage})
            db.update_customer(int(p[1]), data)
            return self._ok({"customer": db.get_customer(int(p[1]))})
        if p and p[0] == "customers" and len(p) == 2 and method == "DELETE":
            db.delete_customer(int(p[1]))
            return self._ok({"deleted": True})
        # 客户消息
        if (p and p[0] == "customers" and len(p) == 3 and p[2] == "messages"
                and method == "GET"):
            q = parse_qs(urlparse(self.path).query)
            around = (q.get("around") or [""])[0].strip()
            try:
                cid = int(p[1])
            except (TypeError, ValueError):
                return self._err("客户不存在", 404)
            if around:
                try:
                    return self._ok({"items": db.list_messages(
                        customer_id=cid, around_id=int(around))})
                except (TypeError, ValueError):
                    pass
            return self._ok({"items": db.list_messages(customer_id=cid)})
        if (p and p[0] == "customers" and len(p) == 3 and p[2] == "messages"
                and method == "POST"):
            data = self._body()
            content = str(data.get("content", ""))
            if not content.strip():
                return self._err("消息内容不能为空")
            direction = "out" if str(data.get("direction", "in")) == "out" else "in"
            res = service.process_message(int(p[1]), direction, content,
                                          ts=data.get("ts"))
            if res is None:
                return self._err("客户不存在", 404)
            return self._ok(res, 201)
        if (p and p[0] == "customers" and len(p) == 3 and p[2] == "rebuild"
                and method == "POST"):
            # 重建分析:改了词表/规则后,把该客户的聊天重新跑一遍
            # (标签、提醒建议、客户文档 都重算;重复的不会重复插入)
            try:
                cid = int(p[1])
            except (TypeError, ValueError):
                return self._err("客户不存在", 404)
            if not db.get_customer(cid):
                return self._err("客户不存在", 404)
            msgs = db.list_messages(customer_id=cid, limit=5000)
            tags_n = docs_n = rem_n = 0
            for m in msgs:
                a = rules.analyze(m["content"], m["direction"])
                db.update_message_tags(m["id"], a["tags"])
                tags_n += 1
                if a["suggestion"]:
                    s = a["suggestion"]
                    db.add_reminder(cid, s["kind"], s["note"], days=s.get("days"),
                                    quote=s.get("quote", ""))
                    rem_n += 1
                if db.get_setting("docs_auto", "1") == "1":
                    docs_n += docs.extract_code_to_db(cid, m["content"],
                                                      direction=m["direction"],
                                                      msg_id=m["id"])
            profile.enrich_customer(cid)
            return self._ok({"rebuilt": len(msgs), "tagged": tags_n,
                             "doc_new": docs_n, "rem_new": rem_n})
        if (p and p[0] == "customers" and len(p) == 3 and p[2] == "profile"
                and method == "GET"):
            return self._ok({"profile": profile_doc.get(int(p[1])),
                             "sections": profile_doc.section_titles(),
                             "ai": {"enabled": ai.enabled(),
                                    "usage": ai.usage()}})
        if (p and p[0] == "customers" and len(p) == 4 and p[2] == "profile"
                and p[3] == "section" and method == "PUT"):
            # 人工修改某一节(text 为空 => 还原原稿)
            data = self._body()
            key = str(data.get("key") or "").strip()
            if not key:
                return self._err("缺少 key")
            try:
                cid = int(p[1])
            except (TypeError, ValueError):
                return self._err("客户不存在", 404)
            if data.get("revert"):
                return self._ok(profile_doc.revert_section(cid, key))
            return self._ok(profile_doc.edit_section(cid, key,
                                                     str(data.get("text") or "")))
        if (p and p[0] == "customers" and len(p) == 3 and p[2] == "profile"
                and method == "POST"):
            try:
                cid = int(p[1])
            except (TypeError, ValueError):
                return self._err("客户不存在", 404)
            if not db.get_customer(cid):
                return self._err("客户不存在", 404)
            return self._ok(profile_doc.generate(cid))
        if (p and p[0] == "customers" and len(p) == 3 and p[2] == "brief"
                and method == "GET"):
            b = brief.get(int(p[1]))
            return self._ok({"brief": b,
                             "sections": brief.SECTIONS,
                             "ai": {"enabled": ai.enabled(),
                                    "usage": ai.usage()}})
        if (p and p[0] == "customers" and len(p) == 3 and p[2] == "brief"
                and method == "POST"):
            try:
                cid = int(p[1])
            except (TypeError, ValueError):
                return self._err("客户不存在", 404)
            if not db.get_customer(cid):
                return self._err("客户不存在", 404)
            return self._ok(brief.generate(cid))
        if (p and p[0] == "customers" and len(p) == 3 and p[2] == "enrich"
                and method == "POST"):
            updated = profile.enrich_customer(int(p[1]))
            return self._ok({"customer": updated}) if updated else self._err("客户不存在", 404)
        if (p and p[0] == "customers" and len(p) == 3 and p[2] == "ai"
                and method == "POST"):
            return self._ok(ai.process_customer(int(p[1])))
        # ---- 客户文档(从对话提炼的高价值信息) ----
        if p and p[0] == "docs" and len(p) == 1 and method == "GET":
            try:
                cid = int(self._query("customer_id", "0") or 0)
            except (TypeError, ValueError):
                cid = 0
            cat = self._query("category", "") or None
            return self._ok({"items": db.list_docs(customer_id=cid or None,
                                                   category=cat),
                             "categories": db.DOC_CATEGORIES,
                             "counts": db.doc_counts()})
        if p and p[0] == "docs" and len(p) == 1 and method == "POST":
            data = self._body()
            try:
                cid = int(data.get("customer_id") or 0)
            except (TypeError, ValueError):
                cid = 0
            if not db.get_customer(cid):
                return self._err("请选择客户")
            title = str(data.get("title") or "").strip()
            if not title:
                return self._err("标题不能为空")
            did = db.add_doc(cid, str(data.get("category") or ""), title,
                             str(data.get("content") or ""),
                             quote=str(data.get("quote") or ""),
                             source="manual", dedupe=False)
            return self._ok({"doc": db.get_doc(did)}, 201)
        if p and p[0] == "docs" and len(p) == 2 and method == "GET":
            d = db.get_doc(int(p[1]))
            return self._ok({"doc": d}) if d else self._err("文档不存在", 404)
        if p and p[0] == "docs" and len(p) == 2 and method == "PUT":
            d = db.update_doc(int(p[1]), self._body())
            return self._ok({"doc": d}) if d else self._err("文档不存在", 404)
        if p and p[0] == "docs" and len(p) == 2 and method == "DELETE":
            db.delete_doc(int(p[1]))
            return self._ok({"deleted": True})
        if (p and p[0] == "customers" and len(p) == 4 and p[2] == "docs"
                and p[3] == "extract" and method == "POST"):
            try:
                cid = int(p[1])
            except (TypeError, ValueError):
                return self._err("客户不存在", 404)
            res = docs.extract_ai(cid)
            return self._ok({"result": res, "docs": db.list_docs(customer_id=cid)})
        # ---- AI 处理日志(半月导出给 William 固化) ----
        if p and p[0] == "ai-log" and len(p) == 1 and method == "GET":
            return self._ok({"items": db.list_ai_log(), "usage": ai.usage()})
        if (p and p[0] == "ai-log" and len(p) == 2 and p[1] == "export"
                and method == "GET"):
            items = db.list_ai_log()
            export = {
                "app": "外贸客户工作台",
                "exported_at": db.now_iso(),
                "count": len(items),
                "items": [{
                    "field": it["task"],
                    "field_cn": {"identity": "身份", "followup": "跟进分类",
                                 "grade": "分级", "batch": "批次"}.get(it["task"], it["task"]),
                    "customer": it.get("customer_name") or "",
                    "status": it.get("status") or "",
                    "result": it.get("result") or "",
                    "quote": it.get("quote") or "",
                    "detail": it.get("detail") or "",
                    "at": it.get("created_at") or "",
                } for it in items],
            }
            return self._ok(export)
        if p and p[0] == "followup" and len(p) == 2 and p[1] == "today" \
                and method == "GET":
            items = profile.today_followups()
            return self._ok({"items": items, "today": db.today_iso()})
        # ---- 看板总览 ----
        if p and p[0] == "overview" and method == "GET":
            customers = db.list_customers()
            stages = [{"stage": s, "count": 0, "customers": []}
                      for s in db.STAGES]
            idx = {s["stage"]: i for i, s in enumerate(stages)}
            for c in customers:
                key = c["stage"] if c["stage"] in idx else db.STAGES[0]
                stages[idx[key]]["count"] += 1
                stages[idx[key]]["customers"].append({
                    "id": c["id"], "name": c["name"], "company": c["company"],
                    "country": c["country"], "product": c["product"],
                    "grade": c["grade"], "msg_count": c.get("msg_count"),
                    "doc_count": c.get("doc_count"),
                    "last_ts": c["last_ts"],
                    "timezone": c.get("timezone") or "",
                    "last_contact_at": c.get("last_contact_at") or "",
                    "next_followup_at": c.get("next_followup_at") or "",
                    "followup_category": c.get("followup_category") or "",
                })
            return self._ok({"stages": stages,
                             "totals": {"customers": len(customers)}})
        # ---- 消息重新识别(改词表后重跑) ----
        if (p and p[0] == "messages" and len(p) == 3 and p[2] == "reanalyze"
                and method == "POST"):
            m = db.get_message(int(p[1]))
            if not m:
                return self._err("消息不存在", 404)
            analysis = rules.analyze(m["content"], m["direction"])
            db.update_message_tags(int(p[1]), analysis["tags"])
            return self._ok({"message": db.get_message(int(p[1])),
                             "tags": analysis["tags"], "hits": analysis["hits"]})
        # ---- 提醒 ----
        if p and p[0] == "ai" and len(p) == 2 and p[1] == "queue" and method == "GET":
            return self._ok(aiworker.stats())
        if p and p[0] == "followcheck" and len(p) == 1 and method == "GET":
            return self._ok(followcheck.stats())
        if p and p[0] == "reminders" and len(p) == 2 and p[1] == "history" and method == "GET":
            return self._ok({"items": db.list_reminder_log(limit=60)})
        # 延时一天(只能一次,留痕“已延时一次”)
        if (p and p[0] == "reminders" and len(p) == 3 and p[2] == "delay"
                and method == "POST"):
            ok, nd, note, msg = db.delay_reminder_once(int(p[1]))
            if not ok:
                return self._err(msg, 400)
            return self._ok({"id": int(p[1]), "notify_date": nd, "note": note})
        # 推荐里没有提醒 id 的行(节奏推荐)也能点“已处理”——按客户推进下次跟进
        if (p and p[0] == "followups" and len(p) == 2 and p[1] == "done"
                and method == "POST"):
            data = self._body()
            cid = int(data.get("customer_id") or 0)
            c = db.get_customer(cid)
            if not c:
                return self._err("客户不存在", 404)
            cad = db.grade_cadence(c.get("grade") or "未分级") or 3
            nxt = (date.today() + timedelta(days=int(cad))).isoformat()
            db.update_customer(cid, {"next_followup_at": nxt})
            return self._ok({"customer_id": cid, "next_followup_at": nxt})
        if (p and p[0] == "reminders" and len(p) == 3 and p[2] == "revert"
                and method == "POST"):
            try:
                rid = int(p[1])
            except (TypeError, ValueError):
                return self._err("提醒不存在", 404)
            return self._ok(db.revert_reminder(rid))
        if (p and p[0] == "reminders" and len(p) == 2 and p[1] == "cleanup"
                and method == "POST"):
            data = self._body()
            if str(data.get("confirm") or "") != "YES":
                return self._err("需确认(confirm=YES)")
            n = db.clear_reminders()
            return self._ok({"cleared": n})
        if (p and p[0] == "reminders" and len(p) == 2 and p[1] == "check-replies"
                and method == "POST"):
            # 手动触发第 1 层:扫描所有待跟进,看我方是否已回复(纯代码,瞬间)
            checked, found = followcheck.code_scan()
            return self._ok({"checked": checked, "found": found,
                             "stats": followcheck.stats()})
        if (p and p[0] == "reminders" and len(p) == 3 and p[2] == "reply"
                and method == "POST"):
            # PM 对“疑似已回复”表态:confirm=确认完成 / keep=还没答,继续跟
            data = self._body()
            action = str(data.get("action") or "")
            try:
                rid = int(p[1])
            except (TypeError, ValueError):
                return self._err("提醒不存在", 404)
            if action == "confirm":
                # 【坑】这里以前调 db.decide_reminder —— 这个函数根本不存在,后端直接报错,
                # 所以“确认完成”点了没反应(也能提前点:不等它到点)。
                rem = db.get_reminder(rid) or {}
                db.set_reminder_status(rid, db.R_DONE)
                try:
                    db.log_reminder(rid, rem.get("customer_id"), "确认完成",
                                    note="手动确认(可提前)")
                except Exception as e:
                    log.swallow("server.py:434", e)
                return self._ok({"done": True})
            db.set_reminder_reply(rid, "not_answered", "", "")
            return self._ok({"kept": True})
        if (p and p[0] == "reminders" and len(p) == 2 and p[1] == "translate"
                and method == "POST"):
            # 把待批建议里的原话批量翻成中文(本地模型,一次调完)
            rows = db.list_reminders(status=db.R_SUGGESTED)
            pairs = {}
            for r in rows:
                q = (r.get("quote") or "").strip()
                if q and not (r.get("quote_zh") or "").strip():
                    pairs[str(r["id"])] = q[:400]
            if not pairs:
                return self._ok({"translated": 0})
            if not ai.enabled():
                return self._ok({"translated": 0, "detail": "AI 未开启"})
            zh = ai.translate_quotes(pairs)
            for rid, text in zh.items():
                try:
                    db.set_reminder_quote_zh(int(rid), text)
                except (TypeError, ValueError):
                    pass
            return self._ok({"translated": len(zh)})
        if p and p[0] == "reminders" and len(p) == 1 and method == "GET":
            status = self._query("status", "") or None
            # scope=today:今日推荐 = 待批准的建议 + **已到点还没处理的**跟进
            scope_today = (self._query("scope", "") == "today")
            items = db.list_reminders(status=None if scope_today else status)
            # 待批准的建议:自动算一个"建议日期",界面上直接预先填好(可改)
            lead = 1
            try:
                lead = max(1, int(db.get_setting("reminder_lead_default", "1") or 1))
            except ValueError:
                lead = 1
            today = date.today()
            for r in items:
                # 已批准:算“离承诺点还有几天” + 是否已到点(到点要置顶高亮)
                nd = (r.get("notify_date") or "")[:10]
                if nd:
                    try:
                        r["days_left"] = (date.fromisoformat(nd) - today).days
                    except ValueError:
                        r["days_left"] = None
                else:
                    r["days_left"] = None
                r["due"] = bool(r.get("status") == db.R_APPROVED
                                and r["days_left"] is not None
                                and r["days_left"] <= 0)
                if r.get("status") == db.R_APPROVED and r["days_left"] is not None:
                    dl = r["days_left"]
                    r["left_text"] = ("已到点(%d 天前)" % abs(dl) if dl < 0
                                      else ("今天到点" if dl == 0 else "还有 %d 天" % dl))
                else:
                    r["left_text"] = ""
                if r.get("status") == db.R_SUGGESTED or not nd:
                    if r.get("days") is not None:
                        r["suggested_date"] = (today + timedelta(
                            days=max(0, int(r["days"]) - lead))).isoformat()
                        r["date_hint"] = "承诺 %s 天内报价/跟进,提前 %s 天提醒" % (r["days"], lead)
                    else:
                        r["suggested_date"] = (today + timedelta(days=3)).isoformat()
                        r["date_hint"] = "原文没写天数,默认 3 天后(可改)"
                # 卡片要显示“几天后 + 具体日期”
                if r.get("status") == db.R_SUGGESTED and r.get("suggested_date"):
                    try:
                        ahead = (date.fromisoformat(r["suggested_date"]) - today).days
                        r["days_ahead"] = ahead
                        r["ahead_text"] = ("今天" if ahead == 0
                                           else ("%d 天后" % ahead if ahead > 0
                                                 else "%d 天前" % abs(ahead)))
                    except ValueError:
                        pass
            # 今日推荐:**A 优先 → B → 未分级;C 级不推荐**。
            # 同级内先到点的排前面。C 只从“推荐”里拿掉;你已批准的承诺(C 级也罢)不动,
            # 因为那是你自己点过批准的,不能因为分级就消失。
            _cache = getattr(self, "_grade_by_customer", None)
            if _cache is None:
                _cache = {c["id"]: (c.get("grade") or "未分级") for c in db.list_customers()}
                self._grade_by_customer = _cache
            for r in items:
                r["grade"] = _cache.get(r.get("customer_id"), "未分级")
            if scope_today:
                # 今日推荐 = ①必须跟的承诺(待批准 + 已到点的) ②跟进节奏(太久没联系)。
                # 跟“待跟进”分开:待跟进是承诺的审批流,这里是“节奏推荐”,要严格但可含 ABC。
                rem_items = [r for r in items
                             if r.get("status") == db.R_SUGGESTED
                             or (r.get("status") == db.R_APPROVED
                                 and r.get("days_left") is not None
                                 and r["days_left"] <= 0)]
                have = {r.get("customer_id") for r in rem_items}
                rhythm = []
                for c in db.list_customers():
                    if c["id"] in have or int(c.get("msg_count") or 0) < 3:
                        continue
                    lc = (c.get("last_contact_at") or "")[:10]
                    if not lc:
                        continue
                    try:
                        gap = (today - date.fromisoformat(lc)).days
                    except ValueError:
                        continue
                    if gap < 7:          # 严格:少于 7 天没联系不进推荐
                        continue
                    # 依据必须是**客户最后一句原话** —— 不能拿我方/运营的消息当证据
                    _con = db.connect()
                    _lm = _con.execute(
                        "SELECT content, ts FROM messages WHERE customer_id=? AND direction='in' "
                        "ORDER BY ts DESC LIMIT 1", (c["id"],)).fetchone()
                    _con.close()
                    rhythm.append({"id": None, "customer_id": c["id"], "kind": "跟进节奏",
                                   "note": "已经 %d 天没联系" % gap, "status": db.R_SUGGESTED,
                                   "grade": c.get("grade") or "未分级", "days_left": None,
                                   "due": False, "left_text": "", "days_ahead": 0,
                                   "ahead_text": "今天", "suggested_date": today.isoformat(),
                                   "quote": (_lm["content"][:90] if _lm else ""),
                                   "quote_ts": (_lm["ts"] if _lm else ""), "quote_zh": ""})
                rhythm.sort(key=lambda x: int(x["note"].split()[1]), reverse=True)
                items = rem_items + rhythm
            # 排序:A → B → C → 未分级;同级内已到点优先,再按临近天数
            _pri = {"A": 0, "B": 1, "C": 2, "未分级": 3, "": 3}
            items.sort(key=lambda r: (_pri.get(r["grade"], 3),
                                      0 if r.get("due") else 1,
                                      r.get("days_left") if r.get("days_left") is not None else 99))
            if scope_today:
                # 每天最多 15 条(可在设置里改):推荐要“严格”,不是把客户全铺开
                try:
                    cap = int(db.get_setting("rec_daily_max", "15") or 15)
                except ValueError:
                    cap = 15
                items = items[:max(1, cap)]
            return self._ok({"items": items, "today": today.isoformat()})
        if p and p[0] == "reminders" and len(p) == 1 and method == "POST":
            data = self._body()
            try:
                cid = int(data.get("customer_id") or 0)
            except (TypeError, ValueError):
                cid = 0
            if not db.get_customer(cid):
                return self._err("请选择客户")
            kind = str(data.get("kind") or "跟进")
            note = str(data.get("note") or "")
            notify_date = data.get("notify_date") or None
            rid = service.create_manual_reminder(cid, kind, note, notify_date)
            if rid is None:
                return self._err("手动提醒必须填提醒日期")
            return self._ok({"reminder": db.get_reminder(rid)}, 201)
        if p and p[0] == "reminders" and len(p) == 3 and p[1] == "decide":
            body = self._body()
            action = body.get("action")
            rid = int(p[2])
            if action == "approve":
                updated = service.approve_reminder(rid,
                                                   body.get("notify_date"))
                if updated is None:
                    return self._err("承诺类请直接批准;行程/无天数类必须先填提醒日期")
                return self._ok({"reminder": updated})
            if action == "cancel":
                return self._ok({"reminder": service.cancel_reminder(rid)})
            return self._err("action 只支持 approve/cancel")
        if p and p[0] == "reminders" and len(p) == 3 and p[2] == "manual-done" \
                and method == "POST":
            # PM 手动选定一条聊天记录作为“处理依据”,并留痕(不靠 AI 自动判)
            b = self._body()
            try:
                rid = int(p[1])
                mid = int(b.get("message_id") or 0)
            except (TypeError, ValueError):
                return self._err("参数错误", 400)
            rem = db.get_reminder(rid)
            if not rem:
                return self._err("提醒不存在", 404)
            m = db.get_message(mid)
            if not m:
                return self._err("消息不存在", 404)
            if m.get("customer_id") != rem.get("customer_id"):
                return self._err("这条消息不属于该客户", 400)
            who = (m.get("sender_name") or "").strip() or \
                  ("我方" if m.get("direction") == "out" else "客户")
            db.set_reminder_reply(rid, "replied", mid, m.get("content") or "",
                                  "PM 手动选定聊天记录作为处理依据",
                                  reply_by=who,
                                  reply_role=("pm" if m.get("direction") == "out" else "customer"))
            con = db.connect()
            con.execute("UPDATE reminders SET decided_by='human', status=?, decided_at=?"
                        " WHERE id=?", (db.R_DONE, db.now_iso(), rid))
            con.commit(); con.close()
            try:
                # 记 prev_status → 撤回时才能找到历史
                db.log_reminder(rid, rem.get("customer_id"), "确认处理(手动选定依据)",
                                (rem.get("status") or ""), db.R_DONE,
                                "依据消息 #%s" % mid)
            except Exception as e:
                log.swallow("server.manual_done_log", e)
            return self._ok({"done": True, "message_id": mid})
        if p and p[0] == "reminders" and len(p) == 3 and p[2] == "done" \
                and method == "POST":
            return self._ok({"reminder": service.mark_done(int(p[1]))})
        if p and p[0] == "reminders" and len(p) == 3 and p[2] == "date" \
                and method == "POST":
            body = self._body()
            nd = body.get("notify_date")
            r = db.get_reminder(int(p[1]))
            if not r:
                return self._err("提醒不存在", 404)
            if not nd:
                return self._err("请填日期")
            return self._ok({"reminder": db.set_reminder_status(
                int(p[1]), db.R_APPROVED, nd)})
        if p and p[0] == "reminders" and len(p) == 2 and method == "DELETE":
            db.delete_reminder(int(p[1]))
            return self._ok({"deleted": True})
        if p and p[0] == "reminders" and len(p) == 2 and p[1] == "due" \
                and method == "GET":
            return self._ok({"items": db.due_reminders()})
        # ---- 知识库 ----
        if p and p[0] == "kb" and len(p) == 1 and method == "GET":
            category = self._query("category", "") or None
            return self._ok({"items": db.list_kb(category=category),
                             "categories": db.KB_CATEGORIES})
        if p and p[0] == "kb" and len(p) == 1 and method == "POST":
            data = self._body()
            title = str(data.get("title") or "").strip()
            if not title:
                return self._err("标题不能为空")
            kid = db.add_kb(str(data.get("category") or db.KB_CATEGORIES[0]),
                            title, str(data.get("content") or ""),
                            str(data.get("tags") or ""),
                            str(data.get("source") or ""))
            return self._ok({"item": db.get_kb(kid)}, 201)
        if p and p[0] == "kb" and len(p) == 2 and method == "GET":
            item = db.get_kb(int(p[1]))
            return self._ok({"item": item}) if item else self._err("条目不存在", 404)
        if p and p[0] == "kb" and len(p) == 2 and method == "PUT":
            updated = db.update_kb(int(p[1]), self._body())
            return self._ok({"item": updated}) if updated else self._err("条目不存在", 404)
        if p and p[0] == "kb" and len(p) == 2 and method == "DELETE":
            db.delete_kb(int(p[1]))
            return self._ok({"deleted": True})
        # ---- 产品目录(结构化) ----
        if p and p[0] == "catalog" and len(p) == 1 and method == "GET":
            department = self._query("department", "") or None
            return self._ok({"items": db.list_catalog(department=department)})
        if p and p[0] == "catalog" and len(p) == 1 and method == "POST":
            data = self._body()
            if not str(data.get("department") or "").strip():
                return self._err("部门不能为空")
            cid = db.add_catalog(data)
            return self._ok({"item": db.get_catalog(cid)}, 201)
        if p and p[0] == "catalog" and len(p) == 2 and method == "GET":
            item = db.get_catalog(int(p[1]))
            return self._ok({"item": item}) if item else self._err("条目不存在", 404)
        if p and p[0] == "catalog" and len(p) == 2 and method == "PUT":
            updated = db.update_catalog(int(p[1]), self._body())
            return self._ok({"item": updated}) if updated else self._err("条目不存在", 404)
        if p and p[0] == "catalog" and len(p) == 2 and method == "DELETE":
            db.delete_catalog(int(p[1]))
            return self._ok({"deleted": True})
        # ---- 历史聊天导入(界面/CLI 共用,保留时间戳) ----
        # ---- 一次性导入(多选文件):像“迁移备份”一样一次弄完,不靠反复拉历史 ----
        if p == ["import-files"] and method == "POST":
            b = self._body()
            files = b.get("files") or []
            if not isinstance(files, list) or not files:
                return self._err("没有文件")
            report = []
            for it in files[:200]:
                nm = str(it.get("name") or "导入.txt")
                txt = str(it.get("text") or "")
                try:
                    r = autoimport.import_text(nm, txt)
                except Exception as e:
                    log.swallow("server.import_files", e)
                    r = {"ok": False, "error": str(e), "file": nm}
                report.append(r)
            okr = [r for r in report if r.get("ok")]
            return self._ok({"files": len(report), "ok": len(okr),
                             "messages": sum(int(r.get("imported") or 0) for r in okr),
                             "customers": len({r.get("customer_id") for r in okr}),
                             "report": report})
        if p and p[0] == "import-chat" and len(p) == 1 and method == "POST":
            data = self._body()
            text = str(data.get("text") or "")
            if not text.strip():
                return self._err("聊天内容为空")
            cid = data.get("customer_id")
            phone = str(data.get("phone") or "").strip()
            peer_name = str(data.get("peer_name") or "").strip()
            new_name = str(data.get("new_name") or "").strip()
            matched_by = "given"
            if cid:
                cid = int(cid)
                if not db.get_customer(cid):
                    return self._err("客户不存在", 404)
            else:
                # 导入的 .txt 只有名字、没有号码 —— 所以按这个顺序找已有客户:
                #   ① 手机号(填了就最准) ② 名字完全一致 ③ 名字本身就是号码
                # 都不中才新建。否则会开出一堆重复档案,后续 WhatsApp 真号也对不上。
                cust = None
                if phone:
                    cust = db.find_customer_by_phone(phone)
                    matched_by = "phone"
                if not cust and peer_name:
                    cust = db.find_customer_by_phone(peer_name)   # 未存联系人时导出名就是号码
                    if cust:
                        matched_by = "peer_phone"
                if not cust:
                    nm = new_name or peer_name
                    if nm:
                        cust = db.find_customer_by_name(nm)
                        if cust:
                            matched_by = "name"
                if cust:
                    cid = cust["id"]
                    # 只在原来**没号码**时才补上;已有的国际格式比本地 0 开头更规范,不覆盖
                    if phone and not (cust.get("phone") or "").strip():
                        db.update_customer(cid, {"phone": phone})
                else:
                    cid = db.create_customer({"name": new_name or peer_name or phone or "导入客户",
                                              "phone": phone, "source": "导入"})
                    matched_by = "new"
            res = chatimport.import_chat(
                cid, text, peer_name=peer_name or None)
            cust_now = db.get_customer(cid) or {}
            return self._ok({"customer_id": cid, "matched_by": matched_by,
                             "customer": {"id": cid, "name": cust_now.get("name"),
                                          "phone": cust_now.get("phone")},
                             **res}, 201)
        # ---- 通知中心(软件内提醒) ----
        if p and p[0] == "notifications" and len(p) == 1 and method == "GET":
            unread_only = self._query("unread", "") in ("1", "true")
            return self._ok({"items": db.list_notifications(unread_only=unread_only),
                             "unread": db.unread_count()})
        if (p and p[0] == "notifications" and len(p) == 2 and p[1] == "read"
                and method == "POST"):
            body = self._body()
            db.mark_notifications_read(body.get("id"))
            return self._ok({"unread": db.unread_count()})
        if (p and p[0] == "notifications" and len(p) == 2 and p[1] == "scan"
                and method == "POST"):
            return self._ok({"created": notify.scan(), "unread": db.unread_count()})
        # ---- 外部收信桥接(WhatsApp 等推送进来;凭令牌鉴权) ----
        # ---- 桥接通道(B 方案:实时收信;已按防封号加固)----
        if p == ["bridge", "status"] and method == "GET":
            st = {}
            sf = os.path.join(db.PROJECT_DIR, "bridge", "status.json")
            if os.path.exists(sf):   # 桥接还没跑时没这文件——正常,不必报错刷日志
                try:
                    with open(sf, encoding="utf-8") as f:
                        st = json.load(f)
                except Exception as e:
                    log.swallow("server.bridge_status", e)
            st["reset_wait_s"] = 0        # 已取消冷却:随时可重新扫码
            return self._ok(st)
        if p == ["bridge", "qr"] and method == "GET":
            qp = os.path.join(db.PROJECT_DIR, "bridge", "qr.png")
            try:
                with open(qp, "rb") as f:
                    return self._send(200, f.read(), "image/png")
            except OSError:
                return self._err("还没有二维码", 404)
        if p == ["bridge", "reset"] and method == "POST":
            # 【改 2026-09-16】取消 30 分钟冷却:随时可重新扫码。
            # 但“请求二维码”只在此次点击时发生(写 pairing.req)——软件不会自动请求。
            bdir = os.path.join(db.PROJECT_DIR, "bridge")
            subprocess.run([sys.executable, "keepalive.py", "--stop"], cwd=bdir, timeout=30)
            for f2 in ("qr.png", "qr.txt"):
                try:
                    os.remove(os.path.join(bdir, f2))
                except OSError:
                    pass
            old = os.path.join(bdir, "auth")
            if os.path.isdir(old):
                try:
                    os.rename(old, os.path.join(bdir, "auth.bad-%s" % time.strftime("%Y%m%d-%H%M%S")))
                except OSError as e:
                    log.swallow("server.bridge_reset_rename", e)
            # 写“扫码指令” → 桥接看到它才去请求二维码
            try:
                with open(os.path.join(bdir, "pairing.req"), "w") as f:
                    f.write(str(time.time()))
            except OSError as e:
                log.swallow("server.bridge_pair_req", e)
            subprocess.run([sys.executable, "keepalive.py", "--force"], cwd=bdir, timeout=60)
            return self._ok({"ok": True, "reset_wait_s": 0})
        # ---- WhatsApp 官方 Cloud API(webhook 收信;合规、不会被封)----
        # Meta 配置 webhook 时会先用 GET 带 hub.challenge 来验一下
        if p == ["wa", "webhook"] and method == "GET":
            want = db.get_setting("wa_verify_token", "")
            mode = self._query("hub.mode", "")
            tok = self._query("hub.verify_token", "")
            chal = self._query("hub.challenge", "")
            if mode == "subscribe" and want and tok == want:
                return self._text(chal)          # 原样回显 challenge
            return self._err("verify failed", 403)
        if p == ["wa", "webhook"] and method == "POST":
            raw = self._raw_body()
            if not wa_official.signature_ok(raw, self.headers.get("X-Hub-Signature-256")):
                log.warn("webhook 签名不通过 @server", detail="已拒绝一条伪造/缺失签名的请求")
                return self._err("bad signature", 403)
            try:
                data = json.loads(raw.decode("utf-8") or "{}")
            except ValueError:
                return self._err("bad json", 400)
            n = 0
            for m in wa_official.parse_webhook(data):
                if not m.get("content"):
                    continue
                service.ingest_message({
                    "phone": m["phone"], "name": m["name"], "content": m["content"],
                    "ts": m["ts"], "direction": "in", "source": "direct",
                    "chat": "", "sender_role": "customer",
                    "wa_message_id": m.get("wa_message_id", ""),
                })
                n += 1
            return self._ok({"received": n})   # 必须快速 200,否则 Meta 会重推
        if p == ["wa", "status"] and method == "GET":
            return self._ok(wa_official.status())
        if p == ["wa", "settings"] and method == "POST":
            b = self._body()
            for k in ("wa_mode", "wa_app_secret", "wa_access_token", "wa_phone_number_id"):
                if k in b:
                    db.set_setting(k, str(b.get(k) or "").strip())
            wa_official.ensure_settings()
            return self._ok(wa_official.status())
        # ---- 收信接口(历史导入/自用脚本仍可用;官方 webhook 走上面那条)----
        if p and p[0] == "ingest" and len(p) == 1 and method == "POST":
            data = self._body()
            if str(data.get("token") or "") != db.get_setting("ingest_token", ""):
                return self._err("令牌不正确", 403)
            if not str(data.get("content") or "").strip():
                return self._err("content 不能为空")
            # 判定“谁发的/归哪个客户”全部在 service.ingest_message 里(我方 PM/SM、
            # 客户本人、客户自带设计师三种身份区分开)
            res = service.ingest_message(data)
            if not res.get("ok"):
                return self._ok({"skipped": res.get("skipped")}, 202)
            return self._ok({"customer_id": res.get("customer_id"),
                             "message_id": res.get("message_id"),
                             "role": res.get("role"),
                             "sender": res.get("sender")}, 201)
        # ---- 批量历史导入:导入完成后统一补一次分析(零 AI、不刷卡片) ----
        if (p and p[0] == "ingest" and len(p) == 2 and p[1] == "bulk-done"
                and method == "POST"):
            data = self._body()
            if str(data.get("token") or "") != db.get_setting("ingest_token", ""):
                return self._err("令牌不正确", 403)
            ids = []
            for x in (data.get("customer_ids") or []):
                try:
                    ids.append(int(x))
                except (TypeError, ValueError):
                    pass
            done = 0
            for cid in ids[:500]:
                try:
                    if db.get_customer(cid):
                        profile.enrich_customer(cid)
                        done += 1
                except Exception as e:
                    log.swallow("server.py:754", e)
            return self._ok({"enriched": done, "total": len(ids)})
        # ---- WhatsApp 标签(客户分级):把标签名字里的 A/B/C 映到客户分级 ----
        if (p and p[0] == "ingest" and len(p) == 2 and p[1] == "labels"
                and method == "POST"):
            data = self._body()
            if str(data.get("token") or "") != db.get_setting("ingest_token", ""):
                return self._err("令牌不正确", 403)
            labels = {}
            for l in (data.get("labels") or []):
                labels[str(l.get("id") or "")] = (l.get("name") or "")
            db.set_setting("wa_labels", json.dumps(labels, ensure_ascii=False))
            db.set_setting("wa_assoc", json.dumps(data.get("assoc") or [], ensure_ascii=False))
            if not data.get("assoc"):
                # 空的关联不动已有的等级(避免误清)
                pass
            applied = []
            for a in (data.get("assoc") or []):
                chat = (a.get("chat") or "").strip()
                if not chat:
                    continue
                # 会话可能按“群 JID”或“群名”绑定 —— 三种键都试,并且两个键都补绑
                subj = (a.get("subject") or "").strip()
                owner = (db.get_chat_customer(chat)
                         or db.get_chat_customer(re.sub(r"@.*$", "", chat))
                         or (db.get_chat_customer(subj) if subj else None))
                if not owner:
                    continue
                for _k in filter(None, [chat, subj]):
                    if not db.get_chat_customer(_k):
                        db.link_chat(_k, owner["id"])
                grade = _grade_from_labels([labels.get(str(i), "") for i in (a.get("ids") or [])])
                if grade and (owner.get("grade") or "") != grade:
                    db.update_customer(owner["id"], {"grade": grade})
                    applied.append({"customer_id": owner["id"], "grade": grade})
            return self._ok({"labels": len(labels), "applied": applied[:50],
                             "applied_count": len(applied)})
        # ---- 名片号码提示:群里发的“客户名片”里带真号 → 补进客户档 ----
        if (p and p[0] == "ingest" and len(p) == 2 and p[1] == "phone-hint"
                and method == "POST"):
            data = self._body()
            if str(data.get("token") or "") != db.get_setting("ingest_token", ""):
                return self._err("令牌不正确", 403)
            chat = (data.get("chat") or "").strip()
            phone = (data.get("phone") or "").strip()
            if not chat or len(re.sub(r"\D", "", phone)) < 7:
                return self._ok({"skipped": "参数不足"})
            # 会话可能以“群名”或“群 JID”任一形式绑定 —— 两个键都查
            owner = (db.get_chat_customer(chat)
                     or db.get_chat_customer((data.get("chat_jid") or "").strip()))
            if not owner:
                return self._ok({"skipped": "该会话还没绑定客户"})
            if (owner.get("phone") or "").strip():
                return self._ok({"skipped": "档案已有号码", "customer_id": owner["id"]})
            db.update_customer(owner["id"], {"phone": phone})
            return self._ok({"filled": owner["id"], "phone": phone})
        # ---- 联系人映射表(LID ↔ 真号 ↔ 备注名):给还没发言的群成员补号 ----
        if (p and p[0] == "ingest" and len(p) == 2 and p[1] == "contacts"
                and method == "POST"):
            data = self._body()
            if str(data.get("token") or "") != db.get_setting("ingest_token", ""):
                return self._err("令牌不正确", 403)
            try:
                cmap = json.loads(db.get_setting("contact_map", "{}"))
            except (ValueError, TypeError):
                cmap = {}
            n = 0
            for c in (data.get("contacts") or []):
                lid = re.sub(r"\D", "", str(c.get("lid") or ""))
                phone = re.sub(r"\D", "", str(c.get("phone") or ""))
                name = (c.get("name") or "").strip()
                if not lid or len(phone) < 7:
                    continue
                cur = cmap.get(lid) or {}
                cmap[lid] = {"phone": "+" + phone,
                             "name": name or cur.get("name", "")}
                n += 1
            if n:
                db.set_setting("contact_map", json.dumps(cmap, ensure_ascii=False))
            return self._ok({"stored": n, "total": len(cmap)})
        # ---- 历史同步进度(桥接上报,界面展示用) ----
        if (p and p[0] == "history" and len(p) == 2 and p[1] == "status"
                and method == "POST"):
            data = self._body()
            if str(data.get("token") or "") != db.get_setting("ingest_token", ""):
                return self._err("令牌不正确", 403)
            st = {k: data.get(k) for k in ("started", "chats", "messages",
                                           "progress", "done")}
            db.set_setting("history_status", json.dumps(st, ensure_ascii=False))
            return self._ok({"ok": True})
        if p and p[0] == "history" and len(p) == 2 and p[1] == "status" and method == "GET":
            raw = db.get_setting("history_status", "")
            try:
                st = json.loads(raw) if raw else {}
            except (ValueError, TypeError):
                st = {}
            return self._ok({"history": st})
        # ---- 我方团队名册(PM / SM / 运营):SM 的群内回复靠这个区分 ----
        if p and p[0] == "team" and len(p) == 1 and method == "GET":
            return self._ok({"items": db.list_team(), "roles": db.TEAM_ROLES})
        # 名册口:群里自动发现的我方号码(待确认)→ 一键加进名册
        if (p and p[0] == "team" and len(p) == 2 and p[1] == "pending"
                and method == "GET"):
            return self._ok({"items": db.list_pending_team()})
        if (p and p[0] == "team" and len(p) == 3 and p[1] == "pending"
                and p[2] == "confirm" and method == "POST"):
            b = self._body()
            phone = str(b.get("phone") or "").strip()
            if not phone:
                return self._err("缺少手机号")
            db.add_team_member({"phone": phone,
                                "name": str(b.get("name") or "").strip(),
                                "role": str(b.get("role") or "SM").strip()})
            db.clear_pending_team(phone)
            return self._ok({"items": db.list_team(),
                             "pending": db.list_pending_team()})
        if (p and p[0] == "team" and len(p) == 3 and p[1] == "pending"
                and p[2] == "remove" and method == "POST"):
            db.clear_pending_team(str(self._body().get("phone") or "").strip())
            return self._ok({"pending": db.list_pending_team()})
        if p and p[0] == "team" and len(p) == 1 and method == "POST":
            body = self._body()
            if not str(body.get("phone") or "").strip():
                return self._err("请填手机号")
            tid = db.add_team_member(body)
            return self._ok({"id": tid, "items": db.list_team()}, 201)
        if p and p[0] == "team" and len(p) == 2 and method in ("PUT", "POST"):
            db.update_team_member(int(p[1]), self._body())
            return self._ok({"items": db.list_team()})
        if p and p[0] == "team" and len(p) == 2 and method == "DELETE":
            db.delete_team_member(int(p[1]))
            return self._ok({"items": db.list_team()})
        # ---- 客户方相关人(客户自带的设计师/采购/同事) ----
        if p and p[0] == "persons" and len(p) == 1 and method == "GET":
            cid = self._query("customer_id", "")
            return self._ok({"items": db.list_persons(int(cid) if cid else None),
                             "roles": db.PERSON_ROLES})
        if p and p[0] == "persons" and len(p) == 1 and method == "POST":
            body = self._body()
            cid = body.get("customer_id")
            if not cid:
                return self._err("缺少 customer_id")
            pid = None
            if str(body.get("phone") or "").strip():
                p0 = db.upsert_person(int(cid), body.get("phone"),
                                      body.get("name") or "",
                                      body.get("role") or "其他",
                                      body.get("note") or "", source="human")
                pid = (p0 or {}).get("id")
                db.update_person(pid, {"role": body.get("role") or "其他",
                                       "name": body.get("name") or ""})
            return self._ok({"id": pid,
                             "items": db.list_persons(int(cid))}, 201)
        if p and p[0] == "persons" and len(p) == 2 and method in ("PUT", "POST"):
            db.update_person(int(p[1]), self._body())
            return self._ok({"ok": True})
        if p and p[0] == "persons" and len(p) == 2 and method == "DELETE":
            db.delete_person(int(p[1]))
            return self._ok({"ok": True})
        # ---- 一个客户的关系网(相关人 + 所属群聊) ----
        if (p and p[0] == "customers" and len(p) == 3 and p[2] == "relations"
                and method == "GET"):
            cid = int(p[1])
            return self._ok({"persons": db.list_persons(cid),
                             "chats": db.links_for_customer(cid),
                             "roles": db.PERSON_ROLES})
        # ---- 合并客户(同人两号 / 把设计师并进客户档案) ----
        if (p and p[0] == "customers" and len(p) == 3 and p[2] == "merge"
                and method == "POST"):
            body = self._body()
            src = body.get("source_id")
            if not src:
                return self._err("请选择要合并进来的客户")
            out = db.merge_customers(int(src), int(p[1]),
                                     body.get("role") or "其他",
                                     body.get("note") or "")
            if not out:
                return self._err("合并失败(客户不存在,或选了自己)")
            db.links_for_customer(int(p[1]))
            return self._ok(out)
        # ---- 合并留痕 + 撒销(误合并一键回滚) ----
        if p and p[0] == "merges" and len(p) == 1 and method == "GET":
            return self._ok({"items": db.list_merges()})
        if (p and p[0] == "merges" and len(p) == 3 and p[2] == "revert"
                and method == "POST"):
            out = db.revert_merge(int(p[1]))
            if not out:
                return self._err("找不到这条合并记录")
            return self._ok(out)
        # ---- 重新指定一个群聊归哪个客户 ----
        if p and p[0] == "chats" and len(p) == 1 and method == "POST":
            body = self._body()
            ref = str(body.get("chat") or "").strip()
            cid2 = body.get("customer_id")
            if not ref or not cid2:
                return self._err("缺少 chat / customer_id")
            db.link_chat(ref, int(cid2))
            return self._ok({"ok": True})
        # ---- AI 处理日志(半月导出给 William 固化) ----
        if p and p[0] == "ai-log" and len(p) == 1 and method == "GET":
            return self._ok({"items": db.list_ai_log(), "usage": ai.usage()})
        if (p and p[0] == "ai-log" and len(p) == 2 and p[1] == "export"
                and method == "GET"):
            items = db.list_ai_log()
            export = {
                "app": "外贸客户工作台",
                "exported_at": db.now_iso(),
                "count": len(items),
                "items": [{
                    "field": it["task"],
                    "field_cn": {"identity": "身份", "followup": "跟进分类",
                                 "grade": "分级", "batch": "批次"}.get(it["task"], it["task"]),
                    "customer": it.get("customer_name") or "",
                    "status": it.get("status") or "",
                    "result": it.get("result") or "",
                    "quote": it.get("quote") or "",
                    "detail": it.get("detail") or "",
                    "at": it.get("created_at") or "",
                } for it in items],
            }
            return self._ok(export)
        # ---- 桥接状态 / 二维码(登录页用) ----
        # 界面错误上报 → 写进 data/app.log(排障用:白屏/undefined 一目了然)
        if p and p[0] == "ui-error" and method == "POST":
            b = self._body()
            log.warn("UI:%s" % str(b.get("where") or "?"),
                     Exception(str(b.get("message") or "")[:300]),
                     detail=str(b.get("stack") or "")[:400])
            return self._ok({"ok": True})
        # ---- 设置 / 统计 ----
        if p and p[0] == "settings" and method == "GET":
            return self._ok({"settings": db.all_settings()})
        if p and p[0] == "settings" and method == "PUT":
            body = self._body()
            for key, value in body.items():
                if isinstance(value, (str, int, float)):
                    db.set_setting(key, str(value))
            return self._ok({"settings": db.all_settings()})
        if p and p[0] == "stats" and method == "GET":
            return self._ok({**db.stats(), "db_path": db.DB_PATH,
                             "version": APP_VERSION})
        # ---- 联网更新(你控制后台,PM 端一键更新)----
        if p == ["update", "check"] and method == "GET":
            return self._ok(updater.check())
        if p == ["update", "status"] and method == "GET":
            return self._ok({"current": APP_VERSION, "url": updater.update_url(),
                             **updater.staged_info()})
        if p == ["update", "download"] and method == "POST":
            return self._ok(updater.stage())
        if p == ["update", "apply"] and method == "POST":
            return self._ok(updater.run_apply())
        return self._err("not found", 404)

    # HTTP 方法入口
    do_GET = lambda self: self._handle("GET")
    do_POST = lambda self: self._handle("POST")
    do_PUT = lambda self: self._handle("PUT")
    do_DELETE = lambda self: self._handle("DELETE")


def _open_app_window(url):
    """用系统浏览器的“应用模式”打开(无地址栏/无标签页,像个客户端)。
    找不到就退回到普通浏览器。"""
    import os
    import shutil
    import subprocess
    import sys as _sys
    if _sys.platform.startswith("win"):
        cands = ["msedge", "chrome",
                 r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
                 r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
                 r"C:\Program Files\Google\Chrome\Application\chrome.exe",
                 r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"]
    elif _sys.platform == "darwin":
        cands = ["google-chrome"]
    else:
        cands = ["google-chrome", "chromium", "chromium-browser", "microsoft-edge"]
    for c in cands:
        exe = shutil.which(c) or (c if os.path.exists(c) else None)
        if not exe:
            continue
        try:
            subprocess.Popen([exe, "--app=" + url],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return True
        except Exception:
            continue
    return False


def run_server(port=DEFAULT_PORT, open_browser=True):
    db.init_db()
    wa_official.ensure_settings()   # 官方通道:首次运行自动生成 webhook 验证口令
    autoimport.start_background()   # 自动导入:收件夹里有导出文件就自动入库(零成本)
    notify.start_background()   # 软件内提醒的后台扫描线程(纯代码,零 token)
    aiworker.start_background()  # 边聊边跑的 AI 识别队列(本地模型,零成本)

    # 本地 AI 模型:开机自动拉起(内置,不用手动开)
    def _boot_ai():
        try:
            info = ai.ensure_local(wait=180)
            if info.get("started"):
                print("  本地 AI 模型:已自动启动 ✅")
            elif info.get("ok"):
                print("  本地 AI 模型:已就绪(或未配置本地模型)")
            else:
                print("  本地 AI 模型:未启动(%s)" % info.get("detail"))
        except Exception as exc:
            print("  本地 AI 模型启动失败:", exc)
    threading.Thread(target=_boot_ai, daemon=True).start()
    handler = lambda *a, **kw: Api(*a, **kw)
    httpd = ThreadingHTTPServer((HOST, port), handler)
    print("=" * 52)
    print("  外贸客户工作台 v%s(本地版)已启动" % APP_VERSION)
    print("  操作台地址: http://127.0.0.1:%d" % port)
    print("  数据文件:   %s" % db.DB_PATH)
    print("  按 Ctrl+C 退出")
    print("=" * 52)
    if open_browser:
        def _open():
            url = f"http://127.0.0.1:{port}"
            if not _open_app_window(url):   # 优先“应用模式”(像客户端)
                webbrowser.open(url)        # 退回到普通浏览器
        threading.Timer(1.0, _open).start()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n已退出,数据都已保存在本地。")
