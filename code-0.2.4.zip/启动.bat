@echo off
chcp 65001 >nul
cd /d %~dp0

REM ---- 首次启动时自动在桌面创建快捷方式 ----
if not exist "%USERPROFILE%\Desktop\客户工作台.lnk" (
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-shortcut.ps1"
)

REM ---- 无窗口启动(pythonw.exe,不弹黑框) ----
start "" python\pythonw.exe main.py
