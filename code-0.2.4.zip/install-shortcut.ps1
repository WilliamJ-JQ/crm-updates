﻿$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$desktop = [Environment]::GetFolderPath('Desktop')
$lnk = Join-Path $desktop ([char]0x5BA2 + [char]0x6237 + [char]0x5DE5 + [char]0x4F5C + [char]0x53F0 + '.lnk')
$ws = New-Object -ComObject WScript.Shell
$s = $ws.CreateShortcut($lnk)
$s.TargetPath = Join-Path $root 'python\pythonw.exe'
$s.Arguments = 'main.py'
$s.WorkingDirectory = $root
$s.IconLocation = Join-Path $root 'app.ico'
$s.Description = 'Customer Desk'
$s.Save()
