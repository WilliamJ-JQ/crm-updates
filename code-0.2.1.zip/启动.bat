@echo off
chcp 65001 >nul
echo ================================================
echo   正在启动 客户工作台(软件 + WhatsApp 桥接)
echo ================================================
wsl -e bash -lc "cd ~/.openclaw/workspace/export-crm && ./service.sh start"
echo.
echo 完成后用浏览器打开: http://127.0.0.1:8765
echo (本窗口可以关掉,服务在后台跑)
timeout /t 5 >nul
