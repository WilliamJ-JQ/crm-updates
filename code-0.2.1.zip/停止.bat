@echo off
chcp 65001 >nul
echo 正在停止 客户工作台…
wsl -e bash -lc "cd ~/.openclaw/workspace/export-crm && ./service.sh stop"
echo 已停止。
timeout /t 3 >nul
