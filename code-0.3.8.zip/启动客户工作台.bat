@echo off
title CRM Workstation v0.3.0 Launcher

echo ========================================
echo   CRM Workstation v0.3.0 Starting...
echo ========================================
echo.

echo %~d0 | findstr "\\\\" >nul
if %errorlevel%==0 (
    echo [ERROR] Running from network share!
    echo Please copy the entire folder to your local computer first.
    pause
    exit /b 1
)

set "APP_DIR=%~dp0"
if "%APP_DIR%"=="" (
    echo [ERROR] Cannot determine app directory
    pause
    exit /b 1
)
if "%APP_DIR:~-1%"=="\" set "APP_DIR=%APP_DIR:~0,-1%"
echo App Dir: %APP_DIR%
echo.

echo [1/6] Unblocking files (fixes Windows security block)...
powershell -NoProfile -Command "Get-ChildItem -Path '%APP_DIR%' -Recurse -Include *.exe,*.dll,*.bat,*.py,*.js | Unblock-File -ErrorAction SilentlyContinue"
echo   Done
echo.

echo [2/6] Stopping old processes (this folder only)...
taskkill /f /im "CRMWorkstation.exe" >nul 2>&1
taskkill /f /im "?????.exe" >nul 2>&1
rem 只结束“命令行里带本目录”的 python/node/llama 进程,
rem 避免把同机其它 Python 程序或另一份客户工作台的桥接一起杀掉。
powershell -NoProfile -Command "$d='%APP_DIR%'.ToLower(); $names=@('python.exe','pythonw.exe','node.exe','llama-server.exe','python-translate.exe'); Get-CimInstance Win32_Process | Where-Object { $_.ProcessId -ne $PID -and $_.Name.ToLower() -in $names -and $_.CommandLine -and $_.CommandLine.ToLower().Contains($d) } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }"
timeout /t 3 /nobreak >nul
echo   Done
echo.

echo [3/6] Checking files...
set "EXE_NAME="
if exist "%APP_DIR%\CRMWorkstation.exe" (
    set "EXE_NAME=CRMWorkstation.exe"
    echo   Found: CRMWorkstation.exe
) else (
    if exist "%APP_DIR%\?????.exe" (
        set "EXE_NAME=?????.exe"
        echo   Found: ?????.exe
    ) else (
        echo   [ERROR] Cannot find exe file
        dir /b "%APP_DIR%\*.exe"
        pause
        exit /b 1
    )
)
if not exist "%APP_DIR%\python\pythonw.exe" (
    echo   [ERROR] Cannot find python\pythonw.exe
    pause
    exit /b 1
)
if not exist "%APP_DIR%\main.py" (
    echo   [ERROR] Cannot find main.py
    pause
    exit /b 1
)
echo   All files OK
echo.

echo [4/6] Checking WebView2 runtime...
reg query "HKLM\SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}" /v pv >nul 2>&1
if %errorlevel%==0 goto :webview_ok
reg query "HKCU\SOFTWARE\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}" /v pv >nul 2>&1
if %errorlevel%==0 goto :webview_ok
echo   WebView2 not installed, installing...
if exist "%APP_DIR%\MicrosoftEdgeWebView2Setup.exe" (
    start /wait "" "%APP_DIR%\MicrosoftEdgeWebView2Setup.exe" /silent /install
    echo   WebView2 installed
) else (
    echo   Downloading WebView2...
    powershell -Command "Invoke-WebRequest -Uri 'https://go.microsoft.com/fwlink/p/?LinkId=2124703' -OutFile '%TEMP%\WebView2Setup.exe' -UseBasicParsing"
    start /wait "" "%TEMP%\WebView2Setup.exe" /silent /install
    echo   WebView2 installed
)
:webview_ok
echo   WebView2: OK
echo.

echo [5/6] Starting server...
cd /d "%APP_DIR%"
start "CRM-Server" /min "%APP_DIR%\python\pythonw.exe" "%APP_DIR%\main.py" --no-browser
echo   Server started, waiting 8 seconds...
timeout /t 8 /nobreak >nul
echo.

echo [6/6] Starting CRM Workstation window...
start "" "%APP_DIR%\%EXE_NAME%"
echo   Window launched!
echo.
echo ========================================
echo   Startup complete!
echo   If no window appears in 30 seconds,
echo   check data\startup.log for errors.
echo ========================================
echo.
timeout /t 5 /nobreak >nul
exit /b 0