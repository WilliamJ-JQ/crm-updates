@echo off
cd /d %~dp0
echo ================================================
echo   应用更新(先关软件,重启时自动生效——手动兑底用)
echo ================================================
taskkill /f /im python.exe >nul 2>&1
taskkill /f /im node.exe >nul 2>&1
timeout /t 2 >nul
echo 正在重启...
start "" "启动客户工作台.bat"
