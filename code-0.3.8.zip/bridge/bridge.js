#!/usr/bin/env node
// -*- coding: utf-8 -*-
// 【工作目录固定到脚本所在目录】不依赖启动时的 cwd
// (双击 bat 时 cwd 可能是软件根目录,会让 auth/、qr.png、status.json 落到错位置 → 界面读不到二维码)。
try { process.chdir(__dirname); } catch (e) {}
// 【启动错误捕获】任何未捕获异常/拒绝都写进 bridge-error.log —— 窗口闪退也能事后查看。
try {
  process.on('uncaughtException', (e) => {
    try {
      require('fs').appendFileSync('bridge-error.log',
        new Date().toISOString() + ' [uncaught] ' + ((e && e.stack) || e) + '\n');
    } catch (x) {}
    console.error('[bridge] 启动/运行失败:', (e && e.stack) || e);
    process.exit(1);
  });
  process.on('unhandledRejection', (e) => {
    try {
      require('fs').appendFileSync('bridge-error.log',
        new Date().toISOString() + ' [reject] ' + ((e && e.stack) || e) + '\n');
    } catch (x) {}
    console.error('[bridge] 未处理的拒绝:', (e && e.stack) || e);
    process.exit(1);
  });
} catch (x) {}
/**
 * WhatsApp 桥接(只收不发)。
 *
 * 做什么:
 *   1) 扫码配对(QR 存到 qr.png)
 *   2) 实时收消息 → POST 到本地客户工作台 /api/ingest(令牌鉴权)
 *   3) 开机/重连时补收“关机期间”的离线消息(默认只看最近 72 小时)
 *   4) 断线限速恢复;硬错误(登出/403/同号别处登录)立即停手,等人工点【拉起桥接】
 *
 * 安全红线(写死,不是配置项):
 *   - 全程没有任何"发送"函数 → 从物理上不可能误发客户。
 *
 * 运行:
 *   node bridge.js
 *   环境变量(可选):
 *     WA_PROXY          代理地址。留空 = 直连;keepalive 会再尝试跟随 Windows 系统代理
 *     APP_URL           客户工作台地址,默认 http://127.0.0.1:8765
 *     WA_OFFLINE_HOURS  开机补收窗口(小时),默认 72。只收窗口内的离线消息,更早的丢弃
 *     WA_AUTO_MAX_CHAIN 连续自动重连上限,默认 4
 *     WA_AUTO_PER_HOUR  每 1 小时自动重连上限,默认 12
 */
// 代理:**默认不设**(PM 用 VPN 直连即可)。大陆自建代理的:设环境变量 WA_PROXY,
// 或在软件【设置】里填「网络代理」。写死代理会导致没有该代理的机器连不上 WhatsApp。
const proxy = (process.env.WA_PROXY || '').trim();
const APP_URL = process.env.APP_URL || 'http://127.0.0.1:8765';
// 配对时向 WhatsApp 请求“全量历史同步”。
// 【改默认】以前默认开 —— 全量拉历史是非官方客户端**最容易被封**的高危行为之一,
// 现已改成**默认关**;确需要再显式设 WA_FULL_HISTORY=1。
// 【关键】syncFullHistory 只在 browser[0] 是桌面端('Mac OS'/'Windows')时才生效,
// 否则 WhatsApp 只推一点点。改了身份后需要**重新配对**才生效。
const FULL_HISTORY = process.env.WA_FULL_HISTORY === '1';
// 【已拆除】历史回补(BACKFILL)全部移除 —— 永不主动拉历史。
// 但"关机期间别人发来的消息"必须能补收:WhatsApp 重连时会把这段时间的离线消息
// 推给我们(upsert type=append / messaging-history.set)。这里只收**时间窗内**的:
// 窗口默认 72 小时,更早的一律丢弃(等价于不做全量历史导入)。
const OFFLINE_MS = Math.max(1, Number(process.env.WA_OFFLINE_HOURS || 72)) * 3600 * 1000;

// ==================== 断线策略(按“不封号”重新设计)====================
// 旧版:不管什么原因都 4 秒重连,最多 9 次 —— 实测 2 周内断 269 次、自动重连 274 次,
// 属于平台眼里典型的“自动化疯狂重连”。
// 新版:
//   1) 可以自动恢复,但**限速**:两次之间至少 30 秒,每小时最多 12 次,连续失败 4 次就停;
//   2) 硬错误(登出/403/同号别处登录/多设备不匹配)**绝不自动重连**,直接停手等人工;
//   3) 停手后进程退出,界面明确提示“已断开,请点【拉起桥接】”;
//   4) 二维码过期(未配对时的 408)不再循环要码,停手并要求重新扫码。
const AUTO_MIN_GAP_MS = 30 * 1000;
const AUTO_MAX_CHAIN = Math.max(1, Number(process.env.WA_AUTO_MAX_CHAIN || 4));
const AUTO_PER_HOUR = Math.max(1, Number(process.env.WA_AUTO_PER_HOUR || 12));
const RECONNECT = { chain: 0, hits: [] };
let STOPPED = false;      // 已经停手过(避免 close 事件重复触发写状态/退出)
let IS_LINKED = false;    // 当前是否已连上(心跳用)
let MY_ID = null;         // 自己的 WhatsApp 身份
let LAST_CONNECTED = '';  // 上次连上的时间(UTC)
const AUTH_DIR = 'auth';
const QR_FILE = 'qr.png';
const QR_TXT = 'qr.txt';

// ==================== 防封号的三道闸(实测教训)====================
// 1) 单实例:同账号两个进程同时连 → 401 conflict → 封号前兆。
// 2) 二维码冷却:旧版每次重连都重新请求扫码(实测 45 次)→ 被判“刷接口”。
// 3) 永不拉历史:syncFullHistory / backfill 全部关闭。
const LOCK_FILE = 'bridge.lock';
// 【按需扫码】软件不主动要二维码;只有你在界面点【重新扫码】时,才写 pairing.req,
// 桥接看到它才去请求二维码。这样随时可扫,又不会被当成刷接口。
const PAIR_REQ = 'pairing.req';
function pairRequested() { try { return fs.existsSync(PAIR_REQ); } catch (e) { return false; } }
function clearPairReq() { try { fs.unlinkSync(PAIR_REQ); } catch (e) {} }

function otherInstanceAlive() {
  // 【可靠判活】不再用 PID：Windows 的 PID 会被复用,旧 PID 可能是别的进程 →
  // 误判“已有实例在运行”直接退出,表现就是“闪一下就没”。
  // 改探本地小接口(8767):有响应 = 真的有一个桥接在跑。
  return new Promise((resolve) => {
    try {
      const net = require('net');
      const s = net.connect({ host: '127.0.0.1',
                              port: Number(process.env.WA_SIDE_PORT || 8767) });
      let done = false;
      const fin = (v) => { if (done) return; done = true; try { s.destroy(); } catch (e) {} resolve(v); };
      s.setTimeout(800);
      s.on('connect', () => fin(true));
      s.on('timeout', () => fin(false));
      s.on('error', () => fin(false));
    } catch (e) { resolve(false); }
  });
}

async function lockOrExit() {
  if (await otherInstanceAlive()) {
    console.log('[bridge] 已有实例在运行(本地接口有响应),本进程退出');
    console.log('          —— 同账号双连会触发 conflict,这是封号前兆,坚决避免。');
    process.exit(0);
  }
  try { fs.writeFileSync(LOCK_FILE, String(process.pid)); } catch (e) { /* ignore */ }
  process.on('exit', () => {
    try {
      if (fs.readFileSync(LOCK_FILE, 'utf8').trim() === String(process.pid)) fs.unlinkSync(LOCK_FILE);
    } catch (e) { /* ignore */ }
  });
}

// (旧的 30 分钟冷却已移除 —— 改成上面的“按需扫码”)

// 先设代理(必须最先,global-agent 才能接管底层连接)。未配代理则全程直连。
if (proxy) {
  process.env.GLOBAL_AGENT_HTTP_PROXY = proxy;
  process.env.GLOBAL_AGENT_HTTPS_PROXY = proxy;
  process.env.HTTPS_PROXY = proxy;
  process.env.HTTP_PROXY = proxy;
  process.env.GLOBAL_AGENT_NO_PROXY = '127.0.0.1,localhost,::1';
  require('global-agent/bootstrap');
  console.log('[bridge] 已启用代理:', proxy);
} else {
  console.log('[bridge] 未配置代理,直连 WhatsApp(PM用VPN全局模式即可)');
}

const fs = require('fs');
const http = require('http');
const QRCode = require('qrcode');
const pino = require('pino');
const {
  default: makeWASocket,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  DisconnectReason,
  makeCacheableSignalKeyStore,
} = require('@whiskeysockets/baileys');

const logger = pino({ level: 'silent' });
let TOKEN = '';
const seen = new Set();   // 消息去重(LID 与手机号可能各推一次)
let ME_NUMS = new Set();    // 我的号码(真实号 + LID)
let MY_PHONE = '';          // 我自己的真实手机号(连接成功后可取)—— 自己发的话用它归属
// 我方团队(PM/SM/运营):从软件的名册接口拉取 —— 他们的消息**不再丢弃**,
// 而是照常推给软件并标明身份,这样“SM 在群里回了客户”也能计入跟进。
const TEAM_NUMS = new Set();
for (const n of (process.env.WA_TEAM || '').split(',')) {
  const t = n.trim().replace(/^\+/, '');
  if (t) TEAM_NUMS.add(t);
}

async function loadRoster() {
  try {
    const r = await fetch(APP_URL + '/api/team');
    const j = await r.json();
    for (const m of (j.items || [])) {
      const n = String(m.phone || '').replace(/^\+/, '');
      if (n) TEAM_NUMS.add(n);
    }
      if (TEAM_NUMS.size !== rosterCount) {
    rosterCount = TEAM_NUMS.size;
    console.log('[bridge] 团队名册:', TEAM_NUMS.size, '个号码');
  }
  } catch (e) { /* 软件没起来时保持空名册 */ }
}

// 给本地软件的登录页提供连接状态
const STATUS_FILE = 'status.json';
function writeStatus(obj) {
  try {
    fs.writeFileSync(STATUS_FILE,
      JSON.stringify(Object.assign({ updated: new Date().toISOString() }, obj)));
  } catch (e) { /* ignore */ }
}

/**
 * 停手:写清原因、清掉扫码指令、2 秒后退出进程。
 * 退出是刻意的 —— 只有进程真的没了,界面才会显示“已断开,请人工拉起”,
 * 也才不会留下一个“进程在、但永远连不上”的假在线状态。
 */
function stopBridge(kind, reason, needPair) {
  if (STOPPED) return;
  STOPPED = true;
  IS_LINKED = false;
  clearPairReq();
  writeStatus({ linked: false, qr: false, stopped: kind, reason: reason || '',
                need_pair: !!needPair, attempt: RECONNECT.chain });
  console.log('[bridge] ⛔ 已停手(' + kind + '):', reason || '-',
              '| 不再自动重连,等人工点【拉起桥接】');
  setTimeout(() => { try { process.exit(0); } catch (e) {} }, 2000);
}

// 【状态心跳】status.json 只在“二维码/连上/断开”时写,长期连着时 updated 一直不变。
// 主服务用 updated 判断“是不是假在线”,没有心跳会把健康在线误判成 stale。
// 每 60 秒刷新一次;只在已连接时刷新,停手/重连中不写(免得掩盖真实原因)。
setInterval(() => {
  if (!IS_LINKED || STOPPED) return;
  writeStatus({ linked: true, qr: false, me: MY_ID, stopped: '', reconnecting: false,
                attempt: 0, heartbeat: true, last_connected: LAST_CONNECTED });
}, 60 * 1000);

async function getToken() {
  // 从本地客户工作台读取收信令牌(两者都在本机,无需额外配置)
  for (let i = 0; i < 30; i++) {
    try {
      const r = await fetch(APP_URL + '/api/settings');
      const j = await r.json();
      if (j && j.settings && j.settings.ingest_token) {
        return j.settings.ingest_token;
      }
    } catch (e) { /* 应用还没起来,重试 */ }
    await new Promise(r => setTimeout(r, 2000));
  }
  throw new Error('读不到客户工作台的收信令牌,请先启动软件(端口 8765)');
}

function phoneOf(jid) {
  const n = String(jid || '').split('@')[0];
  return n.startsWith('+') ? n : '+' + n;
}

// 新版 WhatsApp 用 LID 身份:remoteJid=<lid>@lid,真实手机号在 remoteJidAlt
function resolveJid(msg) {
  const k = (msg && msg.key) || {};
  for (const c of [k.remoteJidAlt, k.participantAlt, k.remoteJid, k.participant]) {
    if (c && String(c).endsWith('@s.whatsapp.net')) return String(c);
  }
  return String(k.remoteJid || k.participant || '');
}

function numOf(jid) {
  return String(jid || '').split(':')[0].split('@')[0].replace(/^\+/, '');
}

// WhatsApp 新版用 LID(内部身份)代替真号;真号在 key.senderPn / key.participantPn
const LID2PN = new Map();   // LID数字 -> 真实手机号(见过的记住)
const GROUP_NAMES = new Map();  // 群 JID -> 群名(用于标记消息来源)
// WhatsApp 标签:你在 Business 里给会话打的标签会通过 app-state 同步推来。
// labels.edit(定义: id→名字) + labels.association(哪个会话打了哪个标签)。
const WA_LABELS = new Map();   // labelId -> name
const WA_ASSOC = new Map();    // chatId  -> [labelId]
// 【坑】标签/关联只在事件触发时才有,桥接一重启就空 → 软件拿不到旧的标签。持久化。
const LABEL_FILE = 'labels.json';
let labelSaveTimer = null;
function saveLabels() {
  clearTimeout(labelSaveTimer);
  labelSaveTimer = setTimeout(() => {
    try {
      fs.writeFileSync(LABEL_FILE, JSON.stringify({
        labels: Object.fromEntries(WA_LABELS),
        assoc: Object.fromEntries(WA_ASSOC),
      }));
    } catch (e) { /* ignore */ }
  }, 800);
}
try {
  const _l = JSON.parse(fs.readFileSync(LABEL_FILE, 'utf8'));
  for (const k of Object.keys(_l.labels || {})) WA_LABELS.set(k, _l.labels[k]);
  for (const k of Object.keys(_l.assoc || {})) WA_ASSOC.set(k, _l.assoc[k]);
  console.log('[bridge] 已载入标签', WA_LABELS.size, '个 / 关联', WA_ASSOC.size, '个会话');
} catch (e) { /* 首次还没有 */ }
async function pushLabels() {
  try {
    const r = await fetch(APP_URL + '/api/ingest/labels', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token: TOKEN,
        labels: [...WA_LABELS.entries()].map(([id, name]) => ({ id, name })),
        // 同时带上群名 —— 软件那边有的会话是按“群名”绑的,只给 JID 会对不上
        assoc: [...WA_ASSOC.entries()].map(([chat, ids]) => ({
          chat, ids, subject: GROUP_NAMES.get(chat) || '' })) }),
    });
    const j = await r.json().catch(() => ({}));
    console.log('[bridge] 标签已上报:', WA_LABELS.size, '个标签 /', WA_ASSOC.size,
                '个会话', JSON.stringify(j));
  } catch (e) { /* ignore */ }
}
// 【坑】LID→真号 映射以前只在内存里,桥接一重启就丢 —— 丢一次就会把
// “我在直聊里发的话”整批跳过(实测把给 Erika 的回复全丢了)。持久化到磁盘。
const LID_FILE = 'lid2pn.json';
let lidSaveTimer = null;
function saveLidMap() {
  clearTimeout(lidSaveTimer);
  lidSaveTimer = setTimeout(() => {
    try { fs.writeFileSync(LID_FILE, JSON.stringify(Object.fromEntries(LID2PN))); }
    catch (e) { /* ignore */ }
  }, 800);
}
try {
  const _saved = JSON.parse(fs.readFileSync(LID_FILE, 'utf8'));
  for (const k of Object.keys(_saved)) LID2PN.set(k, _saved[k]);
  console.log('[bridge] 已载入 LID→真号 映射', LID2PN.size, '条');
} catch (e) { /* 首次还没有 */ }

/** 这个号码属于谁:me(本机) / team(名册里的同事) / unknown86 / customer。
 * 以前 me 和 team 直接 return 丢掉 —— 结果我方在群里的回复在跟进系统里看不见;
 * 现在只**标注身份**,丢不丢由软件决定(软件知道这个群归哪个客户)。
 */
function classifyNum(n) {
  if (ME_NUMS.has(n)) return 'me';
  if (TEAM_NUMS.has(n)) return 'team';
  if (/^86/.test(n)) return 'unknown86';
  return 'customer';
}

// 群消息的发送者:优先真实号,其次 LID;个人聊天的对方
function senderJid(msg) {
  const k = (msg && msg.key) || {};
  const remote = String(k.remoteJid || '');
  if (remote.endsWith('@g.us')) {
    return String(k.participantAlt || k.participant || remote);
  }
  return String(k.remoteJidAlt || k.remoteJid || '');
}

function textOf(msg) {
  const m = msg && msg.message;
  if (!m) return null;
  if (m.conversation) return m.conversation;
  if (m.extendedTextMessage) return m.extendedTextMessage.text || null;
  // 媒体消息:只记录类型和文件名,不下载实际内容(避免风控)
  // 文档文件名很重要,AI可以通过文件名判断是不是报价单
  if (m.documentMessage) {
    const fn = m.documentMessage.fileName || '';
    return fn ? ('[文档] ' + fn) : '[文档]';
  }
  if (m.imageMessage) {
    const cap = m.imageMessage.caption || '';
    return cap ? ('[图片] ' + cap) : '[图片]';
  }
  if (m.videoMessage) {
    const cap = m.videoMessage.caption || '';
    return cap ? ('[视频] ' + cap) : '[视频]';
  }
  if (m.audioMessage) return '[语音]';
  if (m.stickerMessage) return '[贴纸]';
  if (m.contactMessage) return '[名片]';
  if (m.locationMessage) return '[位置]';
  if (m.reactionMessage) return null;   // 表情回应不入库
  return null;
}

function tsOf(msg) {
  if (msg && msg.messageTimestamp) {
    const d = new Date(msg.messageTimestamp * 1000);
    const p = n => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ` +
           `${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
  }
  return null;
}

/** 消息毫秒时间戳(protobuf Long 也兼容)。拿不到返回 0。 */
function tsMs(msg) {
  const t = msg && msg.messageTimestamp;
  const n = Number(t && typeof t === 'object' ? (t.low !== undefined ? t.low : t) : t);
  return Number.isFinite(n) && n > 0 ? n * 1000 : 0;
}

/** 是否在“开机补收窗口”内。没有时间戳的按新消息处理,避免误丢。 */
function freshEnough(msg) {
  const t = tsMs(msg);
  if (!t) return true;
  return (Date.now() - t) >= 0 && (Date.now() - t) <= OFFLINE_MS;
}

// 历史同步进度(供界面显示)
const HIST = { started: null, chats: 0, messages: 0, progress: 0, done: false };
// 诊断计数:历史里每条消息到底是被丢了还是入库了
const STAT = { offered: 0, empty: 0, noSender: 0, sent: 0, accepted: 0 };
const TOUCHED = new Set();      // 本次历史同步涉及到的客户 id
const OLDEST = new Map();       // 会话 -> 已知最早那条消息(key+时间),回补用
// 【坑】锚点以前只在内存里:桥接一重启,回补就“no-anchor”,历史再也拉不回来。持久化。
const OLDEST_FILE = 'oldest.json';
let oldestSaveTimer = null;
function saveOldest() {
  clearTimeout(oldestSaveTimer);
  oldestSaveTimer = setTimeout(() => {
    try { fs.writeFileSync(OLDEST_FILE, JSON.stringify(Object.fromEntries(OLDEST))); }
    catch (e) { /* ignore */ }
  }, 1000);
}
try {
  const _o = JSON.parse(fs.readFileSync(OLDEST_FILE, 'utf8'));
  for (const k of Object.keys(_o)) OLDEST.set(k, _o[k]);
  console.log('[bridge] 已载入回补锚点', OLDEST.size, '个会话');
} catch (e) { /* 首次还没有 */ }
let SOCK = null;                // 当前 socket(回补用)
const DEBUG_SAMPLE = process.env.WA_DEBUG_SAMPLE === '1';
let sampleWritten = 0;
let dumpBulkLeft = DEBUG_SAMPLE ? 60 : 0;   // 前 N 条批量消息连回应一起存到 bulk-debug.jsonl

async function reportHistory() {
  try {
    await fetch(APP_URL + '/api/history/status', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(Object.assign({ token: TOKEN }, HIST)),
    });
  } catch (e) { /* 软件没起来就算了 */ }
}

async function historyDone() {
  HIST.done = true;
  await reportHistory();
  try {
    const r = await fetch(APP_URL + '/api/ingest/bulk-done', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token: TOKEN, customer_ids: [...TOUCHED] }),
    });
    const j = await r.json().catch(() => ({}));
    console.log('[bridge] 历史导入完成:消息', HIST.messages, '条 / 客户', TOUCHED.size,
                '个 → 补分析', JSON.stringify(j));
  } catch (e) {
    console.log('[bridge] 上报历史完成失败:', e.message);
  }
}

// 把一条历史消息的“原始结构”写一份出来,方便看清为什么拿不到发送者
function dumpSample(msg) {
  if (!DEBUG_SAMPLE || sampleWritten >= 12) return;
  sampleWritten++;
  try {
    const k = (msg && msg.key) || {};
    const rec = {
      remoteJid: k.remoteJid, fromMe: k.fromMe, participant: k.participant,
      participantPn: k.participantPn, senderPn: k.senderPn, participantAlt: k.participantAlt,
      remoteJidAlt: k.remoteJidAlt, pushName: msg.pushName,
      msgKeys: Object.keys(msg.message || {}),
    };
    fs.appendFileSync('history-sample.jsonl', JSON.stringify(rec) + '\n');
  } catch (e) { /* ignore */ }
}

/** 从名片(vCard)里抠出手机号 —— 运营在群里发“客户名片”时,号码就在里面。 */
function vcardPhone(msg) {
  const m = (msg && msg.message) || {};
  const c = m.contactMessage || m.contactsArrayMessage || null;
  if (!c) return null;
  const v = c.vcard || ((c.contacts || [])[0] || {}).vcard || '';
  if (!v) return null;
  const tel = /TEL[^:]*:(.+)/i.exec(v);
  const fn = /FN[^:]*:(.+)/i.exec(v);
  const num = tel ? numOf(String(tel[1]).trim().split(/[;\\s]/)[0]) : '';
  if (!num || num.length < 7) return null;
  return { phone: num, name: fn ? String(fn[1]).trim() : '' };
}

/** 把号码提示推给软件:如果这个会话对应的客户还没号码,就补上。 */
async function pushPhoneHint(chat, chatJid, phone, name) {
  try {
    await fetch(APP_URL + '/api/ingest/phone-hint', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token: TOKEN, chat: chat, chat_jid: chatJid || '',
                             phone: phone, name: name || '' }),
    });
    console.log('[bridge] 名片号码已上报:', chat, phone);
  } catch (e) { /* ignore */ }
}

async function pushToApp(p) {
  const body = {
    token: TOKEN,
    bulk: p.bulk ? 1 : 0,          // 历史导入:只落库+打标签,不生成提醒/不进 AI 队列
    phone: p.phone ? ("+" + p.phone) : "",
    name: (p.name || "").trim(),
    content: (p.content || "").trim(),
    direction: p.direction,
    source: p.source,
    chat: p.chat || "",
    chat_jid: p.chatJid || "",       // 会话的 JID:私聊里就是**对方号码** —— 归属靠它
    ts: p.ts || null,
    sender_role: p.senderRole || "customer",
  };
  try {
    const r = await fetch(APP_URL + "/api/ingest", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const j = await r.json().catch(() => ({}));
    // 诊断:把前 60 条批量消息的“报文 + 软件回应”原样存下来(排查为什么被跳)
    if (p.bulk && dumpBulkLeft > 0) {
      dumpBulkLeft--;
      try {
        const safe = Object.assign({}, body);
        delete safe.token;
        fs.appendFileSync('bulk-debug.jsonl',
          JSON.stringify({ sent: safe, reply: j }) + '\n');
      } catch (e) { /* ignore */ }
    }
    if (r.ok) {
      if (p.bulk) {
        STAT.sent++;
        if (!j.skipped) STAT.accepted++;
      } else {
        console.log("[bridge] 转发成功:", body.direction, body.phone);   // 不打印消息正文(隐私)
      }
      return j;
    }
    console.log("[bridge] 推送失败", r.status, body.phone, JSON.stringify(j));
    return null;
  } catch (e) {
    console.log("[bridge] 推送异常:", e.message);
    return null;
  }
}

async function forward(msg, bulk = false) {
  const k = (msg && msg.key) || {};
  const remote = String(k.remoteJid || "");
  if (remote.endsWith("status@broadcast")) return;   // 状态广播不要
  if (k.id) {                                        // 去重(历史与实时可能重复推)
    if (seen.has(k.id)) return;
    seen.add(k.id);
    if (seen.size > 5000) seen.clear();
  }
  const isGroup = remote.endsWith("@g.us");
  const chatKey = String(k.remoteJid || "");
  if (bulk) { STAT.offered++; dumpSample(msg); }

  const content = textOf(msg);
  if (!content || !content.trim()) {
    if (bulk) STAT.empty++;
    return;
  }
  // 【坑】历史同步里的群消息,发送者不一定在 key.participant —— 也可能在消息体的
  //       msg.participant / msg.participantPn(实测一批历史消息卡在这里被丢)。
  const partJid = k.participant || msg.participant || "";
  const who = isGroup ? String(partJid || remote) : String(k.remoteJid || "");
  const pn = isGroup ? (k.participantPn || msg.participantPn || null)
                     : (k.fromMe ? null : k.senderPn);
  if (pn && numOf(who)) { LID2PN.set(numOf(who), numOf(pn)); saveLidMap(); }
  // 真号优先级:见过的 LID→真号 映射 > who 本身是真号 > participantPn/senderPn。
  // 【坑】拿不到真号时绝不回退用 LID 内部号(会建假客户)。
  let realNum = LID2PN.get(numOf(who))
    || (who.endsWith("@s.whatsapp.net") ? numOf(who) : "")
    || numOf(pn) || "";
  // 我自己在**群里**发的话,发送者是我的 LID → 用本机号归属(群靠 chat 归属,不靠 phone)。
  // 【坑】只对群生效!私聊里对方常是未映射的 LID,以前这个兜底会把“对方的号码”
  //      写成我自己的号 → 软件拿我号去找客户,找不到就整条丢掉(实测 3898 条)。
  if (!realNum && k.fromMe && MY_PHONE && isGroup) realNum = MY_PHONE;
  if (!realNum && isGroup && ME_NUMS.has(numOf(who)) && MY_PHONE) realNum = MY_PHONE;

  const chatName = isGroup ? (GROUP_NAMES.get(remote) || remote) : chatKey;
  const ts = tsOf(msg);

  if (!realNum) {
    // 直聊:对方也是未映射的 LID(现在 WhatsApp 很常见)。号码暂时不知道,
    // 但**按会话把消息推给软件** —— 软件按 chat 绑定就能归到人,
    // 总比把“我自己的回复”整条丢掉好(踩过:给 Erika 的回复全丢)。
    if (!isGroup && chatKey) {
      return await pushToApp({ bulk, phone: "", name: msg.pushName || "", content,
                               direction: k.fromMe ? "out" : "in", source: "direct",
                               chat: chatKey, ts, senderRole: k.fromMe ? "me" : "customer" });
    }
    // 群消息拿不到发送者:仍然推给软件 —— 软件知道这个群归哪个客户,
    // 会归到该客户名下并标「群成员(未识别)」,总比整条丢掉好。
    if (isGroup) {
      STAT.noSender++;
      if (STAT.noSender <= 5) {
        console.log("[bridge] 群消息无发送者,按群归属:", remote,
                    "| part=" + (partJid || "-"));
      }
      return await pushToApp({ bulk, phone: "", name: msg.pushName || "", content,
                               direction: k.fromMe ? "out" : "in", source: "group",
                               chat: chatName, ts, senderRole: "unknown" });
    }
    if (bulk) STAT.noSender++;
    if (!bulk || STAT.noSender <= 5) {
      console.log("[bridge] 拿不到真实手机号(LID 尚未映射),本条跳过:", String(who));
    }
    return;
  }

  // 记住每个会话“已知最早的一条” → 按需回补更老的历史时要拿它当锚点
  try {
    const chatKey = isGroup ? remote : String(k.remoteJid || "");
    const prev = OLDEST.get(chatKey);
    if (!prev || String(msg.messageTimestamp || 0) < String(prev.ts || 0)) {
      OLDEST.set(chatKey, { key: k, ts: msg.messageTimestamp });
      saveOldest();
    }
  } catch (e) { /* ignore */ }

  // 群里有人发了“联系人名片” → 名片里带真号,直接用来补客户档
  const card = vcardPhone(msg);
  if (card && isGroup) { pushPhoneHint(chatName, remote, card.phone, card.name).catch(() => {}); }

  const whoRole = classifyNum(realNum);   // me / team / unknown86 / customer
  return await pushToApp({
    bulk, phone: realNum, name: msg.pushName || "", content,
    direction: (k.fromMe || whoRole === "me" || whoRole === "team") ? "out" : "in",
    source: isGroup ? "group" : "direct", chat: chatName, ts, senderRole: whoRole,
    // 【关键】私聊里 remoteJid 就是对方的号 —— 我方发言时,只有靠它才能归到正确客户
    chatJid: remote,
  });
}

// ---------- 只读本地小接口(127.0.0.1):给“补客户手机号/相关人”用 ----------
// 群名里没有号码,历史消息也拿不到成员号码 —— 但向 WhatsApp 拉群成员名单可以直接拿到。
const SIDE_PORT = Number(process.env.WA_SIDE_PORT || 8767);
let sideStarted = false;
function phoneOfJid(jid) {
  const n = numOf(jid);
  return LID2PN.get(n) || (/@s\.whatsapp\.net$/.test(String(jid)) ? n : '');
}
function startSideApi() {
  if (sideStarted) return;
  sideStarted = true;
  http.createServer(async (req, res) => {
    const u = new URL(req.url, 'http://127.0.0.1');
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    try {
      if (u.pathname === '/groups') {
        const groups = [...GROUP_NAMES.entries()].map(([jid, subject]) => ({ jid, subject }));
        return res.end(JSON.stringify({ groups, count: groups.length }));
      }
      // 【人工停手】监管者优先用它优雅停机:不用 taskkill、不闪黑窗、也不会误杀别的 node。
      if (u.pathname === '/shutdown') {
        res.end('{"ok":true}');
        setTimeout(() => { try { process.exit(0); } catch (e) {} }, 300);
        return;
      }
      // 向 WhatsApp 拉“我参与的全部群”(带群名)→ 用于把群对应到客户
      if (u.pathname === '/allgroups') {
        if (!SOCK) { res.statusCode = 400; return res.end('{"error":"未连接"}'); }
        const all = await SOCK.groupFetchAllParticipating();
        const groups = Object.values(all).map(g => ({
          jid: g.id, subject: g.subject || '',
          count: (g.participants || []).length,
          created: g.creation || 0,
        }));
        return res.end(JSON.stringify({ groups, count: groups.length }));
      }
      // 手动触发一次回补(把某个会话被丢掉的历史捞回来)
      if (u.pathname === '/labels') {
        return res.end(JSON.stringify({ labels: Object.fromEntries(WA_LABELS),
          assoc: Object.fromEntries(WA_ASSOC) }));
      }
      if (u.pathname === '/resync') {
        if (!SOCK || !SOCK.resyncAppState) { res.statusCode = 400; return res.end('{}'); }
        await SOCK.resyncAppState(['critical_unblock_low', 'regular_high', 'regular_low',
                                 'critical_block', 'regular'], true);
        return res.end(JSON.stringify({ ok: true }));
      }
      if (u.pathname === '/lidmap') {
        return res.end(JSON.stringify({ count: LID2PN.size,
                                        map: Object.fromEntries(LID2PN) }));
      }
      // 【已拆除】原 /backfill 端点 —— 它调 fetchMessageHistory 拉历史,是封号高危项。
      // 需要历史用软件里的「一次性导入历史」(官方导出,零风险)。
      if (u.pathname === '/members') {
        const jid = u.searchParams.get('jid');
        if (!jid || !SOCK) { res.statusCode = 400; return res.end('{"error":"没有 jid 或未连接"}'); }
        const md = await SOCK.groupMetadata(jid);
        // LID → 真号:①见过的映射 ②Baileys 自带的 lid 映射仓 ③向 WhatsApp 反查
        const lidMap = (SOCK.signalRepository && SOCK.signalRepository.lidMapping) || null;
        const resolve = async (p) => {
          let ph = phoneOfJid(p.id) || numOf(p.phoneNumber || p.phone || '');
          if (!ph && lidMap && lidMap.getPNForLID) {
            try { ph = numOf(await lidMap.getPNForLID(String(p.id))); } catch (e) {}
          }
          if (!ph && String(p.id).endsWith('@lid')) {
            try {
              const r = await SOCK.onWhatsApp(String(p.id));
              if (r && r[0]) ph = numOf(r[0].jid || r[0].phoneNumber || '');
            } catch (e) {}
          }
          return ph || '';
        };
        const members = [];
        for (const p of (md.participants || [])) {
          members.push({ jid: String(p.id || ''), phone: await resolve(p),
                         name: p.name || p.notify || '', admin: p.admin || '' });
        }
        return res.end(JSON.stringify({ jid, subject: md.subject || '', members }));
      }
      res.statusCode = 404;
      res.end('{}');
    } catch (e) {
      res.statusCode = 500;
      res.end(JSON.stringify({ error: e.message }));
    }
  }).listen(SIDE_PORT, '127.0.0.1',
    () => console.log('[bridge] 本地小接口已开: http://127.0.0.1:' + SIDE_PORT))
    .on('error', (e) => {
      // 端口被占 = 另有一份桥接在跑(例如“重新扫码”时旧进程没停干净)。
      // 此时绝不能继续连 WhatsApp:同号双连会触发 conflict(封号前兆)。
      console.log('[bridge] 本地小接口起不来(端口 ' + SIDE_PORT + ' 被占):', e.message);
      stopBridge('side-port-busy', '端口 ' + SIDE_PORT + ' 已被另一份桥接占用,本进程退出避免双连');
    });
}

/* 【已拆除】backfillChat / backfillRound —— 回补历史 = fetchMessageHistory,
 * 实测是封号加速器,已彻底移除。历史改用软件里的“一次性导入”。*/

let starting = false;
let rosterTimer = null;
let rosterCount = -1;
let pairWaitLogged = false;   // “未配对等待扫码”的日志只打一次
async function start() {
  if (starting) return;
  starting = true;
  // 单实例检测:只有首次启动才检测,重连时本进程的side API还在监听,不能误判成其他实例
  if (!sideStarted) {
    await lockOrExit();
    // 【侧口必须尽早开】未配对、等二维码的空闲进程也要有侧口:
    // 监管者/软件靠 /shutdown 优雅停机,靠“端口有响应”判断进程是否真在跑。
    // 原来放在 makeWASocket 之后 → 空闲进程没有侧口 → 旧进程停不掉 → 双连风险。
    startSideApi();
  }
  TOKEN = await getToken();
  await loadRoster();
  // 名册每 5 分钟重拉一次:在软件里新加一个 SM,不用重启桥接就能生效
  // (只在数量变了才打印,避免日志刷屏)
  if (!rosterTimer) rosterTimer = setInterval(loadRoster, 5 * 60 * 1000);
  const { state, saveCreds } = await useMultiFileAuthState(AUTH_DIR);
  // 【按需扫码】没配对且没有扫码指令 → 不连接(不主动要二维码);每 3 秒看一次指令
  // 【关键】用 me/registered 一起判:实测已链接的会话 registered=false 但 me 有值,
  //        只看 registered 会把已链接的会话误判成未配对 → 收信停摆。
  const paired = !!(state.creds && (state.creds.me || state.creds.registered));
  // 已经配对却还留着扫码指令(上次没扫成 / 手工动了 auth)→ 清掉,避免“一重启就要码”
  if (paired && pairRequested()) clearPairReq();
  // 每次启动/重连都刷新状态:让界面知道“正在连”,而不是沿用上一次的停手原因
  writeStatus({ linked: false, qr: false, stopped: '',
                reconnecting: RECONNECT.chain > 0, attempt: RECONNECT.chain,
                offline_hours: Math.round(OFFLINE_MS / 3600000) });
  if (!paired && !pairRequested()) {
    // 这个等待循环每 3 秒跑一次,日志只打一次,免得把 bridge.log 刷成几千行
    if (!pairWaitLogged) {
      pairWaitLogged = true;
      console.log('[bridge] 未配对,且没有扫码指令 —— 不主动请求二维码(避免被判刷接口)。');
      console.log('         在软件里点【重新扫码】即可开始。');
    }
    writeStatus({ linked: false, qr: false, stopped: 'awaiting-pair-request' });
    starting = false;
    setTimeout(() => { try { start(); } catch (e) {} }, 3000);
    return;
  }
  // 获取WhatsApp版本:联网失败时用内置默认版本,避免整个桥接崩溃
  let version;
  try {
    const fetched = await fetchLatestBaileysVersion();
    version = fetched.version;
    console.log('[bridge] WhatsApp版本(在线获取):', version.join('.'));
  } catch (e) {
    version = [2, 3000, 1015901436];  // baileys 6.7.24 对应的稳定版本
    console.log('[bridge] 在线获取版本失败,使用默认版本:', version.join('.'), '原因:', e.message);
  }
  const sock = makeWASocket({
    version,
    logger,
    printQRInTerminal: true,
    // 身份可切换(WA_BROWSER):实测 'Mac OS' 这种桌面端身份会被 WhatsApp 直接断开(428),
    // 所以默认仍用普通 Web 身份;想试全量同步再手动切。
    browser: [process.env.WA_BROWSER || 'Chrome', 'Chrome', '1.0.0'],
    // 【永不拉历史】宁可少几条,不要再来一次封号。
    syncFullHistory: false,
    // —— 稳定性参数(要求:连上就稳、不掋)——
    keepAliveIntervalMs: 25000,        // 25 秒心跳,及时发现自己掉了
    connectTimeoutMs: 60000,           // 连接超时给足(代理链较慢)
    defaultQueryTimeoutMs: 60000,
    retryRequestDelayMs: 2000,
    markOnlineOnConnect: false,        // 不把已读/在线状态搞乱
    generateHighQualityLinkPreview: false,
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, logger),
    },
    // 只收不发:这里刻意不注册任何发送逻辑
  });

  SOCK = sock;
  // 侧口已在 start() 开头开启(幂等),这里不再重复调用
  sock.ev.on('creds.update', saveCreds);

  sock.ev.on('connection.update', (u) => {
    const { connection, qr, lastDisconnect } = u;
    if (qr) {
      // 【按需扫码】能走到这里,说明是你点了【重新扫码】—— 直接把码写出来,随时可扫,无冷却。
      QRCode.toFile(QR_FILE, qr, { width: 400, margin: 1 }, (e) => {
        if (!e) console.log('[bridge] 二维码已生成 ->', QR_FILE, '(用手机扫)');
      });
      fs.writeFileSync(QR_TXT, qr);
      writeStatus({ linked: false, qr: true });
    }
    if (connection === 'open') {
      console.log('[bridge] ✅ 已连接 WhatsApp(只收不发)');
      if (sock.user) {
        ME_NUMS.add(numOf(sock.user.id));
        if (sock.user.lid) ME_NUMS.add(numOf(sock.user.lid));
        MY_PHONE = numOf(sock.user.id) || MY_PHONE;
        console.log('[bridge] 本机号码:', sock.user.id, '| LID:', sock.user.lid || '-',
                    '| 归属用号:', MY_PHONE);
      }
      writeStatus({ linked: true, qr: false, me: sock.user ? sock.user.id : null,
                    stopped: '', reconnecting: false, attempt: 0,
                    last_connected: LAST_CONNECTED || new Date().toISOString() });
      IS_LINKED = true;
      MY_ID = sock.user ? sock.user.id : null;
      LAST_CONNECTED = LAST_CONNECTED || new Date().toISOString();
      clearPairReq();            // 配对成功 → 清掉扫码指令,以后重启不再要二维码
      RECONNECT.chain = 0;       // 连上了,连续失败计数与限速计数归零
      RECONNECT.hits = [];
      starting = false;
      // 连上先把“全部群的 JID↔群名”拉齐(标签关联是按 JID 给的,软件里是按群名绑的),
      // 然后再把标签推过去 —— 否则 100 个按群名绑的客户都匹配不上。
      (async () => {
        try {
          const all = await sock.groupFetchAllParticipating();
          for (const g of Object.values(all || {})) {
            if (g && g.id && g.subject) GROUP_NAMES.set(g.id, g.subject);
          }
          console.log('[bridge] 群名表已刷新:', GROUP_NAMES.size, '个群');
        } catch (e) {
          console.log('[bridge] 群名表刷新失败:', e.message);
        }
        await pushLabels().catch(() => {});   // 有持久化,不必再判断 size
      })();
      // 【已拆】以前这里会在连上 90 秒后自动“回补历史”。
      // 实测:频繁拉历史是封号的主要加速器之一 —— 已彻底移除。
      // 需要历史请用软件里的「导出+导入」(零风险)。
    }
    if (connection === 'close') {
      const err = (lastDisconnect && lastDisconnect.error) || {};
      const code = (err.output && err.output.statusCode) || err.statusCode;
      const reason = (err.output && err.output.payload && err.output.payload.message) ||
                     err.message || '';
      console.log('[bridge] 连接断开, code =', code, '| reason =', reason || '-');
      starting = false;
      IS_LINKED = false;
      SOCK = null;

      // ① 硬错误:再连也没用,而且高频重连会被判自动化 —— 直接停手,等人工处理。
      if (code === DisconnectReason.loggedOut) {
        stopBridge('logged-out', '会话已失效,需要重新扫码', true);
        return;
      }
      if (code === DisconnectReason.forbidden || code === 403) {
        stopBridge('forbidden-403', '被 WhatsApp 拒绝(403),账号可能被限制', false);
        return;
      }
      if (code === DisconnectReason.connectionReplaced || code === 440) {
        stopBridge('conflict', '同一账号在别处登录(440),已停手避免双连', false);
        return;
      }
      if (code === DisconnectReason.multideviceMismatch || code === 411) {
        stopBridge('device-mismatch', '多设备身份不匹配(411),需要重新扫码', true);
        return;
      }
      // ② 还没配对:任何断开都不再自动重连(否则会反复请求二维码,最容易被判“刷接口”)。
      if (!paired) {
        stopBridge(code === 408 ? 'qr-expired' : 'pair-failed',
                   code === 408 ? '二维码已过期,请重新点【重新扫码】'
                                : '配对过程中连接中断,请重新扫码', true);
        return;
      }
      // ③ 其余按“限速自动恢复”处理:最短 30 秒、每小时最多 12 次、连续失败 4 次即停。
      const now = Date.now();
      RECONNECT.hits = RECONNECT.hits.filter(t => now - t < 3600 * 1000);
      if (RECONNECT.chain >= AUTO_MAX_CHAIN) {
        stopBridge('too-many-failures', '连续 ' + RECONNECT.chain + ' 次连不上', false);
        return;
      }
      if (RECONNECT.hits.length >= AUTO_PER_HOUR) {
        stopBridge('reconnect-rate-limit',
                   '1 小时内自动重连已达 ' + RECONNECT.hits.length + ' 次', false);
        return;
      }
      RECONNECT.chain += 1;
      RECONNECT.hits.push(now);
      const delay = (code === DisconnectReason.restartRequired) ? 2000
        : Math.min(AUTO_MIN_GAP_MS * Math.pow(2, RECONNECT.chain - 1), 5 * 60 * 1000);
      writeStatus({ linked: false, qr: false, stopped: '', reconnecting: true,
                    attempt: RECONNECT.chain, code: code || null, reason: reason });
      console.log('[bridge] 将在', Math.round(delay / 1000), '秒后自动重连(第',
                  RECONNECT.chain, '次 / 每小时上限', AUTO_PER_HOUR, ')');
      setTimeout(() => { try { start(); } catch (e) {} }, delay);
    }
  });

  // 实时消息 + 关机期间补收
  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    const list = messages || [];
    let fwd = 0, skip = 0;
    for (const m of list) {
      // notify = 实时新消息; append = 重连时服务端补推的**离线消息**
      // (旧版直接丢掉 append,导致“关机期间收到的消息”开机后收不到)
      if (type === 'notify') {
        await forward(m);
        fwd += 1;
        continue;
      }
      if (type === 'append') {
        if (!freshEnough(m)) { skip += 1; continue; }   // 超出补收窗口的老消息:不导入
        await forward(m);
        fwd += 1;
        continue;
      }
      skip += 1;
    }
    if (list.length) {
      console.log('[bridge] upsert 类型=%s 总数=%d 入库=%d 跳过=%d',
                  type, list.length, fwd, skip);
    }
  });

  // 配对/按需拉取时 WhatsApp 推来的历史(全量同步走这里)
  // 联系人表(LID ↔ 真号 ↔ 备注名):历史同步与实时都会推。存下来就能给
  // “还没发言的群成员”补出号码 —— 这是除“对方发言”之外唯一的号码来源。
  async function pushContacts(list) {
    const out = [];
    for (const c of (list || [])) {
      const id = String((c && (c.id || c.jid)) || '');
      const lid = String((c && (c.lid || '')) || '');
      const pn = numOf((c && (c.jid || c.id)) || '');
      if (lid && numOf(lid)) LID2PN.set(numOf(lid), LID2PN.get(numOf(lid)) || pn || '');
      out.push({ jid: id, lid: lid || '', phone: (/@s\.whatsapp\.net$/.test(id) ? pn : ''),
                 name: (c && (c.name || c.notify || c.verifiedName)) || '' });
    }
    if (!out.length) return;
    try {
      await fetch(APP_URL + '/api/ingest/contacts', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token: TOKEN, contacts: out.slice(0, 2000) }),
      });
      console.log('[bridge] 联系人表已上报', out.length, '条');
    } catch (e) { /* 软件没起来就算了 */ }
  }
  // WhatsApp 标签(客户分级)的事件监听;映射表在模块级(小接口也要用)
  sock.ev.on('labels.edit', (l) => {
    if (!l || !l.id) return;
    if (l.deleted) WA_LABELS.delete(l.id); else WA_LABELS.set(l.id, l.name || '');
    saveLabels();
    pushLabels().catch(() => {});
  });
  sock.ev.on('labels.association', (a) => {
    if (!a || !a.association) return;
    const chat = String(a.association.chatId || a.association.id || '');
    const lid = String(a.association.labelId || '');
    if (!chat || !lid) return;
    const cur = new Set(WA_ASSOC.get(chat) || []);
    if (a.type === 'add') cur.add(lid); else cur.delete(lid);
    WA_ASSOC.set(chat, [...cur]);
    saveLabels();
    pushLabels().catch(() => {});
  });

  sock.ev.on('contacts.upsert', (list) => { pushContacts(list).catch(() => {}); });
  sock.ev.on('contacts.update', (list) => { pushContacts(list).catch(() => {}); });

  sock.ev.on('messaging-history.set', async ({ chats, contacts, messages: histMsgs, syncType, progress }) => {
    if (Array.isArray(contacts) && contacts.length) {
      pushContacts(contacts).catch(() => {});
    }
    if (!HIST.started) HIST.started = new Date().toISOString();
    if (typeof progress === 'number') HIST.progress = progress;
    // 【开机补收】只导入“关机期间”窗口内的消息,更早的历史一律丢弃(不做全量历史导入)。
    // 旧版这里会把 WhatsApp 推来的一切都入库 → 等于变相导入历史,既慢又有封号风险。
    let n = 0, old = 0;
    const eat = async (m) => {
      if (!freshEnough(m)) { old += 1; return; }
      const out = await forward(m);
      if (out && out.customer_id) TOUCHED.add(out.customer_id);
      n += 1;
    };
    if (Array.isArray(chats)) {
      for (const chat of chats) {
        const jid = String((chat && (chat.id || chat.jid)) || '');
        const nm = String((chat && (chat.name || chat.subject)) || '').trim();
        if (jid.endsWith('@g.us') && nm) GROUP_NAMES.set(jid, nm);
        for (const m of (chat.messages || [])) await eat(m);
      }
    }
    if (Array.isArray(histMsgs)) {
      for (const m of histMsgs) await eat(m);
    }
    HIST.chats += (chats || []).length;
    HIST.messages += n;
    console.log('[bridge] 离线补收(窗口 %d 小时): 本次入库 %d 条 / 跳过更早 %d 条'
                + ' | 累计 %d | 空内容 %d / 拿不到发送者 %d / 推给软件 %d / 真正入库 %d',
                Math.round(OFFLINE_MS / 3600000), n, old, HIST.messages,
                STAT.empty, STAT.noSender, STAT.sent, STAT.accepted);
    await reportHistory();
    // 同步包是分批来的:等 15 秒确认没有后续包再收尾,让软件把补收的客户重新判一遍
    clearTimeout(HIST._t);
    HIST._t = setTimeout(() => { historyDone(); }, 15000);
  });
}

start().catch(e => {
  console.error('[bridge] 启动失败:', e.message);
  process.exit(1);
});
