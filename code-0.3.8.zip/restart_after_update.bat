@echo off
rem 更新重启(手动/兜底入口):实际逻辑都在 app\restart_helper.py,
rem 这样「更新包」和「手动双击」走同一套流程,不会出现两套行为。
rem 顺序:停桥接 → 杀掉本软件所有进程(含旧窗口) → 等端口释放 → 完整拉起(服务+窗口)。
cd /d "%~dp0"
if exist "python\pythonw.exe" (
    start "" /min "python\pythonw.exe" "app\restart_helper.py"
) else (
    start "" /min python "app\restart_helper.py"
)
exit /b 0
