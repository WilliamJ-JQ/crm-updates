@echo off
title Stop CRM Workstation
setlocal
set "APP_DIR=%~dp0"
if "%APP_DIR:~-1%"=="\" set "APP_DIR=%APP_DIR:~0,-1%"

echo ========================================
echo   Stopping CRM processes in:
echo   %APP_DIR%
echo ========================================
echo.

taskkill /f /im "CRMWorkstation.exe" >nul 2>&1
taskkill /f /im "?????.exe" >nul 2>&1

rem 只结束“命令行里带本目录”的 python/node/llama 进程,
rem 避免把同机其它 Python 程序或另一份客户工作台的桥接一起杀掉。
powershell -NoProfile -Command "$d='%APP_DIR%'.ToLower(); $names=@('python.exe','pythonw.exe','node.exe','llama-server.exe','python-translate.exe'); Get-CimInstance Win32_Process | Where-Object { $_.ProcessId -ne $PID -and $_.Name.ToLower() -in $names -and $_.CommandLine -and $_.CommandLine.ToLower().Contains($d) } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }"

echo.
echo ========================================
echo   All processes stopped
echo ========================================
echo.
timeout /t 3 /nobreak >nul
exit /b 0
