"""后台翻译模块:导入消息后自动翻译所有英文消息。"""
import os
import threading
import time
import re
import urllib.request
import json

from . import db


# 翻译端口:正式版 8766 / 开发者版 8769。main.py 会把实际端口写进 TRANSLATE_PORT;
# 这里必须“用到时才读”,不能在 import 时定死 —— app.server 比 main() 先导入本模块。
def translate_url():
    return "http://127.0.0.1:%s/translate-batch" % (
        os.environ.get("TRANSLATE_PORT") or "8766")


BATCH_SIZE = 10  # 每批翻译10条


def is_english(text):
    """判断是否主要是英文(需要翻译)。"""
    if not text or not text.strip():
        return False
    letters = re.findall(r'[a-zA-Z]', text)
    if len(letters) < 3:
        return False
    chinese = re.findall(r'[\u4e00-\u9fff]', text)
    total = len(text.strip())
    if total == 0:
        return False
    return (len(letters) / total > 0.2) and (len(chinese) / total < 0.5)


def needs_translation(text):
    """判断是否需要翻译(英文/西班牙语/法语等非中文)。"""
    if not text or not text.strip():
        return False
    # 中文不需要翻译
    chinese = re.findall(r'[\u4e00-\u9fff]', text)
    total = len(text.strip())
    if total == 0:
        return False
    if len(chinese) / total > 0.5:
        return False
    # 有英文字母或罗曼语系特征字符就需要翻译
    letters = re.findall(r'[a-zA-Zñáéíóúüçèêëàâùûôîïÿ]', text)
    return len(letters) >= 3


def _call_translate_batch(texts, timeout=60):
    """调用翻译服务批量翻译。失败返回None。"""
    try:
        data = json.dumps({"texts": texts}).encode("utf-8")
        req = urllib.request.Request(
            translate_url(),
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST"
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            result = json.loads(resp.read().decode("utf-8"))
            return result.get("translations")
    except Exception as e:
        print(f"[bg_translate] 批量翻译失败: {e}")
        return None


def start_bg_translate(customer_id, customer_name=""):
    """启动后台翻译线程。"""
    t = threading.Thread(target=_bg_translate_worker, args=(customer_id, customer_name), daemon=True)
    t.start()
    return t


def _bg_translate_worker(customer_id, customer_name):
    """后台翻译工作线程。"""
    task_id = None
    done = 0
    try:
        # 获取未翻译的消息
        msgs = db.get_untranslated_messages(customer_id, limit=1000)
        if not msgs:
            return

        # 只翻译非中文消息(英文/西班牙语/法语等)
        en_msgs = [m for m in msgs if needs_translation(m["content"])]
        if not en_msgs:
            return

        total = len(en_msgs)
        task_id = db.create_translation_task(customer_id, customer_name, total)

        # 批量翻译
        for i in range(0, total, BATCH_SIZE):
            # 每批翻译前检查客户是否还存在(客户被删除时停止翻译)
            if not db.get_customer(customer_id):
                try:
                    if task_id:
                        db.update_translation_task(task_id, done=done, status="cancelled")
                except Exception:
                    pass
                return
            batch = en_msgs[i:i+BATCH_SIZE]
            texts = [m["content"] for m in batch]
            
            # 重试3次
            translations = None
            for attempt in range(3):
                translations = _call_translate_batch(texts, timeout=60)
                if translations is not None:
                    break
                time.sleep(2)
            
            if translations is None:
                # 批量失败,逐条翻译
                for j, m in enumerate(batch):
                    try:
                        single = _call_translate_batch([m["content"]], timeout=30)
                        if single and single[0] and single[0] != m["content"]:
                            db.update_message_translation(m["id"], single[0])
                    except Exception:
                        pass
                    done += 1
                    if done % 5 == 0 or done == total:
                        db.update_translation_task(task_id, done=done)
            else:
                # 批量成功
                for j, m in enumerate(batch):
                    try:
                        if j < len(translations) and translations[j] and translations[j] != m["content"]:
                            db.update_message_translation(m["id"], translations[j])
                    except Exception:
                        pass
                    done += 1
                
                # 每批更新一次进度(实时)
                db.update_translation_task(task_id, done=done)
            
            # 控制速度,避免占用太多CPU
            time.sleep(0.1)

        db.update_translation_task(task_id, done=total, status="done")
    except Exception as e:
        print(f"[bg_translate] 后台翻译异常: {e}")
        try:
            if task_id:
                db.update_translation_task(task_id, done=done, status="failed")
        except Exception:
            pass
