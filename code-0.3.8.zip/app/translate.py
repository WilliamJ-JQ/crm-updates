# -*- coding: utf-8 -*-
"""翻译模块:调用本地轻量翻译服务(opus-mt-en-zh, ctranslate2)"""
import json
import os
import urllib.request

# 翻译端口可通过环境变量 TRANSLATE_PORT 配置(开发者版 8769,避免和正式版冲突)。
# 必须“用到时才读”:app.server 会先导入本模块,而 main() 稍后才设置 TRANSLATE_PORT。
def _port():
    return os.environ.get("TRANSLATE_PORT", "8766")


def translate_url():
    return f"http://127.0.0.1:{_port()}/translate"


def _health_url():
    return f"http://127.0.0.1:{_port()}/health"


_translate_available = None


def _check_service():
    """检查翻译服务是否可用。"""
    global _translate_available
    if _translate_available is not None:
        return _translate_available
    try:
        req = urllib.request.Request(_health_url(), method="GET")
        with urllib.request.urlopen(req, timeout=2) as resp:
            _translate_available = resp.status == 200
    except Exception:
        _translate_available = False
    return _translate_available


def translate_text(text, target="zh"):
    """翻译文本。优先本地翻译服务,失败则返回原文。"""
    if not text or not text.strip():
        return text
    # 中文不需要翻译
    if any('\u4e00' <= c <= '\u9fff' for c in text):
        return text
    if not _check_service():
        return text  # 翻译服务不可用,返回原文
    try:
        data = json.dumps({"text": text}).encode("utf-8")
        req = urllib.request.Request(
            translate_url(),
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST"
        )
        with urllib.request.urlopen(req, timeout=15) as resp:
            result = json.loads(resp.read().decode("utf-8"))
            return result.get("translation", text)
    except Exception:
        return text  # 翻译失败,返回原文
