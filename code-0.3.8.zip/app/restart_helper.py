# -*- coding: utf-8 -*-
"""更新重启助手(由 `app/updater.py` 拉起)。

顺序刻意如此,每一步都对应一个实际踩过的坑:
  1. 等 2 秒 —— 让「应用更新」的 HTTP 响应先回到界面;
  2. 优雅停桥接(`keepalive --stop`)—— 释放 `bridge/node_modules` 里的原生文件锁,
     并避免"旧桥接还在连 + 新桥接又连"的同号双连(440 conflict);
  3. 结束本软件的**所有**进程:旧窗口(`客户工作台.exe` / `CRMWorkstation.exe`)、
     旧服务(`pythonw/python`)、旧桥接(`node`)、`llama-server`、`python-translate`;
  4. 等主端口真正释放(最多 20 秒);
  5. 重新打开窗口壳(`客户工作台.exe` / `CRMWorkstation.exe`)—— 窗口壳会自己拉起服务,
     所以不会再出现"旧窗口残留、要点两次启动"的怪现象。

安全边界:python/node 只杀"命令行里带本软件目录"的进程(按 PID 排除自己),
不会误杀同机其它 Python / Node 程序;窗口壳按专属进程名杀。
"""
import os
import socket
import subprocess
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PORT = int(os.environ.get("CRM_PORT") or 8765)
SIDE = int(os.environ.get("WA_SIDE_PORT") or (PORT + 2))
NO_WIN = 0x08000000 if os.name == "nt" else 0


def _run(args, timeout=25):
    try:
        return subprocess.run(args, timeout=timeout,
                              stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                              creationflags=NO_WIN)
    except Exception:
        return None


def stop_bridge():
    """先优雅停桥接:不 taskkill、不闪窗,也不会误杀别的 node。"""
    kp = os.path.join(ROOT, "bridge", "keepalive.py")
    if not os.path.exists(kp):
        return
    env = dict(os.environ)
    env["WA_SIDE_PORT"] = str(SIDE)
    try:
        subprocess.run([sys.executable, kp, "--stop"], cwd=os.path.dirname(kp), env=env,
                       timeout=45, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                       creationflags=NO_WIN)
    except Exception:
        pass


def kill_app():
    """结束本软件的全部进程(含另一份目录里的同款窗口,避免两个窗口/两处登录)。"""
    # 窗口壳:进程名是本软件专属,按名字杀不会误伤
    for exe in ("客户工作台.exe", "CRMWorkstation.exe"):
        _run(["taskkill", "/f", "/im", exe], timeout=10)
    if os.name != "nt":
        return
    # 服务/桥接/模型/翻译:只杀命令行里带本软件目录的(排除自己)
    names = ["python.exe", "pythonw.exe", "node.exe",
             "llama-server.exe", "python-translate.exe"]
    ps = (
        "$d='%s'.ToLower().Replace('\\','/'); "
        "$n=@(%s); "
        "Get-CimInstance Win32_Process | Where-Object { $_.ProcessId -ne %d -and "
        "$_.Name.ToLower() -in $n -and $_.CommandLine -and "
        "$_.CommandLine.ToLower().Replace('\\','/').Contains($d) } | "
        "ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }"
    ) % (ROOT, ",".join("'%s'" % n for n in names), os.getpid())
    _run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps], timeout=30)


def port_busy(port):
    try:
        s = socket.socket()
        s.settimeout(0.4)
        s.connect(("127.0.0.1", port))
        s.close()
        return True
    except Exception:
        return False


def launch():
    """完整拉起(服务 + 窗口)。

    只起窗口壳就够了:`CRMWindow.EnsureServer()` 会自己用 `pythonw main.py --no-browser`
    拉起服务(并按 `port.txt`/正式版端口注入 `CRM_PORT`)。
    反过来"只起服务不起窗口"就会留下旧窗口 → 用户看到两个窗口、要手动关。
    """
    for exe in ("客户工作台.exe", "CRMWorkstation.exe"):
        p = os.path.join(ROOT, exe)
        if os.path.exists(p):
            subprocess.Popen([p], cwd=ROOT,
                             creationflags=(0x00000008 if os.name == "nt" else 0))
            return
    # 极老的包没有窗口壳:退回启动脚本(它负责起服务窗口/浏览器)
    bat = os.path.join(ROOT, "启动客户工作台.bat")
    if os.name == "nt" and os.path.exists(bat):
        subprocess.Popen(["cmd", "/c", bat], cwd=ROOT, creationflags=NO_WIN)
        return
    # 最后兜底:直接起服务(用户自己打开浏览器)
    py = os.path.join(ROOT, "python", "pythonw.exe")
    if not os.path.exists(py):
        py = sys.executable
    subprocess.Popen([py, os.path.join(ROOT, "main.py"), "--no-browser", "--port", str(PORT)],
                     cwd=ROOT, creationflags=(0x00000008 if os.name == "nt" else 0))


def main():
    time.sleep(2)
    stop_bridge()
    kill_app()
    for _ in range(20):
        if not port_busy(PORT):
            break
        time.sleep(1)
    launch()
    return 0


if __name__ == "__main__":
    sys.exit(main())
