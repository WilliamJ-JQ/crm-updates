# -*- coding: utf-8 -*-
"""待跟进自动关闭(AI上下文判定)。

工作流(用户 2026-10-07 重定):
  第二层:回复判定层
    - 对每个approved状态的提醒,直接调用ai_find_best_reply
    - AI在前后5条上下文中找到最符合的回复
    - AI判符合 → 直接进已处理(AI判 + 依据)
    - AI找到但不确定 → 标记为已回复待人工确认
    - AI认为没有符合回复 → 保持待跟进
    - AI调用失败 → 交人工判定,不降级

铁律:自动完成的动作永远要能追到"我方哪条原话",追不到就不许自动关闭。
"""
import os
import re
import threading
import time
import traceback
from datetime import datetime, timedelta

from . import ai as ai_mod
from . import db

# 这些属于"复杂回复":涉及正式文件/合同/方案,AI 不自动判,必须人工看
# 注意:简单价格数字(如"12-15 USD/㎡")不算复杂回复,AI可以直接判符合
# 只有正式报价单/PI/合同/完整方案才算复杂回复
_COMPLEX_RE = re.compile(
    r"报价单|正式报价|合同|定金|付款条款|交期承诺|货期承诺|完整方案|设计方案|"
    r"proforma|invoice|\bPI\b|contract|agreement|"
    r"catalog|brochure|产品目录|产品册",
    re.I)

# ==================== 判定层参数(都可在设置里调,不用改代码) ====================
# followcheck_v2=1:新触发(代码筛候选 + 60 秒防抖 + 10 条/2 小时兜底)
# followcheck_v2=0:旧行为(每条我方消息/每 12 秒把所有待跟进逐张送 AI),留作对比
_DEFAULTS = {
    "followcheck_v2": "1",
    "reply_debounce_sec": "60",      # 连发多条时,等这么久再合并判一次
    "reply_fallback_msgs": "10",    # 没有明显候选时,累计这么多条再打包分析
    "reply_fallback_hours": "2",    # 或距上次判定超过这么久,兜底分析一次
    "evidence_auto_close": "1",     # 文件名即报价单/方案/样品 → 直接闭环
}


def _cfg(key):
    return (db.get_setting(key, _DEFAULTS.get(key, "")) or _DEFAULTS.get(key, "")).strip()


def _cfg_int(key, default):
    try:
        return int(float(_cfg(key) or default))
    except (TypeError, ValueError):
        return int(default)


def v2_enabled():
    return _cfg("followcheck_v2") == "1"


# 【媒体】桥接把附件写成 '[文档] 文件名' / '[图片] 说明' / '[语音]' 等
_DOC_PREFIX_RE = re.compile(r"^\s*\[(?:文档|文件|document)\]\s*", re.I)
_MEDIA_ONLY_RE = re.compile(r"^\s*\[(?:图片|视频|语音|贴纸|动图|位置|联系人)\]", re.I)
# 文件名命中这些 → 是"报价类证据"(可以闭环询价/报价类待跟进)
_DOC_QUOTE_RE = re.compile(
    r"报价|报价单|价格表|价目|单价|quotation|quote|price|pricing|"
    r"proforma|invoice|\bpi\b|offer", re.I)
_DOC_DESIGN_RE = re.compile(
    r"design|方案|图纸|效果图|cad|drawing|layout|render|mood|搭配|配色", re.I)
_DOC_SAMPLE_RE = re.compile(r"sample|样品|寄样|色卡|swatch", re.I)
# 只是资料,不能当"已报价"证据(避免发个目录就把询价卡关掉)
_DOC_WEAK_RE = re.compile(r"catalog|brochure|目录|产品册|company profile", re.I)

# 每种文件证据,允许关闭哪些类型的待跟进(只关最早一张)
_KIND_BY_DOC = {
    "quote": {"客户询价", "客户提问", "客户催促", "我方承诺报价", "我方承诺回复"},
    "design": {"客户提问", "客户催促", "我方承诺出方案", "我方承诺回复"},
    "sample": {"客户提问", "客户催促", "客户询价", "我方承诺回复"},
}
_DOC_LABEL = {"quote": "报价单", "design": "方案/图纸", "sample": "样品资料"}

# 代码先判断"像不像回复"(0 成本):命中业务词或够长,才值得叫 AI
_REPLY_HINT_RE = re.compile(
    r"报价|价格|单价|quote|quotation|price|pricing|offer|"
    r"交期|货期|lead ?time|delivery|发货|出货|"
    r"样品|寄样|sample|swatch|色卡|"
    r"方案|设计|图纸|drawing|design|cad|render|3d|"
    r"付款|定金|deposit|payment|合同|pi|proforma|invoice|"
    r"会议|视频|meeting|call|zoom|"
    r"已发|发你|发您|发过去|请查收|查收|attached|sent|here is|here's", re.I)

# 防抖:同一客户 60 秒内的连发消息,只合并判一次
_deb_lock = threading.Lock()
_deb_pending = {}
_deb_thread = None

# 兜底判定的节流(避免每 12 秒重复打包分析同一张卡):rid -> (判过的消息数, 时间)
_force_state = {}


def _debounce_ready():
    """取出等待已满的客户(在锁外调用,避免持锁分析)。"""
    due = []
    now = time.time()
    wait = _cfg_int("reply_debounce_sec", 60)
    with _deb_lock:
        for cid, since in list(_deb_pending.items()):
            if now - since >= wait:
                due.append(cid)
                _deb_pending.pop(cid, None)
    return due


def _debounce_loop():
    while True:
        time.sleep(5)
        for cid in _debounce_ready():
            try:
                scan_customer(cid)
            except Exception:
                pass


def _schedule(customer_id):
    """登记"这个客户有新的我方消息",等 60 秒防抖后再判。"""
    global _deb_thread
    with _deb_lock:
        _deb_pending[customer_id] = time.time()
        if _deb_thread is None or not _deb_thread.is_alive():
            t = threading.Thread(target=_debounce_loop,
                                 name="followcheck-debounce", daemon=True)
            t.start()
            _deb_thread = t


def _doc_kind(content):
    """'[文档] xxx报价单.pdf' → 'quote' / 'design' / 'sample';不是证据返回 ''。"""
    c = (content or "").strip()
    if not _DOC_PREFIX_RE.match(c):
        return ""
    fn = _DOC_PREFIX_RE.sub("", c).strip()
    if not fn:
        return ""
    if _DOC_WEAK_RE.search(fn) and not _DOC_QUOTE_RE.search(fn):
        return ""                      # 目录/公司简介不算报价证据
    if _DOC_QUOTE_RE.search(fn):
        return "quote"
    if _DOC_SAMPLE_RE.search(fn):
        return "sample"
    if _DOC_DESIGN_RE.search(fn):
        return "design"
    return ""


def _is_doc(content):
    return bool(_DOC_PREFIX_RE.match((content or "").strip()))


def try_close_by_document(customer_id, msg_id, content, ts=""):
    """强信号:我方发出的文档文件名就是报价单/方案/样品 → 直接闭环"最早一张"待跟进。

    为什么必须绑定客户+原话:一份同名报价单可能发给不同客户,只凭文件名会误关。
    为什么只关最早一张:同一客户可能有多张真需求,一份文件不该一次关掉多张。
    返回关闭的条数(0 或 1)。
    """
    if _cfg("evidence_auto_close") != "1":
        return 0
    kind = _doc_kind(content)
    if not kind:
        return 0
    try:
        mid = int(msg_id)
        cid = int(customer_id)
    except (TypeError, ValueError):
        return 0
    # 证据必须真实存在于这个客户的聊天里,且没被别的卡用过。
    # 否则一条伪造/错传的 msg_id 就能把卡片关掉,还会把不存在的消息记成依据。
    msg = db.get_message(mid)
    if not msg:
        return 0
    if int(msg.get("customer_id") or 0) != cid:
        return 0
    if db.msg_is_evidence(mid):
        return 0
    rows = db.list_reminders(status=db.R_APPROVED, customer_id=customer_id, limit=200)
    allow = _KIND_BY_DOC.get(kind, set())
    cands = []
    for r in rows:
        if r.get("skip_auto"):
            continue
        if (r.get("kind") or "") not in allow:
            continue
        try:
            src = int(r.get("src_msg_id") or 0)
        except (TypeError, ValueError):
            src = 0
        if not src or src >= mid:
            continue                    # 文件必须晚于这张卡的原话
        cands.append(r)
    if not cands:
        return 0
    cands.sort(key=lambda r: (str(r.get("src_ts") or ""), int(r.get("id") or 0)))
    rem = cands[0]
    who = who_label(msg.get("sender_name"), msg.get("sender_role"))
    db.set_reminder_reply(
        rem["id"], "answered_doc", mid, (content or "")[:300],
        "文件闭环:我方发送「%s」→ 自动完成该待跟进(该客户最早一张%s类卡)"
        % ((content or "")[:80], _DOC_LABEL.get(kind, "资料")),
        reply_by=who, reply_role=(msg.get("sender_role") or ""))
    con = db.connect()
    try:
        con.execute("UPDATE reminders SET decided_by='evidence', status=?, decided_at=?"
                    " WHERE id=? AND status=?",
                    (db.R_DONE, db.now_iso(), rem["id"], db.R_APPROVED))
        con.commit()
    finally:
        con.close()
    try:
        db.log_reminder(rem["id"], rem["customer_id"], "文件证据闭环",
                        db.R_APPROVED, db.R_DONE, (content or "")[:200])
    except Exception:
        pass
    return 1


# 我方人员的显示名:PM=我 / SM=销售经理 / team=团队
_WHO = {"pm": "我(PM)", "sm": "销售经理", "team": "团队",
        "designer": "客户设计师", "other": "客户方成员", "customer": "客户"}


def who_label(name, role):
    """把「谁回的」变成人能看懂的一行字,例:张三(SM) / 我(PM)。"""
    base = _WHO.get((role or "").strip(), "")
    nm = (name or "").strip()
    if nm and nm != base:
        return "%s(%s)" % (nm, base) if base else nm
    return base or nm


def _candidate_msgs(r):
    """代码筛"候选回复"(0 次 AI):我方发的、像回复的、晚于原话的消息。"""
    src_mid = r.get("src_msg_id")
    if not src_mid:
        return []
    rows = db.msgs_after(r["customer_id"], src_mid,
                         limit=_cfg_int("reply_fallback_msgs", 10) * 2,
                         direction="out")
    out = []
    for m in rows:
        c = (m.get("content") or "").strip()
        if not c:
            continue
        if _MEDIA_ONLY_RE.match(c):
            continue                     # 图片/视频/语音:本地模型没视觉,交人工
        if _is_doc(c):
            if not _doc_kind(c):
                continue                 # 目录/公司简介等不算证据
            if db.msg_is_evidence(m["id"]):
                continue                 # 一张文件只关一张卡(已被别的卡用作证据)
            out.append(m)
            continue
        if _REPLY_HINT_RE.search(c) or len(c) >= 15:
            out.append(m)
    return out


def _apply_ai_result(r, best_id, adequate, reason, packed=False):
    """落库 AI 的判定结果(自动完成 / 待人工 / 保持待跟进)。"""
    if reason in ("ai-error", "ai-invalid", "no-reminder", "no-source"):
        db.set_reminder_reply(
            r["id"], "needs_human", None, None,
            "AI调用失败(%s),需人工判定回复是否符合" % reason)
        return 1, 0
    if not best_id:
        db.set_reminder_reply(
            r["id"], "not_answered", None, None,
            "AI判:%s里没有真正解决需求的回复(%s) → 保持待跟进"
            % ("候选消息" if packed else "前后5条", reason))
        return 1, 0
    best_msg = db.get_message(best_id)
    if not best_msg:
        return 0, 0
    who = who_label(best_msg.get("sender_name"), best_msg.get("sender_role"))
    where = "筛出的候选" if packed else "前后5条"
    if adequate:
        db.set_reminder_reply(
            r["id"], "answered_ai", best_id, best_msg["content"],
            "AI判:%s中找到最符合回复(%s · %s),%s → 自动完成"
            % (where, who, best_msg["ts"][:16] if best_msg.get("ts") else "", reason),
            reply_by=who, reply_role=(best_msg.get("sender_role") or ""))
        con2 = db.connect()
        try:
            con2.execute("UPDATE reminders SET decided_by='ai', status=?, decided_at=?"
                         " WHERE id=? AND status='approved'",
                         (db.R_DONE, db.now_iso(), r["id"]))
            con2.commit()
        finally:
            con2.close()
    else:
        db.set_reminder_reply(
            r["id"], "needs_human", best_id, best_msg["content"],
            "AI判:找到回复但不确定是否解决需求(%s · %s),%s → 待人工确认"
            % (who, best_msg["ts"][:16] if best_msg.get("ts") else "", reason),
            reply_by=who, reply_role=(best_msg.get("sender_role") or ""))
    return 1, 1


def _fallback_due(r):
    """没有候选时值不值得再打包分析一次:累计够 N 条,或距上次判定超过 N 小时。"""
    try:
        n_after = db.count_msgs_after(r["customer_id"], r.get("src_msg_id"))
    except Exception:
        return False
    if n_after <= 0:
        return False
    last_n = _force_state.get(r["id"], (0, 0.0))[0]
    if n_after >= _cfg_int("reply_fallback_msgs", 10) and n_after > last_n:
        return True
    last = (r.get("reply_checked_at") or r.get("src_ts") or "").strip()
    if not last:
        return False
    try:
        t = datetime.fromisoformat(last.replace("Z", "").split("+")[0].split(".")[0])
    except ValueError:
        return False
    return datetime.now() - t >= timedelta(hours=_cfg_int("reply_fallback_hours", 2))


def _scan_one(r, force=False):
    """判一张卡:有候选才叫 AI;没候选就不烧算力,等 10 条/2 小时兜底。"""
    if r.get("skip_auto"):
        return 0, 0                      # 人工撤回过的卡,永不自动关
    if not r.get("src_msg_id"):
        return 0, 0
    if r.get("reply_state") in ("answered_ai", "answered_doc", "needs_human"):
        return 0, 0                      # 已有定论,不要来回震荡
    cands = _candidate_msgs(r)
    packed = False
    if not cands:
        if not force:
            return 0, 0                  # 0 次 AI:等真正像回复的消息
        cands = db.msgs_after(r["customer_id"], r["src_msg_id"],
                              limit=_cfg_int("reply_fallback_msgs", 10))
        packed = True
    _force_state[r["id"]] = (db.count_msgs_after(r["customer_id"], r["src_msg_id"]),
                             time.time())
    if not cands:
        return 0, 0
    try:
        best_id, adequate, reason = ai_find_best_reply(
            r["id"], candidates=[m["id"] for m in cands], packed=packed)
    except Exception as e:
        try:
            with open(os.path.join(db.PROJECT_DIR, "data", "app.log"),
                      "a", encoding="utf-8") as f:
                f.write("[ai_find_best_reply ERROR] reminder=%s: %s\n%s\n" % (
                    r.get("id"), str(e), traceback.format_exc()))
        except Exception:
            pass
        db.set_reminder_reply(
            r["id"], "needs_human", None, None,
            "AI调用异常,需人工判定回复是否符合")
        return 1, 0
    return _apply_ai_result(r, best_id, adequate, reason, packed)


def scan_customer(customer_id, limit=100, force=False):
    """只判这个客户:防抖到点后调用。"""
    rows = db.list_reminders(status=db.R_APPROVED, customer_id=customer_id, limit=limit)
    checked = found = 0
    for r in rows:
        try:
            c, f = _scan_one(r, force=force)
            checked += c
            found += f
        except Exception:
            continue
    return checked, found


def _code_scan_legacy(customer_id=None, limit=100):
    """旧行为(每条我方消息/每 12 秒把所有待跟进逐张送 AI)。设 followcheck_v2=0 时启用。"""
    rows = db.list_reminders(status=db.R_APPROVED, limit=limit)
    checked = found = 0
    for r in rows:
        if customer_id and r["customer_id"] != customer_id:
            continue
        if r.get("skip_auto"):
            continue
        if not (r.get("src_ts") or "").strip() or not r.get("src_msg_id"):
            continue
        checked += 1
        if r.get("reply_state") in ("answered_ai", "needs_human", "not_answered"):
            continue
        try:
            best_id, adequate, reason = ai_find_best_reply(r["id"])
        except Exception:
            db.set_reminder_reply(r["id"], "needs_human", None, None,
                                  "AI调用异常,需人工判定回复是否符合")
            continue
        _, f = _apply_ai_result(r, best_id, adequate, reason, packed=False)
        found += f
    return checked, found


def code_scan(customer_id=None, limit=100):
    """第二层入口(主服务每 12 秒调一次;也用于"建卡后立刻看一眼")。

    v2:只对"有候选回复"或"到兜底阈值"的卡调 AI;其余 0 次调用。
    v1:旧行为,全量逐张调 AI。
    """
    if not v2_enabled():
        return _code_scan_legacy(customer_id, limit)
    rows = db.list_reminders(status=db.R_APPROVED, limit=limit)
    checked = found = 0
    for r in rows:
        if customer_id and r["customer_id"] != customer_id:
            continue
        try:
            c, f = _scan_one(r, force=_fallback_due(r))
            checked += c
            found += f
        except Exception:
            continue
    return checked, found


def on_out_message(customer_id, msg_id=None, content="", ts=""):
    """我方刚发出一条消息(v2):
    ① 文件名就是报价单/方案/样品 → 立刻闭环该客户最早一张卡(0 次 AI)
    ② 其余 → 登记防抖,等 60 秒没有新消息了再合并判一次
    """
    try:
        if not v2_enabled():
            return _code_scan_legacy(customer_id=customer_id)
        if try_close_by_document(customer_id, msg_id, content or "", ts or ""):
            return (1, 1)
        _schedule(customer_id)
        return (0, 0)
    except Exception:
        return (0, 0)


def stats():
    con = db.connect()
    try:
        def n(state):
            return con.execute(
                "SELECT COUNT(*) n FROM reminders WHERE status=? AND reply_state=?",
                (db.R_APPROVED, state)).fetchone()["n"]
        return {"no_reply": n("no_reply"), "replied": n("replied"),
                "answered_ai": n("answered_ai"), "answered_doc": n("answered_doc"),
                "needs_human": n("needs_human"),
                "not_answered": n("not_answered")}
    finally:
        con.close()


# AI判断PM手动标记为"已回复"的消息是否真正解决了客户需求
# 如果没解决(如只是解释工厂放假),生成新的"我方承诺"待跟进
_REPLY_ADEQUATE_SYS = (
    "你是外贸业务助理。判断【我方回复】是否真正解决了【客户需求】。\n"
    "客户需求可能是:要报价、要方案、要交期、要样品等。\n"
    "我方回复如果只是解释原因(如工厂放假、需要时间、正在准备)而没有给出实际结果,\n"
    "就不算真正解决,应该生成新的承诺待跟进。\n"
    "如果回复是'[图片]' '[视频]' '[语音]' '[贴纸]':模型看不到内容 → 一律 adequate=false,交人工。\n"
    "【文档识别】如果我方回复是'[文档] 文件名'格式:\n"
    "- 文件名包含 quote/pi/报价/quotation/proforma/invoice/price 等关键词 → 这是报价单,算真正解决了客户的报价需求\n"
    "- 文件名包含 design/drawing/cad/方案/图纸 等关键词 → 这是方案/图纸,算真正解决了客户的方案需求\n"
    "- 文件名包含 sample/样品 等关键词 → 这是样品相关,算真正解决了客户的样品需求\n"
    "输出JSON:{\"adequate\":true/false,\"reason\":\"一句话说明\",\"new_promise\":\"如果没解决,应该承诺什么(如'假期后提供报价'),留空表示不需要新承诺\"}"
)

# AI在前后5条上下文中找到最符合的回复
_FIND_BEST_REPLY_SYS = (
    "你是外贸业务助理。给定【客户需求消息】和前后各5条聊天记录,\n"
    "请在这些消息中找到最能解决客户需求的【我方回复】。\n"
    "客户需求可能是:要报价、要方案、要交期、要样品、要视频通话、问价格等。\n"
    "判断标准:\n"
    "1. 回复必须是我方发出的(PM/销售经理/团队)\n"
    "2. 回复必须在客户需求之后\n"
    "3. 回复必须真正回应了客户需求:\n"
    "   - 客户问价格 → 回复包含价格数字(如12-15 USD、$100、264USD)就算符合\n"
    "   - 客户问交期 → 回复包含时间(如3天、下周、10月15号)就算符合\n"
    "   - 客户问能不能视频 → 回复yes/ok/可以/同意就算符合\n"
    "   - 客户要样品 → 回复说已寄出/给快递单号就算符合\n"
    "   - 客户要方案 → 回复给了文字方案/图纸说明/文件名像方案文件,就算符合\n"
    "4. 【文档识别】如果回复是'[文档] 文件名'格式:\n"
    "   - 文件名包含 quote/pi/报价/quotation/proforma/invoice/price → 报价单,符合客户询价需求\n"
    "   - 文件名包含 design/drawing/cad/方案/图纸 → 方案/图纸,符合客户方案需求\n"
    "   - 文件名包含 sample/样品 → 样品相关,符合客户样品需求\n"
    "   - 文档可以作为正式回复依据,比单纯文字回复更有说服力\n"
    "   - 文件名只有 catalog/brochure/目录/产品册 → 只是资料,不算已报价\n"
    "4.1 【看不了附件】'[图片]' '[视频]' '[语音]' '[贴纸]' 没有可读内容,不能当作回复依据\n"
    "    (真实文件已由文件名单独判定过;这类不确定的一律 adequate=false,交人工)\n"
    "5. 只是寒暄(hello/hi)、解释原因(工厂放假/需要时间)、说'我开始工作了'、只说产品名字不算真正回复\n"
    "6. 如果有多条回复,选最直接、最完整解决需求的那一条\n"
    "7. 只要回复包含了客户要的关键信息(价格/时间/确认/报价单文档),就算符合,不需要非常正式或完整\n"
    "输出JSON:{\"reply_id\":消息ID(数字,没有则为null),\"adequate\":true/false,\"reason\":\"一句话说明为什么选这条或为什么没有符合的回复\"}"
)


def ai_find_best_reply(reminder_id, candidates=None, packed=False):
    """找到最符合的回复。

    - candidates=None:旧行为,取前 5 条 + 需求原话 + 后 5 条
    - candidates=[消息id...]:只给"代码筛出的候选"(节省算力,判断更聚焦)
    - packed=True:兜底模式,给最近 N 条(即使是客户消息/看似无关的话)

    返回 (reply_msg_id, adequate, reason)
    """
    rem = db.get_reminder(reminder_id)
    if not rem:
        return None, False, "no-reminder"
    cid = rem.get("customer_id")
    src_mid = rem.get("src_msg_id")
    if not cid or not src_mid:
        return None, False, "no-source"
    con = db.connect()
    try:
        # 前面3条(候选模式)或前5条(旧模式)
        n_before = 3 if candidates else 5
        before = con.execute(
            "SELECT id, ts, content, direction, sender_role, sender_name FROM messages"
            " WHERE customer_id=? AND id < ? ORDER BY id DESC LIMIT ?",
            (cid, src_mid, n_before)).fetchall()
        before = list(reversed([dict(x) for x in before]))
        # 客户需求消息本身
        src_msg = con.execute(
            "SELECT id, ts, content, direction, sender_role, sender_name FROM messages WHERE id=?",
            (src_mid,)).fetchone()
        if candidates:
            after = []
            ids = [int(i) for i in candidates][:12]
            if ids:
                marks = ",".join("?" * len(ids))
                rows = con.execute(
                    "SELECT id, ts, content, direction, sender_role, sender_name"
                    " FROM messages WHERE id IN (%s) ORDER BY id ASC" % marks,
                    tuple(ids)).fetchall()
                after = [dict(x) for x in rows]
        else:
            after = con.execute(
                "SELECT id, ts, content, direction, sender_role, sender_name FROM messages"
                " WHERE customer_id=? AND id > ? ORDER BY id ASC LIMIT 5",
                (cid, src_mid)).fetchall()
            after = [dict(x) for x in after]
    finally:
        con.close()
    ctx_lines = []
    for m in before:
        role = "客户" if m["direction"] == "in" else "我方"
        ctx_lines.append("[%s][%s][id=%s] %s: %s" % (
            m["ts"][:16] if m["ts"] else "", role, m["id"],
            m.get("sender_name") or "", (m["content"] or "")[:200]))
    if src_msg:
        src_msg = dict(src_msg)
        ctx_lines.append("[%s][客户需求][id=%s] %s: %s" % (
            src_msg["ts"][:16] if src_msg["ts"] else "", src_msg["id"],
            src_msg.get("sender_name") or "", (src_msg["content"] or "")[:200]))
    for m in after:
        role = "客户" if m["direction"] == "in" else "我方"
        ctx_lines.append("[%s][%s][id=%s] %s: %s" % (
            m["ts"][:16] if m["ts"] else "", role, m["id"],
            m.get("sender_name") or "", (m["content"] or "")[:200]))
    context = "\n".join(ctx_lines)
    if candidates:
        label = "候选回复(代码已筛过,只在这个范围里选)" if not packed else "最近聊天记录"
    else:
        label = "前后各5条"
    ask = ("客户需求:%s\n\n聊天记录(%s):\n%s\n\n请找到最符合的我方回复,输出JSON。"
           % ((rem.get("note") or "")[:100], label, context))
    try:
        from . import ai
        out = ai._call_api([
            {"role": "system", "content": _FIND_BEST_REPLY_SYS},
            {"role": "user", "content": ask},
        ])
    except Exception:
        return None, False, "ai-error"
    if isinstance(out, list):
        out = out[0] if out and isinstance(out[0], dict) else {}
    if not isinstance(out, dict):
        return None, False, "ai-invalid"
    reply_id = out.get("reply_id")
    adequate = bool(out.get("adequate"))
    reason = str(out.get("reason") or "")[:200]
    try:
        reply_id = int(reply_id) if reply_id else None
    except (TypeError, ValueError):
        reply_id = None
    return reply_id, adequate, reason


def ai_check_reply_adequate(rid, reply_msg_id):
    """PM手动标记为"已回复"后,AI判断回复是否真正解决了客户需求。

    - 如果解决了 → 标记为"已处理"
    - 如果没解决 → 生成新的"我方承诺"待跟进
    - AI拿不准 → 保持"已回复",交PM确认
    """
    rem = db.get_reminder(rid)
    if not rem:
        return "no-reminder"
    reply_msg = db.get_message(reply_msg_id)
    if not reply_msg:
        return "no-reply-msg"

    customer_need = (rem.get("note") or "")[:100]
    customer_original = (rem.get("quote") or "")[:200]
    reply_content = (reply_msg.get("content") or "")[:300]

    ask = ("客户需求:%s\n客户原话:%s\n我方回复:%s\n\n"
           "判断我方回复是否真正解决了客户需求。"
           "如果只是解释原因(工厂放假/需要时间/正在准备)而没有给出实际结果,就算没解决。"
           % (customer_need, customer_original, reply_content))

    try:
        out = ai_mod._call_api([
            {"role": "system", "content": _REPLY_ADEQUATE_SYS},
            {"role": "user", "content": ask},
        ])
    except Exception:
        return "ai-error"

    if isinstance(out, list):
        out = out[0] if out and isinstance(out[0], dict) else {}
    if not isinstance(out, dict):
        return "ai-invalid"

    adequate = bool(out.get("adequate"))
    reason = str(out.get("reason") or "").strip()[:120]
    new_promise = str(out.get("new_promise") or "").strip()[:40]

    if adequate:
        # AI判断已解决 → 标记为"已处理"
        con = db.connect()
        try:
            con.execute("UPDATE reminders SET status=?, decided_by='ai', decided_at=?"
                        " WHERE id=?", (db.R_DONE, db.now_iso(), rid))
            con.commit()
        finally:
            con.close()
        db.set_reminder_reply(rid, "answered_ai", reply_msg_id, reply_content,
                              "AI判:回复已解决客户需求" + (("(" + reason + ")") if reason else ""))
        db.log_reminder(rid, rem.get("customer_id"), "AI判已解决",
                        db.R_APPROVED, db.R_DONE, reason or "")
        return "adequate"
    elif new_promise:
        # AI判断没解决,且建议了新承诺 → 生成新的"我方承诺"待跟进
        from datetime import date, timedelta
        new_rid = db.add_reminder(
            rem.get("customer_id"),
            "我方承诺:" + new_promise,
            "我方承诺:" + new_promise,
            days=None, status=db.R_APPROVED,
            notify_date=(date.today() + timedelta(days=3)).isoformat(),
            quote=reply_content[:300], src_ts=reply_msg.get("ts") or "",
            src_direction="out", auto="ai", src_msg_id=reply_msg_id,
            decided_by="ai",
            reason="AI判:原回复未解决客户需求(%s),生成新承诺" % reason)
        # 原提醒标记为"已回复"(保持待跟进,但已找到回复)
        db.set_reminder_reply(rid, "replied", reply_msg_id, reply_content,
                              "PM手动标记已回复,AI判未解决,已生成新承诺:%s" % new_promise)
        return "new_promise"
    else:
        # AI拿不准 → 保持"已回复",交PM确认
        db.set_reminder_reply(rid, "needs_human", reply_msg_id, reply_content,
                              "AI拿不准:回复是否解决客户需求?" + (("(" + reason + ")") if reason else ""))
        return "needs_human"
