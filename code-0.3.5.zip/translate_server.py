# -*- coding: utf-8 -*-
"""本地轻量翻译服务(多语言→中文)
用 transformers + opus-mt 模型，支持英语、西班牙语、法语等。
- 英文: opus-mt-en-zh
- 西班牙语: opus-mt-es-zh
- 法语: opus-mt-fr-zh
支持并发请求和批量翻译。
运行: python translate_server.py --port 8766
"""
import argparse
import json
import os
import re
import shutil
import tempfile
import threading
import time
from http.server import HTTPServer, BaseHTTPRequestHandler

_SRC_MODEL_DIR_EN = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ai-models", "translate-en-zh")
_SRC_MODEL_DIR_ES = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ai-models", "translate-es-zh")
_SRC_MODEL_DIR_FR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ai-models", "translate-fr-zh")
MODEL_DIR_EN = os.path.join(tempfile.gettempdir(), "crm-translate-model-en")
MODEL_DIR_ES = os.path.join(tempfile.gettempdir(), "crm-translate-model-es")
MODEL_DIR_FR = os.path.join(tempfile.gettempdir(), "crm-translate-model-fr")

for _src, _dst in [
    (_SRC_MODEL_DIR_EN, MODEL_DIR_EN),
    (_SRC_MODEL_DIR_ES, MODEL_DIR_ES),
    (_SRC_MODEL_DIR_FR, MODEL_DIR_FR),
]:
    if os.path.exists(_src) and not os.path.exists(os.path.join(_dst, "config.json")):
        try:
            shutil.copytree(_src, _dst, dirs_exist_ok=True)
            print(f"[translate] 模型已复制: {_dst}")
        except Exception as e:
            print(f"[translate] 模型复制失败 {_dst}: {e}")

_models = {}  # lang -> (model, tokenizer)
_model_lock = threading.Lock()  # 模型推理锁,防止并发推理导致崩溃


def detect_language(text):
    """简单检测文本语言:en=英语, es=西班牙语, fr=法语, zh=中文, unknown=其他"""
    if not text or not text.strip():
        return "zh"
    # 中文检测
    if any('\u4e00' <= c <= '\u9fff' for c in text):
        return "zh"
    # 西班牙语特征:ñ, á, é, í, ó, ú, ü, ¿, ¡
    if re.search(r'[ñü¿¡]', text, re.IGNORECASE):
        return "es"
    # 法语特征:ç, œ, æ, è, ê, ë, à, â, ù, û, ô, î, ï, ÿ
    if re.search(r'[çœæèêëàâùûôîïÿ]', text, re.IGNORECASE):
        return "fr"
    # 有重音符号的可能是西语或法语,默认按西班牙语处理
    if re.search(r'[áéíóú]', text, re.IGNORECASE):
        return "es"
    # 英语特征:主要是英文字母
    letters = re.findall(r'[a-zA-Z]', text)
    if len(letters) >= 3:
        return "en"
    return "unknown"


def load_model(lang):
    """加载指定语言的模型。"""
    if lang in _models:
        return _models[lang]
    with _model_lock:
        if lang in _models:
            return _models[lang]
        import torch
        from transformers import AutoTokenizer, AutoModelForSeq2SeqLM
        model_dirs = {
            "en": MODEL_DIR_EN,
            "es": MODEL_DIR_ES,
            "fr": MODEL_DIR_FR,
        }
        model_dir = model_dirs.get(lang)
        if not model_dir or not os.path.exists(os.path.join(model_dir, "config.json")):
            print(f"[translate] 模型不存在: {model_dir}")
            return None
        tokenizer = AutoTokenizer.from_pretrained(model_dir)
        model = AutoModelForSeq2SeqLM.from_pretrained(model_dir)
        model.eval()
        _models[lang] = (model, tokenizer)
        print(f"[translate] 模型已加载: {model_dir}")
        return _models[lang]


def translate_text(text, timeout=30):
    """翻译单条文本，返回中文。超时返回原文。"""
    if not text or not text.strip():
        return ""
    # 中文直接返回
    if any('\u4e00' <= c <= '\u9fff' for c in text):
        return text
    lang = detect_language(text)
    if lang == "zh":
        return text
    if lang == "unknown":
        return text  # 不识别的语言直接返回原文
    loaded = load_model(lang)
    if loaded is None:
        return text  # 模型不存在,返回原文
    model, tokenizer = loaded
    import torch
    try:
        with _model_lock:
            lines = text.split("\n")
            results = []
            for line in lines:
                if not line.strip():
                    results.append("")
                    continue
                inputs = tokenizer(line, return_tensors="pt", truncation=True, max_length=512)
                with torch.no_grad():
                    outputs = model.generate(
                        **inputs,
                        max_length=128,
                        num_beams=4,
                        early_stopping=True
                    )
                result = tokenizer.decode(outputs[0], skip_special_tokens=True)
                results.append(result.strip())
            return "\n".join(results)
    except Exception as e:
        print(f"[translate] 翻译失败({lang}): {e}")
        return text  # 失败返回原文


def translate_batch(texts, timeout=60):
    """批量翻译，返回列表。"""
    results = []
    for text in texts:
        results.append(translate_text(text, timeout))
    return results


class ThreadingHTTPServer(HTTPServer):
    """支持并发的HTTP服务器。"""
    daemon_threads = True
    allow_reuse_address = True

    def process_request(self, request, client_address):
        t = threading.Thread(target=self._handle, args=(request, client_address))
        t.daemon = True
        t.start()

    def _handle(self, request, client_address):
        try:
            self.finish_request(request, client_address)
        except Exception:
            self.handle_error(request, client_address)
        finally:
            self.shutdown_request(request)


class TranslateHandler(BaseHTTPRequestHandler):
    def _send(self, data, code=200):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        if self.path == "/translate":
            try:
                length = int(self.headers.get("Content-Length", 0))
                body = self.rfile.read(length).decode("utf-8")
                data = json.loads(body)
                text = data.get("text", "")
                result = translate_text(text)
                self._send({"translation": result})
            except Exception as e:
                self._send({"error": str(e)}, 500)
        elif self.path == "/translate-batch":
            try:
                length = int(self.headers.get("Content-Length", 0))
                body = self.rfile.read(length).decode("utf-8")
                data = json.loads(body)
                texts = data.get("texts", [])
                results = translate_batch(texts)
                self._send({"translations": results})
            except Exception as e:
                self._send({"error": str(e)}, 500)
        else:
            self._send({"error": "not found"}, 404)

    def do_GET(self):
        if self.path == "/health":
            self._send({"status": "ok"})
        else:
            self._send({"error": "not found"}, 404)

    def log_message(self, format, *args):
        pass


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8766)
    args = parser.parse_args()
    print(f"[translate] 启动翻译服务端口 {args.port}...")
    # 启动时预加载英文模型(最常用)
    load_model("en")
    # 检查西班牙语/法语模型是否存在
    for lang, model_dir, name in [
        ("es", MODEL_DIR_ES, "西班牙语"),
        ("fr", MODEL_DIR_FR, "法语"),
    ]:
        if os.path.exists(os.path.join(model_dir, "config.json")):
            print(f"[translate] {name}模型已就绪: {model_dir}")
        else:
            print(f"[translate] {name}模型未安装({name}暂不可用): {model_dir}")
    print(f"[translate] 就绪: http://127.0.0.1:{args.port}/translate")
    server = ThreadingHTTPServer(("127.0.0.1", args.port), TranslateHandler)
    server.serve_forever()


if __name__ == "__main__":
    main()
