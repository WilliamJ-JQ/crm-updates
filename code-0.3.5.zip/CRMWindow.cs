using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using System.Media;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Reflection;
using Microsoft.Web.WebView2.WinForms;
using Microsoft.Web.WebView2.Core;

namespace CRMWindow
{
    static class Program
    {
        [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
        [DllImport("user32.dll")] public static extern int SetProcessDpiAwarenessContext(int c);
        [DllImport("user32.dll")] public static extern IntPtr FindWindow(string lpClassName, string lpWindowName);
        [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
        [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
        [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr hWnd);

        static string logPath = "";
        static void Log(string msg)
        {
            try
            {
                if (string.IsNullOrEmpty(logPath))
                {
                    string dir = Path.Combine(Application.StartupPath, "data");
                    Directory.CreateDirectory(dir);
                    logPath = Path.Combine(dir, "startup.log");
                }
                File.AppendAllText(logPath, DateTime.Now.ToString("HH:mm:ss.fff") + " " + msg + "\r\n");
            }
            catch { }
        }

        public static int GetPort()
        {
            try
            {
                string pfile = Path.Combine(Application.StartupPath, "port.txt");
                if (File.Exists(pfile))
                {
                    string txt = File.ReadAllText(pfile).Trim();
                    int p;
                    if (int.TryParse(txt, out p) && p > 1000 && p < 65535)
                    {
                        Log("Using custom port from port.txt: " + p);
                        return p;
                    }
                }
            }
            catch { }
            return 8765;
        }

        /// <summary>是否是开发者版(有port.txt文件即为开发者版)</summary>
        public static bool IsDevMode()
        {
            try
            {
                return File.Exists(Path.Combine(Application.StartupPath, "port.txt"));
            }
            catch { return false; }
        }

        /// <summary>获取窗口标题(开发者版加标识)</summary>
        public static string GetWindowTitle()
        {
            return IsDevMode() ? "外贸客户工作台（开发者版）" : "外贸客户工作台";
        }

        [STAThread]
        static void Main()
        {
            try
            {
                Log("=== CRMWorkstation starting ===");
                Log("StartupPath: " + Application.StartupPath);

                int port = GetPort();
                Log("Using port: " + port);

                // 用端口检测代替Mutex，更可靠
                Log("Checking port " + port + "...");
                bool serverUp = IsServerUp(port);
                Log("Port " + port + " up: " + serverUp);

                if (serverUp)
                {
                    Log("Finding existing window...");
                    IntPtr hWnd = FindWindow(null, GetWindowTitle());
                    Log("Existing window handle: " + hWnd);
                    if (hWnd != IntPtr.Zero)
                    {
                        Log("Found existing window, activating and exiting");
                        if (IsIconic(hWnd)) ShowWindow(hWnd, 9);
                        ShowWindow(hWnd, 5);
                        SetForegroundWindow(hWnd);
                        return;
                    }
                    Log("No existing window found, continuing startup");
                }

                Log("Setting DPI awareness...");
                try { SetProcessDpiAwarenessContext(-4); } catch (Exception ex) { Log("DPI error: " + ex.Message); }

                Log("Enabling visual styles...");
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);

                Log("Setting up AssemblyResolve...");
                AppDomain.CurrentDomain.AssemblyResolve += (s, e) => {
                    string name = new AssemblyName(e.Name).Name + ".dll";
                    string p = Path.Combine(Application.StartupPath, "webview2", name);
                    Log("Resolving assembly: " + e.Name + " -> " + p + " exists: " + File.Exists(p));
                    if (File.Exists(p)) return Assembly.LoadFrom(p);
                    return null;
                };

                Log("Ensuring server...");
                EnsureServer();
                Log("Server ensured");

                Log("Creating MainForm...");
                MainForm form = new MainForm();
                Log("MainForm created, handle: " + form.Handle);

                Log("Running application...");
                Application.Run(form);
                Log("Application exited normally");
            }
            catch (Exception ex)
            {
                Log("FATAL ERROR: " + ex.ToString());
                MessageBox.Show("启动失败: " + ex.Message + "\r\n\r\n详情请查看 data\\startup.log", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        static bool IsServerUp(int port)
        {
            try {
                using (var c = new System.Net.Sockets.TcpClient())
                {
                    var ar = c.BeginConnect("127.0.0.1", port, null, null);
                    bool ok = ar.AsyncWaitHandle.WaitOne(800);
                    if (ok && c.Connected) { c.EndConnect(ar); return true; }
                }
            } catch {}
            return false;
        }

        static void EnsureServer()
        {
            int port = GetPort();
            if (IsServerUp(port)) return;
            string py = Path.Combine(Application.StartupPath, "python", "pythonw.exe");
            if (!File.Exists(py)) py = "pythonw.exe";
            try {
                var psi = new ProcessStartInfo();
                psi.FileName = py;
                psi.Arguments = "main.py --no-browser";
                psi.WorkingDirectory = Application.StartupPath;
                psi.UseShellExecute = false;
                psi.CreateNoWindow = true;
                // 通过环境变量传递端口
                if (port != 8765)
                {
                    psi.EnvironmentVariables["CRM_PORT"] = port.ToString();
                    // 翻译端口 = 主端口 + 1 (正式版8765→8766, 开发者版8768→8769)
                    psi.EnvironmentVariables["TRANSLATE_PORT"] = (port + 1).ToString();
                }
                Process.Start(psi);
                // 等服务器起来,最多等15秒
                for (int i = 0; i < 30; i++)
                {
                    System.Threading.Thread.Sleep(500);
                    if (IsServerUp(port)) return;
                }
            } catch (Exception ex) {
                MessageBox.Show("启动服务器失败: " + ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }

    public class MainForm : Form
    {
        private WebView2 webView;
        private Panel titleBar;
        private Label btnMin, btnMax, btnClose;
        private NotifyIcon trayIcon;
        private bool isMax = false;
        private bool allowClose = false;
        private const int BW = 8;
        private const int TITLE_H = 36;

        [DllImport("user32.dll")] public static extern bool ReleaseCapture();
        [DllImport("user32.dll")] public static extern int SendMessage(IntPtr h, int m, int w, int l);
        [DllImport("dwmapi.dll")] public static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int val, int size);
        [DllImport("user32.dll")] public static extern bool FlashWindowEx(ref FLASHWINFO pwfi);
        [DllImport("winmm.dll")] public static extern bool PlaySound(string pszSound, IntPtr hmod, uint fdwSound);

        [StructLayout(LayoutKind.Sequential)]
        public struct FLASHWINFO
        {
            public uint cbSize;
            public IntPtr hwnd;
            public uint dwFlags;
            public uint uCount;
            public uint dwTimeout;
        }

        // 任务栏闪烁
        private void FlashTaskbar(uint count = 5)
        {
            try
            {
                FLASHWINFO fwi = new FLASHWINFO();
                fwi.cbSize = Convert.ToUInt32(Marshal.SizeOf(fwi));
                fwi.hwnd = Handle;
                fwi.dwFlags = 0x00000003 | 0x0000000C; // FLASHW_ALL | FLASHW_TIMERNOFG
                fwi.uCount = count;
                fwi.dwTimeout = 0;
                FlashWindowEx(ref fwi);
            } catch { }
        }

        // 托盘图标闪烁
        private void FlashTray(uint durationMs = 3000)
        {
            try
            {
                var t = new System.Windows.Forms.Timer();
                t.Interval = 500;
                bool visible = true;
                t.Tick += (s, e) =>
                {
                    visible = !visible;
                    trayIcon.Visible = visible;
                };
                t.Start();
                var stopTimer = new System.Windows.Forms.Timer();
                stopTimer.Interval = (int)durationMs;
                stopTimer.Tick += (s, e) =>
                {
                    t.Stop();
                    trayIcon.Visible = true;
                    stopTimer.Stop();
                };
                stopTimer.Start();
            } catch { }
        }

        // 播放提示音
        private void PlayNotificationSound()
        {
            try
            {
                // 用系统默认提示音
                SystemSounds.Asterisk.Play();
            } catch { }
        }

        // 完整提醒:声音+任务栏闪烁+托盘闪烁
        private void DoNotify()
        {
            PlayNotificationSound();
            FlashTaskbar(5);
            FlashTray(3000);
        }

        public MainForm()
        {
            Text = Program.GetWindowTitle();
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.CenterScreen;
            Size = new Size(1280, 800);
            MinimumSize = new Size(900, 600);
            BackColor = Color.FromArgb(241, 245, 249);
            Font = new Font("Microsoft YaHei UI", 9F);
            try { int v = 1; DwmSetWindowAttribute(Handle, 2, ref v, 4); } catch {}
            try { int corner = 2; DwmSetWindowAttribute(Handle, 33, ref corner, 4); } catch {}

            // 系统托盘
            InitTray();

            titleBar = new Panel();
            titleBar.Location = new Point(1, 1);
            titleBar.Size = new Size(Width - 2, TITLE_H);
            titleBar.BackColor = Color.White;
            titleBar.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            Controls.Add(titleBar);

            btnMin = MkBtn("\uE921", Width - 140); btnMin.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnMin.Click += (s,e) => WindowState = FormWindowState.Minimized;
            titleBar.Controls.Add(btnMin);
            btnMax = MkBtn("\uE922", Width - 94); btnMax.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnMax.Click += (s,e) => ToggleMax();
            titleBar.Controls.Add(btnMax);
            btnClose = MkBtn("\uE8BB", Width - 48); btnClose.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnClose.MouseEnter += (s,e) => { btnClose.BackColor=Color.FromArgb(232,17,35); btnClose.ForeColor=Color.White; };
            btnClose.MouseLeave += (s,e) => { btnClose.BackColor=Color.Transparent; btnClose.ForeColor=Color.FromArgb(100,116,139); };
            btnClose.Click += (s,e) => HideToTray();
            titleBar.Controls.Add(btnClose);

            titleBar.MouseDown += (s,e) => { if(e.Button==MouseButtons.Left) Drag(); };

            webView = new WebView2();
            webView.Location = new Point(1, TITLE_H + 1);
            webView.Size = new Size(Width - 2, Height - TITLE_H - 2);
            webView.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Controls.Add(webView);

            Shown += async (s,e) => await InitWebView();
        }

        private void InitTray()
        {
            string icoPath = Path.Combine(Application.StartupPath, "app.ico");
            Icon ico = File.Exists(icoPath) ? new Icon(icoPath) : SystemIcons.Application;

            var menu = new ContextMenuStrip();
            menu.Font = new Font("Microsoft YaHei UI", 9F);

            var showItem = new ToolStripMenuItem("显示主界面");
            showItem.Click += (s, e) => ShowWindow();
            menu.Items.Add(showItem);

            menu.Items.Add(new ToolStripSeparator());

            var exitItem = new ToolStripMenuItem("退出软件");
            exitItem.Click += (s, e) => ExitApp();
            menu.Items.Add(exitItem);

            trayIcon = new NotifyIcon();
            trayIcon.Icon = ico;
            trayIcon.Text = Program.GetWindowTitle();
            trayIcon.Visible = true;
            trayIcon.ContextMenuStrip = menu;
            trayIcon.MouseDoubleClick += (s, e) => { if (e.Button == MouseButtons.Left) ShowWindow(); };
        }

        private void HideToTray()
        {
            Hide();
            // 已移除最小化到托盘的气泡提示
        }

        private void ShowWindow()
        {
            Show();
            WindowState = FormWindowState.Normal;
            Activate();
        }

        private void ExitApp()
        {
            allowClose = true;
            try { trayIcon.Visible = false; } catch {}
            // 同步通知服务器退出(等待响应,确保服务器收到退出信号)
            try {
                using(var c=new WebClient()) {
                    c.DownloadString("http://127.0.0.1:" + Program.GetPort() + "/api/exit");
                }
            } catch {}
            // 等待服务器和子进程退出
            System.Threading.Thread.Sleep(1500);
            // 杀死本软件相关的残留进程(pythonw.exe和node.exe,按命令行路径过滤)
            try {
                string appDir = Application.StartupPath.ToLower();
                foreach(var proc in System.Diagnostics.Process.GetProcesses()) {
                    try {
                        string pname = proc.ProcessName.ToLower();
                        if(pname == "pythonw" || pname == "python" || pname == "node") {
                            // 检查进程路径是否在本软件目录下
                            string ppath = proc.MainModule.FileName.ToLower();
                            if(ppath.StartsWith(appDir)) {
                                proc.Kill();
                            }
                        }
                    } catch {}
                }
            } catch {}
            Application.Exit();
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (!allowClose)
            {
                e.Cancel = true;
                HideToTray();
            }
            base.OnFormClosing(e);
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == 0x0084 && WindowState != FormWindowState.Maximized)
            {
                var p = PointToClient(Cursor.Position);
                if (p.X < BW && p.Y < BW) { m.Result = (IntPtr)13; return; }
                if (p.X > Width - BW && p.Y < BW) { m.Result = (IntPtr)14; return; }
                if (p.X < BW && p.Y > Height - BW) { m.Result = (IntPtr)16; return; }
                if (p.X > Width - BW && p.Y > Height - BW) { m.Result = (IntPtr)17; return; }
                if (p.X < BW) { m.Result = (IntPtr)10; return; }
                if (p.X > Width - BW) { m.Result = (IntPtr)11; return; }
                if (p.Y < BW) { m.Result = (IntPtr)12; return; }
                if (p.Y > Height - BW) { m.Result = (IntPtr)15; return; }
            }
            base.WndProc(ref m);
        }

        private Label MkBtn(string symbol, int x)
        {
            var b = new Label { Text=symbol, Font=new Font("Segoe MDL2 Assets", 10F), ForeColor=Color.FromArgb(100,116,139),
                TextAlign=ContentAlignment.MiddleCenter, Location=new Point(x,0), Size=new Size(46,TITLE_H), Cursor=Cursors.Hand };
            b.MouseEnter += (s,e) => { b.BackColor=Color.FromArgb(241,245,249); b.ForeColor=Color.FromArgb(15,23,42); };
            b.MouseLeave += (s,e) => { b.BackColor=Color.Transparent; b.ForeColor=Color.FromArgb(100,116,139); };
            return b;
        }

        private void Drag() { ReleaseCapture(); SendMessage(Handle, 0xA1, 2, 0); }

        private void ToggleMax()
        {
            if (isMax) { WindowState=FormWindowState.Normal; btnMax.Text="\uE922"; isMax=false; }
            else { WindowState=FormWindowState.Maximized; btnMax.Text="\uE923"; isMax=true; }
        }

        private async System.Threading.Tasks.Task InitWebView()
        {
            Activate();
            try
            {
                string ud = Path.Combine(Application.StartupPath, "data", "webview2");
                Directory.CreateDirectory(ud);
                var env = await CoreWebView2Environment.CreateAsync(null, ud);
                await webView.EnsureCoreWebView2Async(env);
                webView.CoreWebView2.Settings.AreDevToolsEnabled = false;
                webView.CoreWebView2.Settings.IsZoomControlEnabled = false;
                // 注册JavaScript消息接收:前端可以用chrome.webview.postMessage({type:'notify'})触发提醒
                webView.CoreWebView2.WebMessageReceived += (s, e) =>
                {
                    try
                    {
                        string msg = e.WebMessageAsJson;
                        if (msg.Contains("\"notify\""))
                        {
                            DoNotify();
                        }
                        else if (msg.Contains("\"sound\""))
                        {
                            PlayNotificationSound();
                        }
                        else if (msg.Contains("\"flash\""))
                        {
                            FlashTaskbar(5);
                            FlashTray(3000);
                        }
                    } catch { }
                };
                webView.CoreWebView2.Navigate("http://127.0.0.1:" + Program.GetPort() + "/");
            }
            catch (Exception ex)
            {
                // 写错误日志
                try
                {
                    string logPath = Path.Combine(Application.StartupPath, "data", "webview2-error.log");
                    Directory.CreateDirectory(Path.GetDirectoryName(logPath));
                    File.WriteAllText(logPath, DateTime.Now.ToString() + "\r\n" + ex.ToString());
                }
                catch { }
                FallbackEdge(ex.Message);
            }
        }

        private void FallbackEdge(string reason)
        {
            // 先尝试用Edge打开
            string[] c = { @"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
                           @"C:\Program Files\Microsoft\Edge\Application\msedge.exe" };
            foreach (var p in c)
            {
                if (File.Exists(p))
                {
                    try
                    {
                        Process.Start(p, "--app=http://127.0.0.1:" + Program.GetPort() + "/");
                        // 用Edge打开成功，显示提示后关闭
                        MessageBox.Show("WebView2初始化失败，已用Edge浏览器打开。\n\n错误信息: " + reason, "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        allowClose = true;
                        Close();
                        return;
                    }
                    catch { }
                }
            }
            // Edge也不行，尝试用默认浏览器
            try
            {
                Process.Start("http://127.0.0.1:8765/");
                MessageBox.Show("WebView2初始化失败，已用默认浏览器打开。\n\n错误信息: " + reason, "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                allowClose = true;
                Close();
                return;
            }
            catch { }
            // 都不行，显示错误，不关闭程序
            MessageBox.Show("无法启动窗口: " + reason + "\n\n请手动在浏览器打开 http://127.0.0.1:8765/", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
