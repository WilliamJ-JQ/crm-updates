@echo off
title CRM Workstation - Updating...

echo ========================================
echo   Applying update, please wait...
echo ========================================
echo.

echo [1/3] Waiting for old process to exit...
timeout /t 3 /nobreak >nul

echo [2/3] Stopping all old processes...
taskkill /f /im "CRMWorkstation.exe" >nul 2>&1
taskkill /f /im "�ͻ�����̨.exe" >nul 2>&1
taskkill /f /im pythonw.exe >nul 2>&1
taskkill /f /im python.exe >nul 2>&1
taskkill /f /im node.exe >nul 2>&1
timeout /t 2 /nobreak >nul
echo   Done

echo [3/3] Restarting application...
cd /d "%~dp0"
start "" "%~dp0�����ͻ�����̨.bat"
echo   Restart initiated!

timeout /t 3 /nobreak >nul
exit /b 0
