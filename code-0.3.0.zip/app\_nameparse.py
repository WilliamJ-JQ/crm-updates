# -*- coding: utf-8 -*-
"""从 WhatsApp 导出文件名中智能提取客户名和国家。"""
import re

# 国家关键词(英文/中文) — 用单词边界匹配,避免部分匹配
_COUNTRY_KEYWORDS = [
    (r"\bkenya\b", "肯尼亚"), (r"\bkenyan\b", "肯尼亚"),
    (r"\bghana\b", "加纳"), (r"\bghanian\b", "加纳"),
    (r"\bnigeria\b", "尼日利亚"), (r"\bnigerian\b", "尼日利亚"),
    (r"\bsouth\s*africa\b", "南非"), (r"\bsouthafrica\b", "南非"),
    (r"\begypt\b", "埃及"), (r"\begyptian\b", "埃及"),
    (r"\buae\b", "阿联酋"), (r"\bdubai\b", "阿联酋"), (r"\bemirates\b", "阿联酋"),
    (r"\bsaudi\b", "沙特"), (r"\bsaudi\s*arabia\b", "沙特"),
    (r"\bqatar\b", "卡塔尔"), (r"\bkuwait\b", "科威特"), (r"\boman\b", "阿曼"), (r"\bbahrain\b", "巴林"),
    (r"\btanzania\b", "坦桑尼亚"), (r"\buganda\b", "乌干达"),
    (r"\bcameroon\b", "喀麦隆"), (r"\bivory\s*coast\b", "科特迪瓦"),
    (r"\bbenin\b", "贝宁"), (r"\bmorocco\b", "摩洛哥"), (r"\btunisia\b", "突尼斯"),
    (r"\balgeria\b", "阿尔及利亚"), (r"\bsudan\b", "苏丹"), (r"\bethiopia\b", "埃塞俄比亚"),
    (r"\busa\b", "美国"), (r"\bamerica\b", "美国"), (r"\bunited\s*states\b", "美国"),
    (r"\buk\b", "英国"), (r"\bbritain\b", "英国"), (r"\bengland\b", "英国"),
    (r"\baustralia\b", "澳大利亚"), (r"\baus\b", "澳大利亚"),
    (r"\bcanada\b", "加拿大"), (r"\bgermany\b", "德国"), (r"\bfrance\b", "法国"),
    (r"\bitaly\b", "意大利"), (r"\bspain\b", "西班牙"), (r"\bnetherlands\b", "荷兰"),
    (r"\bbelgium\b", "比利时"), (r"\bswitzerland\b", "瑞士"), (r"\bsweden\b", "瑞典"),
    (r"\bnorway\b", "挪威"), (r"\bpoland\b", "波兰"), (r"\brussia\b", "俄罗斯"),
    (r"\bbrazil\b", "巴西"), (r"\bmexico\b", "墨西哥"), (r"\bargentina\b", "阿根廷"),
    (r"\bchile\b", "智利"), (r"\bcolombia\b", "哥伦比亚"), (r"\bperu\b", "秘鲁"),
    (r"\bjapan\b", "日本"), (r"\bkorea\b", "韩国"), (r"\bsingapore\b", "新加坡"),
    (r"\bmalaysia\b", "马来西亚"), (r"\bthailand\b", "泰国"), (r"\bvietnam\b", "越南"),
    (r"\bindonesia\b", "印尼"), (r"\bindia\b", "印度"), (r"\bpakistan\b", "巴基斯坦"),
    (r"\bbangladesh\b", "孟加拉"), (r"\bphilippines\b", "菲律宾"),
    (r"\bchina\b", "中国"),
]

# 中文国家名
_CN_COUNTRIES = ["迪拜", "肯尼亚", "加纳", "尼日利亚", "南非", "埃及", "阿联酋", "沙特", "卡塔尔",
                 "科威特", "阿曼", "巴林", "坦桑尼亚", "乌干达", "喀麦隆", "科特迪瓦",
                 "贝宁", "摩洛哥", "突尼斯", "阿尔及利亚", "苏丹", "埃塞俄比亚",
                 "美国", "英国", "澳大利亚", "加拿大", "德国", "法国", "意大利",
                 "西班牙", "荷兰", "比利时", "瑞士", "瑞典", "挪威", "波兰", "俄罗斯",
                 "巴西", "墨西哥", "阿根廷", "智利", "哥伦比亚", "秘鲁", "日本",
                 "韩国", "新加坡", "马来西亚", "泰国", "越南", "印尼", "印度",
                 "巴基斯坦", "孟加拉", "菲律宾", "中国", "刚果金", "刚果"]

# 噪音词(分类、标签、项目类型等,不是人名)
_NOISE_WORDS = {
    "george", "vip", "project", "procurement", "deco", "decoration",
    "order", "sample", "quote", "quotation", "inquiry", "inquire",
    "customer", "client", "new", "old", "hot", "warm", "cold",
    "whatsapp", "chat", "with", "and", "the", "for", "from", "what",
    "建群", "群聊", "客户", "询价", "报价", "订单", "样品",
    "新客户", "老客户", "重点", "跟进", "待跟进", "vip客户", "客户询价",
    "采购", "项目", "装饰", "装修",
}

# 编号模式
_NUM_PATTERN = re.compile(r"^(w|wk|week|q|#)?\d+[\.\-]?\d*$", re.IGNORECASE)


def parse_filename(fname):
    """从文件名提取 (客户名, 国家)。"""
    if not fname:
        return "", ""
    name = re.sub(r"\.(zip|txt|md|text)$", "", fname, flags=re.IGNORECASE)
    name = name.replace("_", " ").replace("-", " ").replace("–", " ").replace("—", " ")
    # 提取国家(英文,单词边界)
    country = ""
    name_lower = name.lower()
    for pattern, cn in _COUNTRY_KEYWORDS:
        if re.search(pattern, name_lower):
            country = cn
            name = re.sub(pattern, " ", name, flags=re.IGNORECASE)
            break
    # 去掉中文国家名
    for cn in _CN_COUNTRIES:
        if cn in name:
            if not country:
                country = cn
            name = name.replace(cn, " ")
    # 分词
    tokens = [t.strip() for t in name.split() if t.strip()]
    # 过滤噪音和编号
    clean_tokens = []
    for t in tokens:
        tl = t.lower().strip(".,!?()[]{}")
        if tl in _NOISE_WORDS:
            continue
        if _NUM_PATTERN.match(tl):
            continue
        if re.match(r"^[\d\s\+\-]+$", t):
            continue
        # 纯中文且是噪音词的跳过
        if re.match(r"^[\u4e00-\u9fff]+$", t) and t in _NOISE_WORDS:
            continue
        clean_tokens.append(t)
    # 客户名:优先取第一个英文token(通常是人名),没有则取第一个干净token
    peer_name = ""
    for t in clean_tokens:
        if re.match(r"^[A-Za-z]", t):  # 英文名
            peer_name = t
            break
    if not peer_name and clean_tokens:
        peer_name = clean_tokens[0]
    # 如果第一个token是全大写缩写且<=3,试第二个
    if peer_name and len(peer_name) <= 3 and peer_name.isupper() and len(clean_tokens) > 1:
        for t in clean_tokens[1:]:
            if re.match(r"^[A-Za-z]", t):
                peer_name = t
                break
    return peer_name, country