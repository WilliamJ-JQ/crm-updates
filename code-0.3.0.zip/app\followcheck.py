# -*- coding: utf-8 -*-
"""待跟进自动关闭(AI上下文判定)。

工作流(用户 2026-10-07 重定):
  第二层:回复判定层
    - 对每个approved状态的提醒,直接调用ai_find_best_reply
    - AI在前后5条上下文中找到最符合的回复
    - AI判符合 → 直接进已处理(AI判 + 依据)
    - AI找到但不确定 → 标记为已回复待人工确认
    - AI认为没有符合回复 → 保持待跟进
    - AI调用失败 → 交人工判定,不降级

铁律:自动完成的动作永远要能追到"我方哪条原话",追不到就不许自动关闭。
"""
import re
from datetime import datetime, timedelta

from . import ai as ai_mod
from . import db

# 这些属于"复杂回复":涉及正式文件/合同/方案,AI 不自动判,必须人工看
# 注意:简单价格数字(如"12-15 USD/㎡")不算复杂回复,AI可以直接判符合
# 只有正式报价单/PI/合同/完整方案才算复杂回复
_COMPLEX_RE = re.compile(
    r"报价单|正式报价|合同|定金|付款条款|交期承诺|货期承诺|完整方案|设计方案|"
    r"proforma|invoice|\bPI\b|contract|agreement|"
    r"catalog|brochure|产品目录|产品册",
    re.I)


# 我方人员的显示名:PM=我 / SM=销售经理 / team=团队
_WHO = {"pm": "我(PM)", "sm": "销售经理", "team": "团队",
        "designer": "客户设计师", "other": "客户方成员", "customer": "客户"}


def who_label(name, role):
    """把「谁回的」变成人能看懂的一行字,例:张三(SM) / 我(PM)。"""
    base = _WHO.get((role or "").strip(), "")
    nm = (name or "").strip()
    if nm and nm != base:
        return "%s(%s)" % (nm, base) if base else nm
    return base or nm


def code_scan(customer_id=None, limit=100):
    """第二层:AI在前后5条上下文中找到最符合的回复,判断是否解决需求。

    工作流:
    1. 遍历所有approved状态的提醒
    2. 对每个提醒,直接调用ai_find_best_reply(前后5条上下文)
    3. AI判符合 → 直接进已处理(AI判)
    4. AI找到但不确定 → 标记为已回复待人工确认
    5. AI认为没有符合回复 → 保持待跟进
    6. AI调用失败 → 交人工判定,不降级
    """
    rows = db.list_reminders(status=db.R_APPROVED, limit=limit)
    checked = found = 0
    try:
        for r in rows:
            if customer_id and r["customer_id"] != customer_id:
                continue
            # 跳过被人工撤回的提醒(skip_auto=1),避免撤回后又被自动完成
            if r.get("skip_auto"):
                continue
            src_ts = (r.get("src_ts") or "").strip()
            if not src_ts:
                continue          # 没有原话时间,不敢自动判
            src_mid = r.get("src_msg_id")
            if not src_mid:
                continue          # 没有原话消息ID,AI无法定位上下文
            checked += 1
            # 已由 AI/人工定论 → 保持结论,不要每轮重设(否则会与 AI 层来回震荡)
            if r.get("reply_state") in ("answered_ai", "needs_human", "not_answered"):
                continue
            # 直接调用AI在前后5条上下文中找到最符合的回复
            try:
                best_id, adequate, ai_reason = ai_find_best_reply(r["id"])
                # 区分AI调用失败和AI认为没有符合回复
                _AI_ERRORS = ("ai-error", "ai-invalid", "no-reminder", "no-source")
                if ai_reason in _AI_ERRORS:
                    # AI调用失败 → 交人工判定,不降级
                    db.set_reminder_reply(
                        r["id"], "needs_human", None, None,
                        "AI调用失败(%s),需人工判定回复是否符合" % ai_reason)
                    continue
                if best_id:
                    # AI找到了回复
                    best_msg = db.get_message(best_id)
                    if best_msg:
                        found += 1
                        who = who_label(best_msg.get("sender_name"), best_msg.get("sender_role"))
                        if adequate:
                            # AI判符合 → 直接进已处理
                            db.set_reminder_reply(
                                r["id"], "answered_ai", best_id, best_msg["content"],
                                "AI判:前后5条上下文中找到最符合回复(%s · %s),%s → 自动完成"
                                % (who, best_msg["ts"][:16] if best_msg.get("ts") else "", ai_reason),
                                reply_by=who, reply_role=(best_msg.get("sender_role") or ""))
                            con2 = db.connect()
                            con2.execute("UPDATE reminders SET decided_by='ai', status=?, decided_at=?"
                                         " WHERE id=? AND status='approved'",
                                         (db.R_DONE, db.now_iso(), r["id"]))
                            con2.commit(); con2.close()
                        else:
                            # AI找到回复但不确定是否符合 → 标记为已回复待确认
                            db.set_reminder_reply(
                                r["id"], "needs_human", best_id, best_msg["content"],
                                "AI判:找到回复但不确定是否解决需求(%s · %s),%s → 待人工确认"
                                % (who, best_msg["ts"][:16] if best_msg.get("ts") else "", ai_reason),
                                reply_by=who, reply_role=(best_msg.get("sender_role") or ""))
                    continue
                else:
                    # AI正常运行但认为没有符合的回复 → 保持待跟进状态
                    db.set_reminder_reply(
                        r["id"], "not_answered", None, None,
                        "AI判:前后5条上下文中未找到符合回复(%s) → 保持待跟进" % ai_reason)
                    continue
            except Exception as e:
                # AI调用异常 → 交给人工判定,不降级用代码层
                import traceback
                try:
                    import os
                    with open(os.path.join(db.PROJECT_DIR, "data", "app.log"), "a", encoding="utf-8") as f:
                        f.write("[ai_find_best_reply ERROR] reminder=%s: %s\n%s\n" % (
                            r.get("id"), str(e), traceback.format_exc()))
                except Exception:
                    pass
                db.set_reminder_reply(
                    r["id"], "needs_human", None, None,
                    "AI调用异常,需人工判定回复是否符合")
                continue
    finally:
        pass
    return checked, found


def on_out_message(customer_id):
    """我方刚发出一条消息 → 跑code_scan(AI在前后5条中找最符合回复)。"""
    try:
        return code_scan(customer_id=customer_id)
    except Exception:
        return (0, 0)


def stats():
    con = db.connect()
    try:
        def n(state):
            return con.execute(
                "SELECT COUNT(*) n FROM reminders WHERE status=? AND reply_state=?",
                (db.R_APPROVED, state)).fetchone()["n"]
        return {"no_reply": n("no_reply"), "replied": n("replied"),
                "answered_ai": n("answered_ai"), "needs_human": n("needs_human"),
                "not_answered": n("not_answered")}
    finally:
        con.close()


# AI判断PM手动标记为"已回复"的消息是否真正解决了客户需求
# 如果没解决(如只是解释工厂放假),生成新的"我方承诺"待跟进
_REPLY_ADEQUATE_SYS = (
    "你是外贸业务助理。判断【我方回复】是否真正解决了【客户需求】。\n"
    "客户需求可能是:要报价、要方案、要交期、要样品等。\n"
    "我方回复如果只是解释原因(如工厂放假、需要时间、正在准备)而没有给出实际结果,\n"
    "就不算真正解决,应该生成新的承诺待跟进。\n"
    "【文档识别】如果我方回复是'[文档] 文件名'格式:\n"
    "- 文件名包含 quote/pi/报价/quotation/proforma/invoice/price 等关键词 → 这是报价单,算真正解决了客户的报价需求\n"
    "- 文件名包含 design/drawing/cad/方案/图纸 等关键词 → 这是方案/图纸,算真正解决了客户的方案需求\n"
    "- 文件名包含 sample/样品 等关键词 → 这是样品相关,算真正解决了客户的样品需求\n"
    "输出JSON:{\"adequate\":true/false,\"reason\":\"一句话说明\",\"new_promise\":\"如果没解决,应该承诺什么(如'假期后提供报价'),留空表示不需要新承诺\"}"
)

# AI在前后5条上下文中找到最符合的回复
_FIND_BEST_REPLY_SYS = (
    "你是外贸业务助理。给定【客户需求消息】和前后各5条聊天记录,\n"
    "请在这些消息中找到最能解决客户需求的【我方回复】。\n"
    "客户需求可能是:要报价、要方案、要交期、要样品、要视频通话、问价格等。\n"
    "判断标准:\n"
    "1. 回复必须是我方发出的(PM/销售经理/团队)\n"
    "2. 回复必须在客户需求之后\n"
    "3. 回复必须真正回应了客户需求:\n"
    "   - 客户问价格 → 回复包含价格数字(如12-15 USD、$100、264USD)就算符合\n"
    "   - 客户问交期 → 回复包含时间(如3天、下周、10月15号)就算符合\n"
    "   - 客户问能不能视频 → 回复yes/ok/可以/同意就算符合\n"
    "   - 客户要样品 → 回复说已寄出/给快递单号就算符合\n"
    "   - 客户要方案 → 回复给了方案/图纸/图片就算符合\n"
    "4. 【文档识别】如果回复是'[文档] 文件名'格式:\n"
    "   - 文件名包含 quote/pi/报价/quotation/proforma/invoice/price → 报价单,符合客户询价需求\n"
    "   - 文件名包含 design/drawing/cad/方案/图纸 → 方案/图纸,符合客户方案需求\n"
    "   - 文件名包含 sample/样品 → 样品相关,符合客户样品需求\n"
    "   - 文档可以作为正式回复依据,比单纯文字回复更有说服力\n"
    "5. 只是寒暄(hello/hi)、解释原因(工厂放假/需要时间)、说'我开始工作了'、只说产品名字不算真正回复\n"
    "6. 如果有多条回复,选最直接、最完整解决需求的那一条\n"
    "7. 只要回复包含了客户要的关键信息(价格/时间/确认/报价单文档),就算符合,不需要非常正式或完整\n"
    "输出JSON:{\"reply_id\":消息ID(数字,没有则为null),\"adequate\":true/false,\"reason\":\"一句话说明为什么选这条或为什么没有符合的回复\"}"
)


def ai_find_best_reply(reminder_id):
    """AI在待跟进消息的前后5条上下文中找到最符合的回复。

    返回 (reply_msg_id, adequate, reason)
    """
    rem = db.get_reminder(reminder_id)
    if not rem:
        return None, False, "no-reminder"
    cid = rem.get("customer_id")
    src_mid = rem.get("src_msg_id")
    if not cid or not src_mid:
        return None, False, "no-source"
    # 获取前后各5条消息
    con = db.connect()
    try:
        # 前面5条
        before = con.execute(
            "SELECT id, ts, content, direction, sender_role, sender_name FROM messages"
            " WHERE customer_id=? AND id < ? ORDER BY id DESC LIMIT 5",
            (cid, src_mid)).fetchall()
        before = list(reversed([dict(x) for x in before]))
        # 客户需求消息本身
        src_msg = con.execute(
            "SELECT id, ts, content, direction, sender_role, sender_name FROM messages WHERE id=?",
            (src_mid,)).fetchone()
        # 后面5条
        after = con.execute(
            "SELECT id, ts, content, direction, sender_role, sender_name FROM messages"
            " WHERE customer_id=? AND id > ? ORDER BY id ASC LIMIT 5",
            (cid, src_mid)).fetchall()
        after = [dict(x) for x in after]
    finally:
        con.close()
    # 组装上下文
    ctx_lines = []
    for m in before:
        role = "客户" if m["direction"] == "in" else "我方"
        ctx_lines.append("[%s][%s][id=%s] %s: %s" % (
            m["ts"][:16] if m["ts"] else "", role, m["id"],
            m.get("sender_name") or "", (m["content"] or "")[:200]))
    if src_msg:
        src_msg = dict(src_msg)
        ctx_lines.append("[%s][客户需求][id=%s] %s: %s" % (
            src_msg["ts"][:16] if src_msg["ts"] else "", src_msg["id"],
            src_msg.get("sender_name") or "", (src_msg["content"] or "")[:200]))
    for m in after:
        role = "客户" if m["direction"] == "in" else "我方"
        ctx_lines.append("[%s][%s][id=%s] %s: %s" % (
            m["ts"][:16] if m["ts"] else "", role, m["id"],
            m.get("sender_name") or "", (m["content"] or "")[:200]))
    context = "\n".join(ctx_lines)
    ask = "客户需求:%s\n\n聊天记录(前后各5条):\n%s\n\n请找到最符合的我方回复,输出JSON。" % (
        (rem.get("note") or "")[:100], context)
    try:
        from . import ai
        out = ai._call_api([
            {"role": "system", "content": _FIND_BEST_REPLY_SYS},
            {"role": "user", "content": ask},
        ])
    except Exception:
        return None, False, "ai-error"
    if isinstance(out, list):
        out = out[0] if out and isinstance(out[0], dict) else {}
    if not isinstance(out, dict):
        return None, False, "ai-invalid"
    reply_id = out.get("reply_id")
    adequate = bool(out.get("adequate"))
    reason = str(out.get("reason") or "")[:200]
    try:
        reply_id = int(reply_id) if reply_id else None
    except (TypeError, ValueError):
        reply_id = None
    return reply_id, adequate, reason


def ai_check_reply_adequate(rid, reply_msg_id):
    """PM手动标记为"已回复"后,AI判断回复是否真正解决了客户需求。

    - 如果解决了 → 标记为"已处理"
    - 如果没解决 → 生成新的"我方承诺"待跟进
    - AI拿不准 → 保持"已回复",交PM确认
    """
    rem = db.get_reminder(rid)
    if not rem:
        return "no-reminder"
    reply_msg = db.get_message(reply_msg_id)
    if not reply_msg:
        return "no-reply-msg"

    customer_need = (rem.get("note") or "")[:100]
    customer_original = (rem.get("quote") or "")[:200]
    reply_content = (reply_msg.get("content") or "")[:300]

    ask = ("客户需求:%s\n客户原话:%s\n我方回复:%s\n\n"
           "判断我方回复是否真正解决了客户需求。"
           "如果只是解释原因(工厂放假/需要时间/正在准备)而没有给出实际结果,就算没解决。"
           % (customer_need, customer_original, reply_content))

    try:
        out = ai_mod._call_api([
            {"role": "system", "content": _REPLY_ADEQUATE_SYS},
            {"role": "user", "content": ask},
        ])
    except Exception:
        return "ai-error"

    if isinstance(out, list):
        out = out[0] if out and isinstance(out[0], dict) else {}
    if not isinstance(out, dict):
        return "ai-invalid"

    adequate = bool(out.get("adequate"))
    reason = str(out.get("reason") or "").strip()[:120]
    new_promise = str(out.get("new_promise") or "").strip()[:40]

    if adequate:
        # AI判断已解决 → 标记为"已处理"
        con = db.connect()
        try:
            con.execute("UPDATE reminders SET status=?, decided_by='ai', decided_at=?"
                        " WHERE id=?", (db.R_DONE, db.now_iso(), rid))
            con.commit()
        finally:
            con.close()
        db.set_reminder_reply(rid, "answered_ai", reply_msg_id, reply_content,
                              "AI判:回复已解决客户需求" + (("(" + reason + ")") if reason else ""))
        db.log_reminder(rid, rem.get("customer_id"), "AI判已解决",
                        db.R_APPROVED, db.R_DONE, reason or "")
        return "adequate"
    elif new_promise:
        # AI判断没解决,且建议了新承诺 → 生成新的"我方承诺"待跟进
        from datetime import date, timedelta
        new_rid = db.add_reminder(
            rem.get("customer_id"),
            "我方承诺:" + new_promise,
            "我方承诺:" + new_promise,
            days=None, status=db.R_APPROVED,
            notify_date=(date.today() + timedelta(days=3)).isoformat(),
            quote=reply_content[:300], src_ts=reply_msg.get("ts") or "",
            src_direction="out", auto="ai", src_msg_id=reply_msg_id,
            decided_by="ai",
            reason="AI判:原回复未解决客户需求(%s),生成新承诺" % reason)
        # 原提醒标记为"已回复"(保持待跟进,但已找到回复)
        db.set_reminder_reply(rid, "replied", reply_msg_id, reply_content,
                              "PM手动标记已回复,AI判未解决,已生成新承诺:%s" % new_promise)
        return "new_promise"
    else:
        # AI拿不准 → 保持"已回复",交PM确认
        db.set_reminder_reply(rid, "needs_human", reply_msg_id, reply_content,
                              "AI拿不准:回复是否解决客户需求?" + (("(" + reason + ")") if reason else ""))
        return "needs_human"
