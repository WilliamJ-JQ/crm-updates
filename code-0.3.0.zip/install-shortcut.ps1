$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$desktop = [Environment]::GetFolderPath('Desktop')
$lnk = Join-Path $desktop '客户工作台.lnk'
$ws = New-Object -ComObject WScript.Shell
$s = $ws.CreateShortcut($lnk)
$s.TargetPath = Join-Path $root '客户工作台.exe'
$s.WorkingDirectory = $root
$s.IconLocation = Join-Path $root '客户工作台.exe'
$s.Description = '外贸客户工作台'
$s.Save()
Write-Host "快捷方式已创建到桌面"