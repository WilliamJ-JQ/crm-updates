# -*- coding: utf-8 -*-
"""本地轻量翻译服务(英→中)
用 transformers + opus-mt-en-zh，质量稳定。
支持并发请求和批量翻译。
运行: python translate_server.py --port 8766
"""
import argparse
import json
import os
import shutil
import tempfile
import threading
import time
from http.server import HTTPServer, BaseHTTPRequestHandler

_SRC_MODEL_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ai-models", "translate-en-zh")
MODEL_DIR = os.path.join(tempfile.gettempdir(), "crm-translate-model")
if not os.path.exists(os.path.join(MODEL_DIR, "config.json")):
    if os.path.exists(_SRC_MODEL_DIR):
        shutil.copytree(_SRC_MODEL_DIR, MODEL_DIR, dirs_exist_ok=True)
        print(f"[translate] 模型已复制到英文路径: {MODEL_DIR}")

_model = None
_tokenizer = None
_model_lock = threading.Lock()  # 模型推理锁,防止并发推理导致崩溃


def load_model():
    global _model, _tokenizer
    if _model is not None:
        return
    with _model_lock:
        if _model is not None:
            return
        import torch
        from transformers import AutoTokenizer, AutoModelForSeq2SeqLM
        _tokenizer = AutoTokenizer.from_pretrained(MODEL_DIR)
        _model = AutoModelForSeq2SeqLM.from_pretrained(MODEL_DIR)
        _model.eval()
        print(f"[translate] 模型已加载: {MODEL_DIR}")


def translate_text(text, timeout=30):
    """翻译单条文本，返回中文。超时返回原文。"""
    if not text or not text.strip():
        return ""
    if any('\u4e00' <= c <= '\u9fff' for c in text):
        return text
    load_model()
    import torch
    try:
        with _model_lock:
            lines = text.split("\n")
            results = []
            for line in lines:
                if not line.strip():
                    results.append("")
                    continue
                inputs = _tokenizer(line, return_tensors="pt", truncation=True, max_length=512)
                with torch.no_grad():
                    outputs = _model.generate(
                        **inputs,
                        max_length=128,
                        num_beams=4,
                        early_stopping=True
                    )
                result = _tokenizer.decode(outputs[0], skip_special_tokens=True)
                results.append(result.strip())
            return "\n".join(results)
    except Exception as e:
        print(f"[translate] 翻译失败: {e}")
        return text  # 失败返回原文


def translate_batch(texts, timeout=60):
    """批量翻译，返回列表。"""
    results = []
    for text in texts:
        results.append(translate_text(text, timeout))
    return results


class ThreadingHTTPServer(HTTPServer):
    """支持并发的HTTP服务器。"""
    daemon_threads = True
    allow_reuse_address = True

    def process_request(self, request, client_address):
        t = threading.Thread(target=self._handle, args=(request, client_address))
        t.daemon = True
        t.start()

    def _handle(self, request, client_address):
        try:
            self.finish_request(request, client_address)
        except Exception:
            self.handle_error(request, client_address)
        finally:
            self.shutdown_request(request)


class TranslateHandler(BaseHTTPRequestHandler):
    def _send(self, data, code=200):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        if self.path == "/translate":
            try:
                length = int(self.headers.get("Content-Length", 0))
                body = self.rfile.read(length).decode("utf-8")
                data = json.loads(body)
                text = data.get("text", "")
                result = translate_text(text)
                self._send({"translation": result})
            except Exception as e:
                self._send({"error": str(e)}, 500)
        elif self.path == "/translate-batch":
            try:
                length = int(self.headers.get("Content-Length", 0))
                body = self.rfile.read(length).decode("utf-8")
                data = json.loads(body)
                texts = data.get("texts", [])
                results = translate_batch(texts)
                self._send({"translations": results})
            except Exception as e:
                self._send({"error": str(e)}, 500)
        else:
            self._send({"error": "not found"}, 404)

    def do_GET(self):
        if self.path == "/health":
            self._send({"status": "ok"})
        else:
            self._send({"error": "not found"}, 404)

    def log_message(self, format, *args):
        pass


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8766)
    args = parser.parse_args()
    print(f"[translate] 启动翻译服务端口 {args.port}...")
    load_model()
    print(f"[translate] 就绪: http://127.0.0.1:{args.port}/translate")
    server = ThreadingHTTPServer(("127.0.0.1", args.port), TranslateHandler)
    server.serve_forever()


if __name__ == "__main__":
    main()
