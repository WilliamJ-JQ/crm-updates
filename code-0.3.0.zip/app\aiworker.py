# -*- coding: utf-8 -*-
"""边聊边跑的 AI 识别队列(后台 worker)。

设计要点(按用户纠正后的版本):
  - 消息是**一条条散着来**的,不是所有消息都要 AI;实测十条里 1~2 条才需要
  - **代码先滤**(每条、瞬间、免费):像"待办"的才进队列
  - 队列丢给**后台线程**慢慢跑本地模型 —— PM 一边聊,AI 一边跑,**不阻塞**
  - 跑完自动归档:
      · 我方承诺  → 进【承诺审批】(等 PM 批;卡片必须一眼看清"承诺是什么")
      · 客户提问  → 直接进【待跟进】,标「系统直判」(可撤回)
  - 云端(DeepSeek)默认**不参与识别**,把成本留给夜间回复

成本:代码 0 元 → 本地模型 0 元。这一层不需要花钱。
"""
import json
import re
import threading
import time

from . import ai as ai_mod
from . import log
from . import db
from . import rules

# 队列上限:积压太多就不再往里塞,避免把本地 CPU 压死
MAX_PENDING = 40
POLL_SECONDS = 12

# ==================== 高价值关键词(匹配到任意一个 → 进AI队列) ====================
_HIGH_VALUE = {
    "报价": ("报价", "价格", "多少钱", "费用", "quote", "quotation", "price", "how much", "cost"),
    "我方承诺": ("我会", "我们安排", "明天给你", "后天给你", "答应", "承诺", "帮你做", "我来",
                "will do", "promise", "arrange", "i'll", "i will", "we will", "we'll", "let me"),
    "客户催促": ("催", "急", "尽快", "什么时候能", "等了很久", "还没好", "怎么还没",
                "urgent", "asap", "still waiting", "long time", "no reply", "when can"),
    "会议": ("会议", "视频", "通话", "打电话", "线上聊", "meeting", "call", "zoom", "teams", "video call"),
    "交期": ("交期", "货期", "发货", "什么时候到", "什么时候能发",
            "lead time", "delivery", "when ship", "eta", "shipping"),
    "样品": ("样品", "寄样", "样板", "sample", "swatch"),
    "合同付款": ("合同", "付款", "定金", "尾款", "pi发", "invoice",
                 "contract", "payment", "deposit", "balance"),
    "方案设计": ("方案", "搭配", "设计", "效果图", "rendering", "design plan"),
}

# ==================== 低价值关键词(匹配到且无高价值信号 → 直接丢弃) ====================
_LOW_VALUE = {
    "产品属性": ("材质", "颜色", "尺寸", "现货", "有货吗", "能定制吗", "什么材料",
                "material", "color", "colour", "size", "stock", "available", "customize"),
    "纯寒暄": ("你好", "早上好", "在吗", "嗨", "哈喽", "hi", "hello", "hey",
              "good morning", "good afternoon", "how are you", "how's going"),
    "简单确认": ("好的", "收到", "明白", "谢谢", "感谢", "ok", "okay", "noted",
                "thanks", "thank you", "got it", "sure", "fine", "no problem"),
}


def _match_keywords(text, keyword_dict):
    """匹配关键词,返回匹配到的类别列表。"""
    low = (text or "").lower()
    matched = []
    for cat, words in keyword_dict.items():
        for w in words:
            if w in low:
                matched.append(cat)
                break
    return matched


def should_enqueue(text, direction, analysis):
    """代码先滤:这条消息值不值得让 AI 看一眼?

    三层判断:
    1. 高价值关键词 → 直接进AI队列(报价/承诺/催促/会议/交期/样品/合同/方案)
    2. 低价值关键词 → 直接丢弃(产品属性/寒暄/确认),但必须无高价值信号
    3. 模糊地带 → 也进AI(宁可误判,不可漏判)

    返回 (是否进队列, 匹配到的高价值类别, 匹配到的低价值类别)
    """
    low = (text or "").lower().strip()
    if len(low) < 8:
        return False, [], ["超短消息"]

    high_matched = _match_keywords(text, _HIGH_VALUE)
    low_matched = _match_keywords(text, _LOW_VALUE)

    # 1. 高价值信号 → 直接进AI
    if high_matched:
        return True, high_matched, low_matched

    # 2. 低价值信号且无高价值 → 丢弃
    if low_matched:
        return False, [], low_matched

    # 3. 模糊地带:有问号、长度>30、或有业务信号 → 也进AI
    tags = (analysis or {}).get("tags") or []
    has_biz = bool(tags)
    has_question = "?" in low or "？" in low
    is_long = len(low) > 30

    # 我方消息:像承诺但关键词没匹配上 → 进AI
    sug = (analysis or {}).get("suggestion")
    if direction == "out" and sug and not sug.get("days"):
        return True, ["模糊-我方疑似承诺"], []

    if has_biz or has_question or is_long:
        return True, ["模糊-待AI确认"], []

    return False, [], ["无明确信号"]


_CLS_SYS = (
    "你是外贸业务助理。根据【当前消息】,判断这条消息里有没有【待办】。\n"
    "分类只能三种:\n"
    "- promise:【我方】(我司/业务员)答应了客户要做什么(报价/寄样/发资料/安排…)\n"
    "- question:【客户】在提问或提要求(要报价/要尺寸/要方案/问交期…)\n"
    "- none:只是寒暄、确认、闲聊,或只是背景信息\n"
    "注意:\n"
    "1. 说话人方向由输入里的【谁说的】决定,不要自己猜。\n"
    "2. 只看当前这一条消息,不要推测上下文或后续回复。\n"
    "promise 字段(**promise 和 question 两种都要填**):用**不超过 25 个汉字**说清"
    "『这件事是什么』(例:\"报价\"\"寄样\"\"提供CAD图纸\"\"确认交期\")。可以留空**只限** kind=none。\n"
    '只输出 JSON:{"kind":"promise","promise":"提供CAD图纸","reason":"一句话判断依据"}'
)


def classify(text, direction="in"):
    """让本地模型判断这条消息。返回 {"kind":..., "promise":..., "reason":...}。

    只看当前这一条消息,不看上下文。"是否已被回复"是第二层(回复判定层)的事。
    已踩坑:模型会把**客户**说的"can you send me the quotation"也判成 promise。
    所以:①告诉它谁说的话题;②代码再按方向归一化。
    """
    who = "客户发来的" if direction == "in" else "我方发出的"
    user_content = "【当前消息(%s)】\n%s" % (who, (text or "")[:600])
    try:
        out = ai_mod._call_api([
            {"role": "system", "content": _CLS_SYS},
            {"role": "user", "content": user_content},
        ])
    except Exception:
        return {"kind": "", "promise": "", "reason": ""}
    if isinstance(out, list):
        out = out[0] if out and isinstance(out[0], dict) else {}
    if not isinstance(out, dict):
        return {"kind": "", "promise": "", "reason": ""}
    kind = str(out.get("kind") or "").strip().lower()
    promise = str(out.get("promise") or "").strip()[:40]
    reason = str(out.get("reason") or "").strip()[:100]
    if kind not in ("promise", "question", "none"):
        kind = ""
    # 按方向归一化:客户的话不可能是我方承诺;我方的话既可能是承诺、也可能是在等客户回
    if kind == "promise" and direction == "in":
        kind = "question"
    if not kind and promise and direction == "in":
        kind = "question"
    return {"kind": kind, "promise": promise, "reason": reason}


def _fallback_summary(text, direction):
    """模型没给摘要时的代码兜底 —— 绝不因为“摘要为空”就把一条真待办丢掉。"""
    low = (text or "").lower()
    for pat, label in ((r"报价|价格|quote|price|quotation|offer", "报价"),
                       (r"样品|样板|sample|swatch", "寄样"),
                       (r"cad|图纸|design|方案|效果图|render", "设计图纸/方案"),
                       (r"交期|货期|lead time|delivery|什么时候", "交期"),
                       (r"尺寸|size|measure|毫米|mm|cm", "尺寸确认"),
                       (r"付款|定金|deposit|payment", "付款条件"),
                       (r"视频|图片|photo|video|picture", "图片/视频资料")):
        if re.search(pat, low):
            return label
    t = re.sub(r"\s+", " ", (text or "")).strip()
    return (t[:22] + ("…" if len(t) > 22 else "")) or ("客户提问" if direction == "in" else "我方承诺")


def apply_result(customer_id, direction, content, ts, res, msg_id=None, code_reason=""):
    """按 AI 判断归档:承诺 → 承诺审批;客户提问 → 直接进待跟进;拿不准 → 交 PM 审批。

    code_reason: 代码层匹配到的高价值类别(如"报价,客户催促"),用于显示判断依据。
    第一层AI只看单条消息,不判断"是否已被回复"(那是第二层的事)。
    """
    kind = (res.get("kind") or "").strip().lower()
    promise = (res.get("promise") or "").strip()
    ai_reason = (res.get("reason") or "").strip()
    # 构造完整的判断依据
    reason_parts = []
    if code_reason:
        reason_parts.append("代码匹配:%s" % code_reason)
    if ai_reason:
        reason_parts.append("AI判断:%s" % ai_reason)
    full_reason = " | ".join(reason_parts)
    if kind == "none":
        # AI明确判none → 只是寒暄/确认/低价值,直接丢弃,记录日志
        db.add_ai_log(customer_id, "classify_none", "none",
                      (content or "")[:200], "none",
                      detail="AI判断只是寒暄/确认/低价值,无需待办")
        return ""
    if not kind:
        # AI拿不准(kind为空) → 冒出来给 PM 审批,并留痕日志(方便调模型)
        # 有催促词时标为"客户催促",否则标为"客户提问"
        low = (content or "").lower()
        is_urgent = any(h in low for h in _URGENT_HINTS)
        rem_kind = "客户催促" if is_urgent else "客户提问"
        prefix = "❓待PM确认:客户在催促?" if is_urgent else "❓待PM确认:"
        summary = promise or _fallback_summary(content, direction) or (content or "")[:40]
        db.add_reminder(customer_id, rem_kind, prefix + summary,
                        days=None, status=db.R_SUGGESTED,
                        quote=(content or "")[:300], src_ts=ts or "",
                        src_direction=direction, auto="ai", src_msg_id=msg_id,
                        decided_by="review", reason=full_reason)
        db.add_ai_log(customer_id, "classify_unclear", "unclear",
                      (content or "")[:200], "unclear",
                      detail="代码+AI 都拿不准(有业务信号),交 PM 审批")
        return "待PM审批"
    if not promise:
        promise = _fallback_summary(content, direction)
    if kind == "promise" and direction == "out":
        db.add_reminder(customer_id,
                        rules.kind_of("out", (promise or "") + " " + (content or "")),
                        "我方承诺:" + promise, days=None, status=db.R_SUGGESTED,
                        quote=(content or "")[:300], src_ts=ts or "",
                        src_direction=direction, auto="ai", src_msg_id=msg_id,
                        decided_by="ai", reason=full_reason)
        return "承诺审批"
    if kind == "question" and direction == "in":
        # 客户提问 → 直接进待跟进,标「系统直判」,2 天后提醒
        from datetime import date, timedelta
        rid = db.add_reminder(customer_id,
                              rules.kind_of("in", (promise or "") + " " + (content or "")),
                              "客户要求:" + promise,
                              days=None, status=db.R_APPROVED,
                              notify_date=(date.today() + timedelta(days=2)).isoformat(),
                              quote=(content or "")[:300], src_ts=ts or "",
                              src_direction=direction, auto="ai", src_msg_id=msg_id,
                              decided_by="ai", reason=full_reason)
        # 时序补丁:待跟进是异步才创建的,可能错过"我方已回复"那一刻 —— 立刻补扫一次
        try:
            from . import followcheck
            followcheck.code_scan(customer_id=customer_id)
        except Exception as e:
            log.swallow("aiworker.py:apply_result_question", e)
        return "待跟进"
    return ""


def _is_quote(promise, content):
    s = (promise or "") + (content or "")[:200]
    return bool(re.search(r"报价|价格|quote|price|quotation", s, re.I))


def run_once():
    """处理一条队列消息。返回 True 表示处理了东西。

    流程:① 渐进上下文(纯代码)先试 → 要素齐就直接建档,**不调 AI**;
          ② 不齐 → 把**扩好的窗口**(不是单句)交给本地 AI 再判。
    """
    item = db.next_queued_msg()
    if not item:
        return False
    cid = item["customer_id"]
    direction = item.get("direction") or "in"
    content = item.get("content") or ""
    ts = item.get("ts")
    ai_on = ai_mod.enabled() and ai_mod.usage()["left"] > 0

    # 第一层AI判断:只看当前这一条消息,不看上下文
    # (上下文和回复判断是第二层followcheck的事)
    if not ai_on:
        db.finish_queued(item["qid"], "skipped", "", "")
        return True

    res = classify(content, direction)
    kind, promise = res.get("kind") or "", res.get("promise") or ""
    code_reason = item.get("code_reason") or ""
    where = apply_result(cid, direction, content, ts, res, msg_id=item.get("mid"),
                         code_reason=code_reason)

    db.finish_queued(item["qid"], "done" if where else "skipped", kind, promise)
    if where:
        from . import profile
        try:
            profile.enrich_customer(cid)
        except Exception as e:
            log.swallow("aiworker.py:run_once_enrich", e)
    return True


_thread = None
_stop = False


# 同一条消息最多重试几次(超过就标 error 离开队列)
# 【教训】以前 run_once 报错 → 循环只 sleep 就重试同一条 → 18 小时把本地模型跑满 CPU
MAX_ATTEMPTS = 3


def _loop():
    while not _stop:
        try:
            if db.queue_stats()["pending"] > 0:
                try:
                    did = run_once()
                except Exception:
                    # 单条消息出错 → 记一次尝试;超过上限就标 error,绝不无限重试
                    q = db.next_queued_msg()
                    if q:
                        n = db.bump_queue_attempt(q["qid"])
                        if n >= MAX_ATTEMPTS:
                            db.finish_queued(q["qid"], "error", "", "")
                    time.sleep(POLL_SECONDS)
                    continue
                if not did:
                    time.sleep(POLL_SECONDS)   # 取不到东西也别空转
                continue
            from . import followcheck
            # 兜底:定期跑代码层(纯代码、瞬间、零成本)—— 不依赖“我方发消息”那一瞬
            try:
                followcheck.code_scan()
            except Exception as e:
                log.swallow("aiworker.py:_loop_codescan", e)
            time.sleep(POLL_SECONDS)
        except Exception:
            time.sleep(POLL_SECONDS)


def start_background():
    """启动后台 worker(幂等)。"""
    global _thread
    if _thread and _thread.is_alive():
        return
    _thread = threading.Thread(target=_loop, daemon=True)
    _thread.start()


def stats():
    s = db.queue_stats()
    s["running"] = bool(_thread and _thread.is_alive())
    s["ai_enabled"] = ai_mod.enabled()
    return s
