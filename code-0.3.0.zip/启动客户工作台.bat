@echo off
chcp 65001 >nul
title 客户工作台 v0.3.0 启动器
cd /d %~dp0

echo ========================================
echo   客户工作台 v0.3.0 正在启动...
echo ========================================
echo.

REM ---- 第一步：检查WebView2运行时 ----
echo [1/3] 检查运行环境...
reg query "HKLM\SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}" /v pv >nul 2>&1
if %errorlevel%==0 (
    echo   WebView2运行时：已安装
) else (
    reg query "HKCU\SOFTWARE\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}" /v pv >nul 2>&1
    if %errorlevel%==0 (
        echo   WebView2运行时：已安装
    ) else (
        echo   WebView2运行时：未安装，正在自动安装...
        if exist "MicrosoftEdgeWebView2Setup.exe" (
            start /wait "" "MicrosoftEdgeWebView2Setup.exe" /silent /install
            echo   WebView2运行时安装完成
        ) else (
            echo   [警告] 找不到安装包，正在下载...
            powershell -Command "Invoke-WebRequest -Uri 'https://go.microsoft.com/fwlink/p/?LinkId=2124703' -OutFile '%TEMP%\WebView2Setup.exe' -UseBasicParsing"
            start /wait "" "%TEMP%\WebView2Setup.exe" /silent /install
            echo   WebView2运行时安装完成
        )
    )
)

REM ---- 第二步：创建桌面快捷方式 ----
echo.
echo [2/3] 创建桌面快捷方式...
if not exist "%USERPROFILE%\Desktop\客户工作台.lnk" (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=(New-Object -COM WScript.Shell).CreateShortcut('%USERPROFILE%\Desktop\客户工作台.lnk');$s.TargetPath='%~dp0启动客户工作台.bat';$s.WorkingDirectory='%~dp0';$s.IconLocation='%~dp0app.ico,0';$s.Save()"
    echo   桌面快捷方式已创建
) else (
    echo   桌面快捷方式已存在
)

REM ---- 第三步：启动软件 ----
echo.
echo [3/3] 启动客户工作台...
echo.
start "" "客户工作台.exe"

REM ---- 等待几秒后关闭启动窗口 ----
timeout /t 3 /nobreak >nul
exit
