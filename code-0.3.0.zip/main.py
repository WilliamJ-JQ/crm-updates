# -*- coding: utf-8 -*-
"""外贸客户工作台 —— 启动入口。

运行:
  python main.py                # 启动后自动打开浏览器操作台
  python main.py --no-browser   # 只启动服务(不弹浏览器)
  python main.py --port 9000    # 换端口

说明:界面是本地网页(只在你电脑上),数据全在本地 data/crm.db。

【更新机制】启动时先应用"已下载待更新"(update/pending/)—— 必须在
import app 之前做,这样新代码才会被加载。因此**重启即可生效**,不依赖
任何 .bat(taskkill/xcopy 在 Windows 上不可靠)。
"""
import argparse
import os
import shutil
import sys
import time

# 让 Windows 任务栏把本程序识别为独立应用(显示自定义图标)
if os.name == "nt":
    try:
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("CustomerDesk.App")
    except Exception:
        pass

ROOT = os.path.dirname(os.path.abspath(__file__))


def _backup_db():
    """应用更新前,先把客户数据库备份一份(双保险;更新本就不碰数据)。"""
    cands = []
    env = (os.environ.get("CRM_DATA_DIR") or "").strip()
    if env:
        cands.append(os.path.join(env, "crm.db"))
    cands.append(os.path.join(ROOT, "data", "crm.db"))
    cands.append(os.path.join(os.path.expanduser("~"), "客户工作台数据", "crm.db"))
    for dbp in cands:
        if os.path.exists(dbp):
            try:
                shutil.copy2(dbp, dbp + ".bak-update-" + time.strftime("%Y%m%d-%H%M%S"))
                print("[update] 已备份数据库:", dbp)
            except Exception as e:
                print("[update] 备份数据库失败(继续):", e)
            return


def _apply_pending_update():
    """把 update/pending/ 里的新代码覆盖到软件目录。失败不影响启动。"""
    pend = os.path.join(ROOT, "update", "pending")
    if not os.path.isdir(pend):
        return
    try:
        _backup_db()
        for name in os.listdir(pend):
            src = os.path.join(pend, name)
            dst = os.path.join(ROOT, name)
            if os.path.isdir(src):
                shutil.copytree(src, dst, dirs_exist_ok=True)
            else:
                shutil.copy2(src, dst)
        shutil.rmtree(pend, ignore_errors=True)
        pj = os.path.join(ROOT, "update", "pending.json")
        if os.path.exists(pj):
            os.remove(pj)
        print("[update] 已应用上次下载的更新")
    except Exception as e:
        print("[update] 应用更新失败(不影响启动):", e)


_apply_pending_update()

from app import server   # noqa: E402  (必须在应用更新之后再导入)


def _already_running(port):
    """检测软件是否已在跑(端口能通 = 已启动)。"""
    import socket
    try:
        s = socket.create_connection(("127.0.0.1", port), timeout=1.5)
        s.close()
        return True
    except Exception:
        return False


def main():
    p = argparse.ArgumentParser(description="外贸客户工作台(本地版)")
    p.add_argument("--port", type=int, default=server.DEFAULT_PORT,
                   help=f"本地端口(默认 {server.DEFAULT_PORT})")
    p.add_argument("--no-browser", action="store_true",
                   help="启动后不自动打开浏览器")
    args = p.parse_args()

    # 单实例:软件已在跑 → 直接打开窗口,不重复启动
    if not args.no_browser and _already_running(args.port):
        server._open_app_window(f"http://127.0.0.1:{args.port}")
        return

    # 启动本地翻译服务(后台运行,失败不影响主功能)
    _start_translate_server()

    server.run_server(port=args.port, open_browser=not args.no_browser)


# 全局变量:记录子进程,退出时统一关闭
_child_processes = []


def _start_translate_server():
    """启动本地翻译服务(后台运行,失败不影响主功能)。"""
    try:
        import subprocess
        ts = os.path.join(ROOT, "translate_server.py")
        translate_py = os.path.join(ROOT, "python-translate", "python.exe")
        if not os.path.exists(translate_py):
            translate_py = sys.executable  # 降级用主Python
        if os.path.exists(ts):
            log_file = os.path.join(ROOT, "data", "translate.log")
            os.makedirs(os.path.dirname(log_file), exist_ok=True)
            # 不用with open,否则文件句柄会被关闭导致子进程崩溃
            log_f = open(log_file, "w", encoding="utf-8")
            proc = subprocess.Popen(
                [translate_py, ts, "--port", "8766"],
                cwd=ROOT,
                creationflags=0x08000000,  # CREATE_NO_WINDOW
                stdout=log_f,
                stderr=subprocess.STDOUT
            )
            _child_processes.append(proc)
            print("[translate] 翻译服务已启动,日志:", log_file)
    except Exception as e:
        print("[translate] 翻译服务启动失败(不影响主功能):", e)


def shutdown_all():
    """关闭所有子进程,然后退出。供/api/exit调用。"""
    print("[shutdown] 正在关闭所有子进程...")
    for proc in _child_processes:
        try:
            if proc.poll() is None:  # 还在运行
                proc.terminate()
                proc.wait(timeout=3)
                print("[shutdown] 已关闭子进程 PID:", proc.pid)
        except Exception as e:
            print("[shutdown] 关闭子进程失败:", e)
    # 给子进程一点时间退出
    time.sleep(0.5)
    print("[shutdown] 所有子进程已关闭,服务器退出")
    os._exit(0)


if __name__ == "__main__":
    main()
