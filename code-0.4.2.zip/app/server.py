# -*- coding: utf-8 -*-
"""本地 Web 服务:默认监听 127.0.0.1,开启老板模式后监听 0.0.0.0(局域网可访问)。

安全边界:
 - 默认只绑定本机回环地址,局域网/外网都访问不到;
 - 老板模式(boss_enabled=1)才监听 0.0.0.0,且老板API需要密钥验证;
 - 当前版本没有任何"发给客户"的通道 —— 所有接口只读、只写本地库、只生成建议。
"""
import json
import os
import re
import subprocess
import sys
import threading
import time
import webbrowser
from datetime import date, datetime, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

from . import ai, aiworker, brief, chatimport, classifier, db, docs, followcheck, notify, profile, profile_doc, rules, service
from . import translate
from . import log
from . import wa_official
from . import autoimport
from . import updater
from .version import APP_VERSION

# 老板模式:0.3.4起强制开启,局域网可访问老板API
# 固定老板密钥(所有PM统一,老板端用这个密钥访问)
BOSS_TOKEN = "Boss@2026CRM"
DEFAULT_PORT = int(os.environ.get("CRM_PORT", "8765"))
# 实际运行端口(run_server 会更新它)。桥接推送地址必须跟着它走 ——
# 否则开发者版(8768)的桥接会把消息推给正式版(8765)。
ACTIVE_PORT = DEFAULT_PORT
UI_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ui", "index.html")


def _bridge_env():
    """桥接进程的环境变量:APP_URL/侧口端口都跟随当前实例,并按设置决定是否走代理。"""
    env = dict(os.environ)
    env["APP_URL"] = "http://127.0.0.1:%d" % ACTIVE_PORT
    # 侧口 = 主口 + 2(正式 8765→8767,开发者 8768→8770)。
    # 两份目录各自独立,才不会“开发者版点重新扫码把正式版桥接杀掉”。
    env["WA_SIDE_PORT"] = str(ACTIVE_PORT + 2)
    px = (db.get_setting("bridge_proxy", "") or "").strip()
    if px and px.lower() not in ("direct", "none", "off"):
        env["WA_PROXY"] = px
    else:
        env.pop("WA_PROXY", None)     # 没配代理 → 直连(VPN);keepalive 末了会再看系统代理
    return env


def _no_window():
    """子进程一律不弹控制台窗口(主程序是 pythonw,不设就会闪黑窗)。"""
    return {"creationflags": 0x08000000} if os.name == "nt" else {}


def _detached():
    """后台常驻子进程(不继承句柄)。"""
    return ({"creationflags": 0x00000008} if os.name == "nt"
            else {"start_new_session": True})


def _bridge_dir():
    return os.path.join(db.PROJECT_DIR, "bridge")


def _bridge_status():
    """读桥接自己写的 status.json(没有就返回空)。"""
    sf = os.path.join(_bridge_dir(), "status.json")
    try:
        with open(sf, encoding="utf-8") as f:
            return json.load(f) or {}
    except Exception:
        return {}


def _bridge_paired():
    """是否已配对(有 auth/creds.json)。未配对时只能靠人工扫码,绝不自动连。"""
    return os.path.exists(os.path.join(_bridge_dir(), "auth", "creds.json"))


def _boot_bridge_allowed():
    """开机是否允许自动连一次。

    【根因修法 2026-11-03 · 白名单】不再用"哪些停手原因不许自启"的黑名单
    —— 黑名单每新增一种死因就要补一条,漏一条就会误自启(治标不治本)。
    改成:只有"上次没有任何停手原因"(stopped 为空)才允许自启。
      · 正常关机 / 意外退出:状态里 stopped 都是空 → 允许自启一次(补收关机期间消息);
      · 任何主动停手(logged-out/403/440/411、machine-locked、以后新增的任何原因)
        都会写 stopped → 一律不自启,等人工点【拉起桥接】。
    这样未知死因天然 fail-safe,也绝不会在"本机已另有一份桥接"时自启第二条。
    """
    if not _bridge_paired():
        return False, "未配对,等人工扫码"
    why = str(_bridge_status().get("stopped") or "")
    if why:
        return False, "上次停手(%s),等人工点【拉起桥接】" % why
    return True, ""


def _boss_enabled():
    """老板模式强制开启(0.3.4+)。"""
    return True


def _boss_token():
    """老板密钥(固定)。"""
    return BOSS_TOKEN


def _get_host():
    """老板模式强制监听 0.0.0.0(局域网可访问)。"""
    return "0.0.0.0"


def _get_local_ip():
    """获取本机局域网IP地址。"""
    import socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        try:
            return socket.gethostbyname(socket.gethostname())
        except Exception:
            return "127.0.0.1"


def _bridge_side_alive(timeout=1):
    """桥接的本地小接口(主口+2)是否响应 —— 判断桥接进程是否真的活着。"""
    import socket
    try:
        with socket.create_connection(("127.0.0.1", ACTIVE_PORT + 2), timeout=timeout):
            return True
    except Exception:
        return False


def _bridge_side_post(path, timeout=5):
    """调用桥接侧口(只监听 127.0.0.1)。失败返回 None。"""
    try:
        import urllib.request
        url = "http://127.0.0.1:%d%s" % (ACTIVE_PORT + 2, path)
        req = urllib.request.Request(url, data=b"{}", method="POST",
                                     headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8") or "{}")
    except Exception as e:
        log.swallow("server.side_post", e)
        return None


def _bridge_side_get(path, timeout=5):
    """GET 桥接侧口(只监听 127.0.0.1)。失败返回 None。"""
    try:
        import urllib.request
        url = "http://127.0.0.1:%d%s" % (ACTIVE_PORT + 2, path)
        with urllib.request.urlopen(url, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8") or "{}")
    except Exception as e:
        log.swallow("server.side_get", e)
        return None


# 【拉起闸门】开机线程 / 界面按钮 / 重新扫码 三个入口都可能同时 Popen。
# 同一 15 秒窗口内只允许一个拉起动作,其余直接返回"正在启动",避免起两份桥接。
_SPAWN = {"until": 0.0}


def _spawn_allowed():
    now = time.time()
    if now < _SPAWN["until"]:
        return False
    _SPAWN["until"] = now + 15
    return True


def _json(obj):
    return json.dumps(obj, ensure_ascii=False).encode("utf-8")


# WhatsApp 标签名 → 客户分级(A/B/C)。只认明确的写法,不做臆测。
_GRADE_KEYS = [("A", ("a级", "a类", "a 级", "重点", "vip")),
               ("B", ("b级", "b类", "b 级", "次重点")),
               ("C", ("c级", "c类", "c 级", "普通"))]


def _grade_from_labels(names):
    """从标签名字里读出分级:名字是 A/B/C(或 A级/B级/C级、含“重点”等)才算。"""
    clean = [(n or "").strip() for n in names if (n or "").strip()]
    for g, keys in _GRADE_KEYS:
        for n in clean:
            low = n.lower()
            if n.upper() == g or low in keys or any(k in low for k in keys):
                return g
    return ""


def _route_parts(path):
    return [p for p in path.split("?")[0].split("/") if p]


class Api(BaseHTTPRequestHandler):
    server_version = "CustomerDesk/0.1"

    # ---- 基础工具 ----

    def log_message(self, *args):
        pass  # 安静运行,不刷日志

    def _send(self, code, body, ctype="application/json; charset=utf-8"):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        # CORS:允许老板监管台等本地网页跨域访问
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, X-Boss-Token, Authorization")
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        """处理CORS预检请求。"""
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, X-Boss-Token, Authorization")
        self.send_header("Access-Control-Max-Age", "86400")
        self.end_headers()

    def _ok(self, obj, code=200):
        self._send(code, _json(obj))

    def _err(self, msg, code=400):
        self._send(code, _json({"error": msg}))

    def _body(self):
        length = int(self.headers.get("Content-Length") or 0)
        if length <= 0:
            return {}
        try:
            return json.loads(self.rfile.read(length).decode("utf-8"))
        except Exception:
            return {}

    def _raw_body(self):
        """原始字节 —— 校验 Meta 签名必须用原始 body(不能先 json 再序列化)。"""
        length = int(self.headers.get("Content-Length") or 0)
        if length <= 0:
            return b""
        return self.rfile.read(length)

    def _text(self, s, code=200):
        self._send(code, str(s).encode("utf-8"), "text/plain; charset=utf-8")

    def _query(self, name, default=None):
        q = self.path.split("?", 1)
        if len(q) < 2:
            return default
        m = re.search(r"(?:^|&)" + name + r"=([^&]*)", q[1])
        return m.group(1) if m else default

    # ---- 路由 ----

    def _handle(self, method):
        parts = _route_parts(self.path)
        try:
            if not parts:
                return self._serve_ui()
            if parts[0] == "widget" and method == "GET":
                return self._serve_widget()
            if parts[0] == "panel" and method == "GET":
                return self._serve_panel()
            if parts[0] == "api":
                return self._route_api(method, parts[1:])
            if parts[0] == "index.html" and method == "GET":
                return self._serve_ui()
            # 静态文件(logo.png 等)
            if method == "GET":
                return self._serve_static("/".join(parts))
            return self._err("not found", 404)
        except BrokenPipeError:
            pass
        except Exception as exc:  # 兜底:任何内部错误都以 JSON 返回,不让界面白屏
            try:
                self._err(f"server error: {exc}", 500)
            except Exception as e:
                log.swallow("server.py:108", e)

    def _serve_ui(self):
        try:
            with open(UI_FILE, "rb") as f:
                self._send(200, f.read(), "text/html; charset=utf-8")
        except FileNotFoundError:
            self._err("ui/index.html missing", 500)

    def _serve_widget(self):
        wf = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ui", "widget.html")
        try:
            with open(wf, "rb") as f:
                self._send(200, f.read(), "text/html; charset=utf-8")
        except FileNotFoundError:
            self._err("ui/widget.html missing", 500)

    def _serve_panel(self):
        pf = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ui", "panel.html")
        try:
            with open(pf, "rb") as f:
                self._send(200, f.read(), "text/html; charset=utf-8")
        except FileNotFoundError:
            self._err("ui/panel.html missing", 500)

    def _serve_static(self, rel):
        import mimetypes
        ui_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ui")
        fp = os.path.join(ui_dir, rel)
        # 防止路径穿越
        if not os.path.realpath(fp).startswith(os.path.realpath(ui_dir)):
            return self._err("not found", 404)
        try:
            with open(fp, "rb") as f:
                data = f.read()
            ctype = mimetypes.guess_type(fp)[0] or "application/octet-stream"
            self._send(200, data, ctype)
        except FileNotFoundError:
            self._err("not found", 404)

    def _route_api(self, method, p):
        # ---- 退出:关闭所有子进程后退出 ----
        if p and p[0] == "exit" and method == "GET":
            try:
                import main as main_mod
                if hasattr(main_mod, "shutdown_all"):
                    # 先返回OK,然后在后台线程中关闭(避免请求未完成就退出)
                    import threading
                    threading.Timer(0.3, main_mod.shutdown_all).start()
                    return self._ok({"exiting": True})
            except Exception as e:
                log.swallow("server.api_exit", e)
            return self._ok({"exiting": True})
        # ---- 客户 ----
        if p and p[0] == "customers" and len(p) == 1 and method == "GET":
            q = self._query("q", "") or ""
            return self._ok({"items": db.list_customers(q or None)})
        if p and p[0] == "customers" and len(p) == 1 and method == "POST":
            data = self._body()
            if not str(data.get("name", "")).strip():
                return self._err("客户姓名(name)不能为空")
            cid = db.create_customer(data)
            return self._ok({"customer": db.get_customer(cid)}, 201)
        if (p and p[0] == "customers" and len(p) == 2 and p[1] == "recompute"
                and method == "POST"):
            n = 0
            for c in db.list_customers():
                profile.enrich_customer(c["id"])
                n += 1
            return self._ok({"recomputed": n})
        if p and p[0] == "customers" and len(p) == 2 and method == "GET":
            c = db.get_customer(int(p[1]))
            return self._ok({"customer": c}) if c else self._err("客户不存在", 404)
        if p and p[0] == "customers" and len(p) == 2 and method == "PUT":
            data = self._body()
            if data.get("move") in ("next", "prev"):
                stage = db.update_customer(int(p[1]), {}, move=data["move"])
                if stage is None:
                    return self._err("客户不存在", 404)
                return self._ok({"stage": stage})
            db.update_customer(int(p[1]), data)
            return self._ok({"customer": db.get_customer(int(p[1]))})
        if p and p[0] == "customers" and len(p) == 2 and method == "DELETE":
            db.delete_customer(int(p[1]))
            return self._ok({"deleted": True})
        # 客户消息
        if (p and p[0] == "customers" and len(p) == 3 and p[2] == "messages"
                and method == "GET"):
            q = parse_qs(urlparse(self.path).query)
            around = (q.get("around") or [""])[0].strip()
            try:
                cid = int(p[1])
            except (TypeError, ValueError):
                return self._err("客户不存在", 404)
            if around:
                try:
                    return self._ok({"items": db.list_messages(
                        customer_id=cid, around_id=int(around))})
                except (TypeError, ValueError):
                    pass
            return self._ok({"items": db.list_messages(customer_id=cid)})
        if (p and p[0] == "customers" and len(p) == 3 and p[2] == "messages"
                and method == "POST"):
            data = self._body()
            content = str(data.get("content", ""))
            if not content.strip():
                return self._err("消息内容不能为空")
            direction = "out" if str(data.get("direction", "in")) == "out" else "in"
            res = service.process_message(int(p[1]), direction, content,
                                          ts=data.get("ts"))
            if res is None:
                return self._err("客户不存在", 404)
            return self._ok(res, 201)
        # ---- 翻译接口(优先谷歌,失败用本地) ----
        if p == ["translate"] and method == "POST":
            data = self._body()
            text = str(data.get("text") or "").strip()
            target = str(data.get("target") or "zh")
            if not text:
                return self._err("内容为空")
            try:
                result = translate.translate_text(text, target)
                return self._ok({"original": text, "translated": result, "engine": "google"})
            except Exception as e:
                return self._err("翻译失败:" + str(e))
        # ---- 后台翻译进度 ----
        if p == ["translate-tasks"] and method == "GET":
            tasks = db.get_running_translation_tasks()
            return self._ok({"tasks": tasks})
        if (p and p[0] == "customers" and len(p) == 3 and p[2] == "rebuild"
                and method == "POST"):
            # 重建分析:改了词表/规则后,把该客户的聊天重新跑一遍
            # (标签、提醒建议、客户文档 都重算;重复的不会重复插入)
            try:
                cid = int(p[1])
            except (TypeError, ValueError):
                return self._err("客户不存在", 404)
            if not db.get_customer(cid):
                return self._err("客户不存在", 404)
            msgs = db.list_messages(customer_id=cid, limit=5000)
            tags_n = docs_n = rem_n = 0
            # 记录rebuild前该客户的提醒数量,用于计算真正新增的数量
            # (add_reminder有去重逻辑,返回已存在ID时不算新增)
            con_before = db.connect()
            try:
                rem_before = con_before.execute(
                    "SELECT COUNT(*) n FROM reminders WHERE customer_id=?", (cid,)).fetchone()["n"]
            finally:
                con_before.close()
            # 导入分析时间窗口:只对窗口内的消息生成提醒/提取文档,窗口外的只更新标签
            try:
                window_days = int(db.get_setting("import_analyze_days", "7") or "7")
            except (TypeError, ValueError):
                window_days = 7
            cutoff = (datetime.now() - timedelta(days=window_days)).strftime("%Y-%m-%d %H:%M:%S")
            for m in msgs:
                a = rules.analyze(m["content"], m["direction"])
                db.update_message_tags(m["id"], a["tags"])
                tags_n += 1
                # 只有窗口内的消息才生成提醒和加入AI队列
                msg_ts = m.get("ts") or ""
                in_window = bool(msg_ts) and msg_ts >= cutoff
                if in_window and a["suggestion"]:
                    s = a["suggestion"]
                    db.add_reminder(cid, s["kind"], s["note"], days=s.get("days"),
                                    quote=s.get("quote", ""),
                                    src_ts=m.get("ts",""), src_direction=m.get("direction",""),
                                    src_msg_id=m["id"])
                # 代码层筛选高价值信息 → 加入AI队列,让AI后台分析
                # (AI会更准确地判断是否为待办,避免代码层误判/漏判)
                if in_window:
                    try:
                        from . import aiworker
                        should_enq, high_cats, low_cats = aiworker.should_enqueue(
                            m["content"], m["direction"], a)
                        if should_enq:
                            code_reason = ",".join(high_cats) if high_cats else "模糊地带"
                            db.enqueue_msg(m["id"], cid, code_reason=code_reason)
                    except Exception as e:
                        pass  # AI队列失败不影响导入
                # 只有窗口内的消息才提取文档
                if in_window and db.get_setting("docs_auto", "1") == "1":
                    docs_n += docs.extract_code_to_db(cid, m["content"],
                                                      direction=m["direction"],
                                                      msg_id=m["id"])
            profile.enrich_customer(cid)
            # 计算真正新增的提醒数量(去重后的)
            con_after = db.connect()
            try:
                rem_after = con_after.execute(
                    "SELECT COUNT(*) n FROM reminders WHERE customer_id=?", (cid,)).fetchone()["n"]
            finally:
                con_after.close()
            rem_n = max(0, rem_after - rem_before)
            return self._ok({"rebuilt": len(msgs), "tagged": tags_n,
                             "doc_new": docs_n, "rem_new": rem_n,
                             "window_days": window_days})
        if (p and p[0] == "customers" and len(p) == 3 and p[2] == "profile"
                and method == "GET"):
            return self._ok({"profile": profile_doc.get(int(p[1])),
                             "sections": profile_doc.section_titles(),
                             "ai": {"enabled": ai.enabled(),
                                    "usage": ai.usage()}})
        if (p and p[0] == "customers" and len(p) == 4 and p[2] == "profile"
                and p[3] == "section" and method == "PUT"):
            # 人工修改某一节(text 为空 => 还原原稿)
            data = self._body()
            key = str(data.get("key") or "").strip()
            if not key:
                return self._err("缺少 key")
            try:
                cid = int(p[1])
            except (TypeError, ValueError):
                return self._err("客户不存在", 404)
            if data.get("revert"):
                return self._ok(profile_doc.revert_section(cid, key))
            return self._ok(profile_doc.edit_section(cid, key,
                                                     str(data.get("text") or "")))
        if (p and p[0] == "customers" and len(p) == 3 and p[2] == "profile"
                and method == "POST"):
            try:
                cid = int(p[1])
            except (TypeError, ValueError):
                return self._err("客户不存在", 404)
            if not db.get_customer(cid):
                return self._err("客户不存在", 404)
            return self._ok(profile_doc.generate(cid))
        if (p and p[0] == "customers" and len(p) == 3 and p[2] == "brief"
                and method == "GET"):
            b = brief.get(int(p[1]))
            return self._ok({"brief": b,
                             "sections": brief.SECTIONS,
                             "ai": {"enabled": ai.enabled(),
                                    "usage": ai.usage()}})
        if (p and p[0] == "customers" and len(p) == 3 and p[2] == "brief"
                and method == "POST"):
            try:
                cid = int(p[1])
            except (TypeError, ValueError):
                return self._err("客户不存在", 404)
            if not db.get_customer(cid):
                return self._err("客户不存在", 404)
            return self._ok(brief.generate(cid))
        if (p and p[0] == "customers" and len(p) == 3 and p[2] == "enrich"
                and method == "POST"):
            updated = profile.enrich_customer(int(p[1]))
            return self._ok({"customer": updated}) if updated else self._err("客户不存在", 404)
        if (p and p[0] == "customers" and len(p) == 3 and p[2] == "ai"
                and method == "POST"):
            return self._ok(ai.process_customer(int(p[1])))
        # ---- 客户文档(从对话提炼的高价值信息) ----
        if p and p[0] == "docs" and len(p) == 1 and method == "GET":
            try:
                cid = int(self._query("customer_id", "0") or 0)
            except (TypeError, ValueError):
                cid = 0
            cat = self._query("category", "") or None
            return self._ok({"items": db.list_docs(customer_id=cid or None,
                                                   category=cat),
                             "categories": db.DOC_CATEGORIES,
                             "counts": db.doc_counts()})
        if p and p[0] == "docs" and len(p) == 1 and method == "POST":
            data = self._body()
            try:
                cid = int(data.get("customer_id") or 0)
            except (TypeError, ValueError):
                cid = 0
            if not db.get_customer(cid):
                return self._err("请选择客户")
            title = str(data.get("title") or "").strip()
            if not title:
                return self._err("标题不能为空")
            did = db.add_doc(cid, str(data.get("category") or ""), title,
                             str(data.get("content") or ""),
                             quote=str(data.get("quote") or ""),
                             source="manual", dedupe=False)
            return self._ok({"doc": db.get_doc(did)}, 201)
        if p and p[0] == "docs" and len(p) == 2 and method == "GET":
            d = db.get_doc(int(p[1]))
            return self._ok({"doc": d}) if d else self._err("文档不存在", 404)
        if p and p[0] == "docs" and len(p) == 2 and method == "PUT":
            d = db.update_doc(int(p[1]), self._body())
            return self._ok({"doc": d}) if d else self._err("文档不存在", 404)
        if p and p[0] == "docs" and len(p) == 2 and method == "DELETE":
            db.delete_doc(int(p[1]))
            return self._ok({"deleted": True})
        if (p and p[0] == "customers" and len(p) == 4 and p[2] == "docs"
                and p[3] == "extract" and method == "POST"):
            try:
                cid = int(p[1])
            except (TypeError, ValueError):
                return self._err("客户不存在", 404)
            res = docs.extract_ai(cid)
            return self._ok({"result": res, "docs": db.list_docs(customer_id=cid)})
        # ---- AI 处理日志(半月导出给 William 固化) ----
        if p and p[0] == "ai-log" and len(p) == 1 and method == "GET":
            return self._ok({"items": db.list_ai_log(), "usage": ai.usage()})
        if (p and p[0] == "ai-log" and len(p) == 2 and p[1] == "export"
                and method == "GET"):
            items = db.list_ai_log()
            export = {
                "app": "外贸客户工作台",
                "exported_at": db.now_iso(),
                "count": len(items),
                "items": [{
                    "field": it["task"],
                    "field_cn": {"identity": "身份", "followup": "跟进分类",
                                 "grade": "分级", "batch": "批次"}.get(it["task"], it["task"]),
                    "customer": it.get("customer_name") or "",
                    "status": it.get("status") or "",
                    "result": it.get("result") or "",
                    "quote": it.get("quote") or "",
                    "detail": it.get("detail") or "",
                    "at": it.get("created_at") or "",
                } for it in items],
            }
            return self._ok(export)
        if p and p[0] == "followup" and len(p) == 2 and p[1] == "today" \
                and method == "GET":
            items = profile.today_followups()
            return self._ok({"items": items, "today": db.today_iso()})
        # ---- 看板总览 ----
        if p and p[0] == "overview" and method == "GET":
            customers = db.list_customers()
            stages = [{"stage": s, "count": 0, "customers": []}
                      for s in db.STAGES]
            idx = {s["stage"]: i for i, s in enumerate(stages)}
            for c in customers:
                key = c["stage"] if c["stage"] in idx else db.STAGES[0]
                stages[idx[key]]["count"] += 1
                stages[idx[key]]["customers"].append({
                    "id": c["id"], "name": c["name"], "company": c["company"],
                    "country": c["country"], "product": c["product"],
                    "grade": c["grade"], "msg_count": c.get("msg_count"),
                    "doc_count": c.get("doc_count"),
                    "last_ts": c["last_ts"],
                    "timezone": c.get("timezone") or "",
                    "last_contact_at": c.get("last_contact_at") or "",
                    "next_followup_at": c.get("next_followup_at") or "",
                    "followup_category": c.get("followup_category") or "",
                })
            return self._ok({"stages": stages,
                             "totals": {"customers": len(customers)}})
        # ---- 桌面浮窗(Z宝)摘要:一个请求喂满整个浮窗 ----
        if p and p[0] == "panel" and len(p) == 2 and p[1] == "summary" \
                and method == "GET":
            today = date.today()
            due = []
            for r in db.list_reminders(status=db.R_APPROVED):
                nd = (r.get("notify_date") or "")[:10]
                if not nd:
                    continue
                try:
                    dl = (date.fromisoformat(nd) - today).days
                except ValueError:
                    continue
                if dl > 0:
                    continue
                due.append({
                    "id": r.get("id"),
                    "customer_id": r.get("customer_id"),
                    "name": r.get("customer_name") or "客户",
                    "grade": r.get("grade") or "未分级",
                    "note": r.get("note") or "",
                    "days_left": dl,
                    "left_text": ("已到点 %d 天" % abs(dl)) if dl < 0 else "今天到点",
                })
            pri = {"A": 0, "B": 1, "C": 2}
            due.sort(key=lambda x: (pri.get(x["grade"], 3), x["days_left"]))
            try:
                suggested = db.list_reminders(status=db.R_SUGGESTED)
            except Exception:
                suggested = []
            try:
                fu = profile.today_followups()
            except Exception:
                fu = []
            pend = [x for x in fu if not x.get("done")]
            custs = db.list_customers()
            return self._ok({
                "today": today.isoformat(),
                "counts": {"due": len(due), "approve": len(suggested),
                           "follow": len(pend), "customers": len(custs)},
                "due": due[:20],
            })
        # ---- 消息重新识别(改词表后重跑) ----
        if (p and p[0] == "messages" and len(p) == 3 and p[2] == "reanalyze"
                and method == "POST"):
            m = db.get_message(int(p[1]))
            if not m:
                return self._err("消息不存在", 404)
            analysis = rules.analyze(m["content"], m["direction"])
            db.update_message_tags(int(p[1]), analysis["tags"])
            return self._ok({"message": db.get_message(int(p[1])),
                             "tags": analysis["tags"], "hits": analysis["hits"]})
        # ---- 提醒 ----
        if p and p[0] == "ai" and len(p) == 2 and p[1] == "queue" and method == "GET":
            return self._ok(aiworker.stats())
        if p and p[0] == "followcheck" and len(p) == 1 and method == "GET":
            return self._ok(followcheck.stats())
        if p and p[0] == "reminders" and len(p) == 2 and p[1] == "history" and method == "GET":
            return self._ok({"items": db.list_reminder_log(limit=60)})
        # 延时一天(只能一次,留痕“已延时一次”)
        if (p and p[0] == "reminders" and len(p) == 3 and p[2] == "delay"
                and method == "POST"):
            ok, nd, note, msg = db.delay_reminder_once(int(p[1]))
            if not ok:
                return self._err(msg, 400)
            return self._ok({"id": int(p[1]), "notify_date": nd, "note": note})
        # 推荐里没有提醒 id 的行(节奏推荐)也能点“已处理”——按客户推进下次跟进
        if (p and p[0] == "followups" and len(p) == 2 and p[1] == "done"
                and method == "POST"):
            data = self._body()
            cid = int(data.get("customer_id") or 0)
            c = db.get_customer(cid)
            if not c:
                return self._err("客户不存在", 404)
            cad = db.grade_cadence(c.get("grade") or "未分级") or 3
            nxt = (date.today() + timedelta(days=int(cad))).isoformat()
            db.update_customer(cid, {"next_followup_at": nxt})
            return self._ok({"customer_id": cid, "next_followup_at": nxt})
        if (p and p[0] == "reminders" and len(p) == 3 and p[2] == "revert"
                and method == "POST"):
            try:
                rid = int(p[1])
            except (TypeError, ValueError):
                return self._err("提醒不存在", 404)
            return self._ok(db.revert_reminder(rid))
        if (p and p[0] == "reminders" and len(p) == 2 and p[1] == "cleanup"
                and method == "POST"):
            data = self._body()
            if str(data.get("confirm") or "") != "YES":
                return self._err("需确认(confirm=YES)")
            n = db.clear_reminders()
            return self._ok({"cleared": n})
        # 垃圾桶:获取列表
        if (p and p[0] == "reminders" and len(p) == 2 and p[1] == "trash"
                and method == "GET"):
            return self._ok({"items": db.get_trash_reminders()})
        # 垃圾桶:软删除单条
        if (p and p[0] == "reminders" and len(p) == 3 and p[2] == "trash"
                and method == "POST"):
            try:
                rid = int(p[1])
            except (TypeError, ValueError):
                return self._err("提醒不存在", 404)
            return self._ok({"reminder": db.soft_delete_reminder(rid)})
        # 垃圾桶:撤回
        if (p and p[0] == "reminders" and len(p) == 3 and p[2] == "restore"
                and method == "POST"):
            try:
                rid = int(p[1])
            except (TypeError, ValueError):
                return self._err("提醒不存在", 404)
            return self._ok({"reminder": db.restore_reminder(rid)})
        if (p and p[0] == "reminders" and len(p) == 2 and p[1] == "check-replies"
                and method == "POST"):
            # 手动触发第 1 层:扫描所有待跟进,看我方是否已回复(纯代码,瞬间)
            checked, found = followcheck.code_scan()
            return self._ok({"checked": checked, "found": found,
                             "stats": followcheck.stats()})
        if (p and p[0] == "reminders" and len(p) == 3 and p[2] == "reply"
                and method == "POST"):
            # PM 对“疑似已回复”表态:confirm=确认完成 / keep=还没答,继续跟
            data = self._body()
            action = str(data.get("action") or "")
            try:
                rid = int(p[1])
            except (TypeError, ValueError):
                return self._err("提醒不存在", 404)
            if action == "confirm":
                # 【坑】这里以前调 db.decide_reminder —— 这个函数根本不存在,后端直接报错,
                # 所以“确认完成”点了没反应(也能提前点:不等它到点)。
                rem = db.get_reminder(rid) or {}
                db.set_reminder_status(rid, db.R_DONE)
                try:
                    db.log_reminder(rid, rem.get("customer_id"), "确认完成",
                                    note="手动确认(可提前)")
                except Exception as e:
                    log.swallow("server.py:434", e)
                return self._ok({"done": True})
            db.set_reminder_reply(rid, "not_answered", "", "")
            return self._ok({"kept": True})
        if (p and p[0] == "reminders" and len(p) == 2 and p[1] == "translate"
                and method == "POST"):
            # 把待批建议里的原话批量翻成中文(本地模型,一次调完)
            rows = db.list_reminders(status=db.R_SUGGESTED)
            pairs = {}
            for r in rows:
                q = (r.get("quote") or "").strip()
                if q and not (r.get("quote_zh") or "").strip():
                    pairs[str(r["id"])] = q[:400]
            if not pairs:
                return self._ok({"translated": 0})
            if not ai.enabled():
                return self._ok({"translated": 0, "detail": "AI 未开启"})
            zh = ai.translate_quotes(pairs)
            for rid, text in zh.items():
                try:
                    db.set_reminder_quote_zh(int(rid), text)
                except (TypeError, ValueError):
                    pass
            return self._ok({"translated": len(zh)})
        if p and p[0] == "reminders" and len(p) == 1 and method == "GET":
            status = self._query("status", "") or None
            # scope=today:今日推荐 = 待批准的建议 + **已到点还没处理的**跟进
            scope_today = (self._query("scope", "") == "today")
            items = db.list_reminders(status=None if scope_today else status)
            # 待批准的建议:自动算一个"建议日期",界面上直接预先填好(可改)
            lead = 1
            try:
                lead = max(1, int(db.get_setting("reminder_lead_default", "1") or 1))
            except ValueError:
                lead = 1
            today = date.today()
            for r in items:
                # 已批准:算“离承诺点还有几天” + 是否已到点(到点要置顶高亮)
                nd = (r.get("notify_date") or "")[:10]
                if nd:
                    try:
                        r["days_left"] = (date.fromisoformat(nd) - today).days
                    except ValueError:
                        r["days_left"] = None
                else:
                    r["days_left"] = None
                r["due"] = bool(r.get("status") == db.R_APPROVED
                                and r["days_left"] is not None
                                and r["days_left"] <= 0)
                if r.get("status") == db.R_APPROVED and r["days_left"] is not None:
                    dl = r["days_left"]
                    r["left_text"] = ("已到点(%d 天前)" % abs(dl) if dl < 0
                                      else ("今天到点" if dl == 0 else "还有 %d 天" % dl))
                else:
                    r["left_text"] = ""
                if r.get("status") == db.R_SUGGESTED or not nd:
                    if r.get("days") is not None:
                        r["suggested_date"] = (today + timedelta(
                            days=max(0, int(r["days"]) - lead))).isoformat()
                        r["date_hint"] = "承诺 %s 天内报价/跟进,提前 %s 天提醒" % (r["days"], lead)
                    else:
                        r["suggested_date"] = (today + timedelta(days=3)).isoformat()
                        r["date_hint"] = "原文没写天数,默认 3 天后(可改)"
                # 卡片要显示“几天后 + 具体日期”
                if r.get("status") == db.R_SUGGESTED and r.get("suggested_date"):
                    try:
                        ahead = (date.fromisoformat(r["suggested_date"]) - today).days
                        r["days_ahead"] = ahead
                        r["ahead_text"] = ("今天" if ahead == 0
                                           else ("%d 天后" % ahead if ahead > 0
                                                 else "%d 天前" % abs(ahead)))
                    except ValueError:
                        pass
            # 今日推荐:**A 优先 → B → 未分级;C 级不推荐**。
            # 同级内先到点的排前面。C 只从“推荐”里拿掉;你已批准的承诺(C 级也罢)不动,
            # 因为那是你自己点过批准的,不能因为分级就消失。
            _cache = getattr(self, "_grade_by_customer", None)
            if _cache is None:
                _cache = {c["id"]: (c.get("grade") or "未分级") for c in db.list_customers()}
                self._grade_by_customer = _cache
            for r in items:
                r["grade"] = _cache.get(r.get("customer_id"), "未分级")
            if scope_today:
                # 今日推荐 = ①必须跟的承诺(待批准 + 已到点的) ②跟进节奏(太久没联系)。
                # 跟“待跟进”分开:待跟进是承诺的审批流,这里是“节奏推荐”,要严格但可含 ABC。
                rem_items = [r for r in items
                             if r.get("status") == db.R_SUGGESTED
                             or (r.get("status") == db.R_APPROVED
                                 and r.get("days_left") is not None
                                 and r["days_left"] <= 0)]
                have = {r.get("customer_id") for r in rem_items}
                rhythm = []
                for c in db.list_customers():
                    if c["id"] in have or int(c.get("msg_count") or 0) < 3:
                        continue
                    lc = (c.get("last_contact_at") or "")[:10]
                    if not lc:
                        continue
                    try:
                        gap = (today - date.fromisoformat(lc)).days
                    except ValueError:
                        continue
                    if gap < 7:          # 严格:少于 7 天没联系不进推荐
                        continue
                    # 依据必须是**客户最后一句原话** —— 不能拿我方/运营的消息当证据
                    _con = db.connect()
                    _lm = _con.execute(
                        "SELECT content, ts FROM messages WHERE customer_id=? AND direction='in' "
                        "ORDER BY ts DESC LIMIT 1", (c["id"],)).fetchone()
                    _con.close()
                    rhythm.append({"id": None, "customer_id": c["id"], "kind": "跟进节奏",
                                   "note": "已经 %d 天没联系" % gap, "status": db.R_SUGGESTED,
                                   "grade": c.get("grade") or "未分级", "days_left": None,
                                   "due": False, "left_text": "", "days_ahead": 0,
                                   "ahead_text": "今天", "suggested_date": today.isoformat(),
                                   "quote": (_lm["content"][:90] if _lm else ""),
                                   "quote_ts": (_lm["ts"] if _lm else ""), "quote_zh": ""})
                rhythm.sort(key=lambda x: int(x["note"].split()[1]), reverse=True)
                items = rem_items + rhythm
            # 排序:A → B → C → 未分级;同级内已到点优先,再按临近天数
            _pri = {"A": 0, "B": 1, "C": 2, "未分级": 3, "": 3}
            items.sort(key=lambda r: (_pri.get(r["grade"], 3),
                                      0 if r.get("due") else 1,
                                      r.get("days_left") if r.get("days_left") is not None else 99))
            if scope_today:
                # 每天最多 15 条(可在设置里改):推荐要“严格”,不是把客户全铺开
                try:
                    cap = int(db.get_setting("rec_daily_max", "15") or 15)
                except ValueError:
                    cap = 15
                items = items[:max(1, cap)]
            return self._ok({"items": items, "today": today.isoformat()})
        if p and p[0] == "reminders" and len(p) == 1 and method == "POST":
            data = self._body()
            try:
                cid = int(data.get("customer_id") or 0)
            except (TypeError, ValueError):
                cid = 0
            if not db.get_customer(cid):
                return self._err("请选择客户")
            kind = str(data.get("kind") or "跟进")
            note = str(data.get("note") or "")
            notify_date = data.get("notify_date") or None
            rid = service.create_manual_reminder(cid, kind, note, notify_date)
            if rid is None:
                return self._err("手动提醒必须填提醒日期")
            return self._ok({"reminder": db.get_reminder(rid)}, 201)
        if p and p[0] == "reminders" and len(p) == 3 and p[1] == "decide":
            body = self._body()
            action = body.get("action")
            rid = int(p[2])
            if action == "approve":
                updated = service.approve_reminder(rid,
                                                   body.get("notify_date"))
                if updated is None:
                    return self._err("承诺类请直接批准;行程/无天数类必须先填提醒日期")
                return self._ok({"reminder": updated})
            if action == "cancel":
                # "不用"审批:移到垃圾桶(可撤回),而不是直接取消
                return self._ok({"reminder": db.soft_delete_reminder(rid)})
            return self._err("action 只支持 approve/cancel")
        if p and p[0] == "reminders" and len(p) == 3 and p[2] == "manual-done" \
                and method == "POST":
            # PM 手动选定一条聊天记录作为"处理依据",并留痕(不靠 AI 自动判)
            # action: "reply"=标记为已回复(保持待跟进), "done"=标记为已处理
            b = self._body()
            try:
                rid = int(p[1])
                mid = int(b.get("message_id") or 0)
                action = (b.get("action") or "done").strip().lower()
                if action not in ("reply", "done"):
                    action = "done"
            except (TypeError, ValueError):
                return self._err("参数错误", 400)
            rem = db.get_reminder(rid)
            if not rem:
                return self._err("提醒不存在", 404)
            m = db.get_message(mid)
            if not m:
                return self._err("消息不存在", 404)
            if m.get("customer_id") != rem.get("customer_id"):
                return self._err("这条消息不属于该客户", 400)
            # 消息方向校验:只能选我方发出的消息(direction=out),不能选客户的消息
            if m.get("direction") != "out":
                return self._err("请选择我方回复的消息(不能选客户的消息)", 400)
            who = (m.get("sender_name") or "").strip() or "我方"
            db.set_reminder_reply(rid, "replied", mid, m.get("content") or "",
                                  "PM 手动选定聊天记录作为处理依据",
                                  reply_by=who, reply_role="pm")
            con = db.connect()
            if action == "reply":
                # 标记为已回复:status保持approved(待跟进),reply_state=replied
                # 清除skip_auto,让AI可以判断是否需要生成新承诺
                con.execute("UPDATE reminders SET decided_by='human', decided_at=?,"
                            " skip_auto=0 WHERE id=?", (db.now_iso(), rid))
                new_status = db.R_APPROVED
            else:
                # 标记为已处理:status=done
                con.execute("UPDATE reminders SET decided_by='human', status=?, decided_at=?"
                            " WHERE id=?", (db.R_DONE, db.now_iso(), rid))
                new_status = db.R_DONE
            con.commit(); con.close()
            try:
                # 记 prev_status → 撤回时才能找到历史
                db.log_reminder(rid, rem.get("customer_id"),
                                "确认处理(手动选定依据,%s)" % ("已回复" if action == "reply" else "已处理"),
                                (rem.get("status") or ""), new_status,
                                "依据消息 #%s" % mid)
            except Exception as e:
                log.swallow("server.manual_done_log", e)
            # 标记为"已回复"后,后台异步触发AI判断是否需要生成新的承诺待跟进
            # 不阻塞请求,避免AI队列忙时点击没反应
            if action == "reply":
                try:
                    import threading
                    from . import followcheck
                    threading.Thread(target=followcheck.ai_check_reply_adequate,
                                     args=(rid, mid), daemon=True).start()
                except Exception as e:
                    log.swallow("server.manual_reply_ai_check", e)
            return self._ok({"done": action == "done", "replied": action == "reply",
                             "message_id": mid})
        if p and p[0] == "reminders" and len(p) == 3 and p[2] == "done" \
                and method == "POST":
            return self._ok({"reminder": service.mark_done(int(p[1]))})
        if p and p[0] == "reminders" and len(p) == 3 and p[2] == "date" \
                and method == "POST":
            body = self._body()
            nd = body.get("notify_date")
            r = db.get_reminder(int(p[1]))
            if not r:
                return self._err("提醒不存在", 404)
            if not nd:
                return self._err("请填日期")
            return self._ok({"reminder": db.set_reminder_status(
                int(p[1]), db.R_APPROVED, nd)})
        if p and p[0] == "reminders" and len(p) == 2 and method == "DELETE":
            db.delete_reminder(int(p[1]))
            return self._ok({"deleted": True})
        if p and p[0] == "reminders" and len(p) == 2 and p[1] == "due" \
                and method == "GET":
            return self._ok({"items": db.due_reminders()})
        # ---- 日报总结 ----
        if p and p[0] == "daily-report" and len(p) == 1 and method == "GET":
            return self._ok({"items": db.list_daily_reports()})
        if p and p[0] == "daily-report" and len(p) == 2 and method == "GET":
            report = db.get_daily_report(p[1])
            return self._ok({"item": report}) if report else self._err("日报不存在", 404)
        if p and p[0] == "daily-report" and len(p) == 2 and p[1] == "generate" \
                and method == "POST":
            data = self._body()
            report_date = str(data.get("date") or date.today().isoformat())
            try:
                generate_daily_report(report_date)
                report = db.get_daily_report(report_date)
                return self._ok({"item": report, "status": "generated"})
            except Exception as e:
                return self._err("生成失败: %s" % str(e))
        if p and p[0] == "daily-report" and len(p) == 2 and p[1] == "stats" \
                and method == "GET":
            report_date = self._query("date", date.today().isoformat())
            return self._ok({"stats": db.get_daily_stats(report_date)})
        # ---- 知识库 ----
        if p and p[0] == "kb" and len(p) == 1 and method == "GET":
            category = self._query("category", "") or None
            return self._ok({"items": db.list_kb(category=category),
                             "categories": db.KB_CATEGORIES})
        if p and p[0] == "kb" and len(p) == 1 and method == "POST":
            data = self._body()
            title = str(data.get("title") or "").strip()
            if not title:
                return self._err("标题不能为空")
            kid = db.add_kb(str(data.get("category") or db.KB_CATEGORIES[0]),
                            title, str(data.get("content") or ""),
                            str(data.get("tags") or ""),
                            str(data.get("source") or ""))
            return self._ok({"item": db.get_kb(kid)}, 201)
        if p and p[0] == "kb" and len(p) == 2 and method == "GET":
            item = db.get_kb(int(p[1]))
            return self._ok({"item": item}) if item else self._err("条目不存在", 404)
        if p and p[0] == "kb" and len(p) == 2 and method == "PUT":
            updated = db.update_kb(int(p[1]), self._body())
            return self._ok({"item": updated}) if updated else self._err("条目不存在", 404)
        if p and p[0] == "kb" and len(p) == 2 and method == "DELETE":
            db.delete_kb(int(p[1]))
            return self._ok({"deleted": True})
        # ---- 产品目录(结构化) ----
        if p and p[0] == "catalog" and len(p) == 1 and method == "GET":
            department = self._query("department", "") or None
            return self._ok({"items": db.list_catalog(department=department)})
        if p and p[0] == "catalog" and len(p) == 1 and method == "POST":
            data = self._body()
            if not str(data.get("department") or "").strip():
                return self._err("部门不能为空")
            cid = db.add_catalog(data)
            return self._ok({"item": db.get_catalog(cid)}, 201)
        if p and p[0] == "catalog" and len(p) == 2 and method == "GET":
            item = db.get_catalog(int(p[1]))
            return self._ok({"item": item}) if item else self._err("条目不存在", 404)
        if p and p[0] == "catalog" and len(p) == 2 and method == "PUT":
            updated = db.update_catalog(int(p[1]), self._body())
            return self._ok({"item": updated}) if updated else self._err("条目不存在", 404)
        if p and p[0] == "catalog" and len(p) == 2 and method == "DELETE":
            db.delete_catalog(int(p[1]))
            return self._ok({"deleted": True})
        # ---- 老客户导入:预览解析(不入库,返回客户信息供PM确认) ----
        if p == ["import-preview"] and method == "POST":
            import re as _re
            import zipfile as _zipfile
            import io as _io
            import base64 as _base64
            b = self._body()
            files = b.get("files") or []
            text = b.get("text") or ""
            all_text = text
            vcf_phones = []  # 从VCF文件提取的手机号
            for it in files[:50]:
                fname = str(it.get("name") or "")
                ftext = str(it.get("text") or "")
                fzip = it.get("zip_b64") or ""
                # 通过文件头判断是否是ZIP(不依赖扩展名),支持无扩展名的WhatsApp导出包
                is_zip = False
                zip_data = b""
                if fzip:
                    try:
                        zip_data = _base64.b64decode(fzip)
                        # ZIP文件头: PK\x03\x04 (50 4B 03 04)
                        if len(zip_data) >= 4 and zip_data[:4] == b"PK\x03\x04":
                            is_zip = True
                    except Exception:
                        pass
                if is_zip:
                    try:
                        zf = _zipfile.ZipFile(_io.BytesIO(zip_data))
                        # 只读取TXT文件(WhatsApp导出的聊天记录TXT最准确,不读MD)
                        txt_files = [n for n in zf.namelist()
                                     if n.lower().endswith(".txt")
                                     and not n.startswith("__MACOSX")]
                        for cf in txt_files:
                            try:
                                raw = zf.read(cf)
                                for enc in ("utf-8-sig", "utf-8", "utf-16", "gb18030", "latin-1"):
                                    try:
                                        all_text += "\n" + raw.decode(enc)
                                        break
                                    except (UnicodeDecodeError, UnicodeError):
                                        continue
                            except Exception:
                                pass
                        # 读取VCF文件提取手机号(WhatsApp导出的联系人名片)
                        vcf_phones = []
                        vcf_files = [n for n in zf.namelist()
                                     if n.lower().endswith(".vcf")
                                     and not n.startswith("__MACOSX")]
                        for cf in vcf_files:
                            try:
                                raw = zf.read(cf)
                                vcf_text = ""
                                for enc in ("utf-8-sig", "utf-8", "gb18030", "latin-1"):
                                    try:
                                        vcf_text = raw.decode(enc)
                                        break
                                    except (UnicodeDecodeError, UnicodeError):
                                        continue
                                # 解析VCF中的TEL字段,如 TEL;type=Home;waid=255787254707:+255 787 254 707
                                for line in vcf_text.splitlines():
                                    if line.upper().startswith("TEL"):
                                        tel_match = _re.search(r":\s*(\+?[\d\s\-]+)", line)
                                        if tel_match:
                                            digits = _re.sub(r"\D", "", tel_match.group(1))
                                            if len(digits) >= 8:
                                                vcf_phones.append("+" + digits if not tel_match.group(1).startswith("+") else tel_match.group(1).strip())
                            except Exception:
                                pass
                        zf.close()
                    except Exception:
                        all_text += "\n" + ftext
                else:
                    all_text += "\n" + ftext
            if not all_text.strip():
                return self._err("没有内容")
            parsed = chatimport.parse_chat(all_text)
            participants = parsed.get("participants", {})
            # 优先从文件名提取客户名和国家
            all_fnames = " ".join(str(it.get("name") or "") for it in files)
            from . import _nameparse
            name_from_file, country_from_file = _nameparse.parse_filename(all_fnames)
            # 聊天记录中的参与者(排除我方)
            cust_names = [k for k in participants if k.strip() not in ("你", "我", "me", "Me", "ME", "")]
            chat_peer = ""
            if cust_names:
                chat_peer = max(cust_names, key=lambda k: participants[k])
            # 客户名:文件名提取的 > 聊天记录中非纯号码的 > 最多发言的
            peer_name = name_from_file
            if not peer_name and chat_peer and not _re.match(r"^[\d\s\+\-]+$", chat_peer):
                peer_name = chat_peer
            if not peer_name:
                peer_name = chat_peer
            phone = ""
            # 优先从VCF文件提取手机号(WhatsApp导出的联系人名片)
            if vcf_phones:
                phone = vcf_phones[0]
            # 其次从参与者名字中提取
            if not phone:
                phone_re = _re.compile(r"\+?\d[\d\s\-]{7,}")
                for pname in participants:
                    if pname.strip() in ("你", "我", "me", "Me", "ME"): continue
                    pm = phone_re.search(pname)
                    if pm:
                        digits = _re.sub(r"\D", "", pm.group(0))
                        if len(digits) >= 8:
                            phone = "+" + digits
                            break
            # 最后从聊天内容中提取国际手机号(非+86开头的)
            if not phone:
                phone_re = _re.compile(r"\+\d[\d\s\-]{7,}")
                for m in parsed["messages"][:200]:  # 只看前200条,避免太慢
                    content = m.get("content", "")
                    for pm in phone_re.finditer(content):
                        digits = _re.sub(r"\D", "", pm.group(0))
                        if len(digits) >= 8 and not digits.startswith("86"):
                            phone = pm.group(0).strip()
                            break
                    if phone:
                        break
            country = country_from_file or ""
            country_map = {"+1":"美国/加拿大","+44":"英国","+61":"澳大利亚","+64":"新西兰","+81":"日本","+82":"韩国","+65":"新加坡","+60":"马来西亚","+66":"泰国","+84":"越南","+62":"印尼","+63":"菲律宾","+91":"印度","+92":"巴基斯坦","+880":"孟加拉","+971":"阿联酋","+966":"沙特","+974":"卡塔尔","+965":"科威特","+968":"阿曼","+973":"巴林","+20":"埃及","+27":"南非","+234":"尼日利亚","+254":"肯尼亚","+255":"坦桑尼亚","+256":"乌干达","+233":"加纳","+229":"贝宁","+225":"科特迪瓦","+237":"喀麦隆","+243":"刚果金","+212":"摩洛哥","+216":"突尼斯","+218":"利比亚","+249":"苏丹","+49":"德国","+33":"法国","+39":"意大利","+34":"西班牙","+31":"荷兰","+32":"比利时","+41":"瑞士","+46":"瑞典","+47":"挪威","+48":"波兰","+7":"俄罗斯","+55":"巴西","+52":"墨西哥","+54":"阿根廷","+56":"智利","+57":"哥伦比亚","+51":"秘鲁","+86":"中国"}
            if phone:
                for code, cname in sorted(country_map.items(), key=lambda x: -len(x[0])):
                    if phone.startswith(code):
                        country = cname
                        break
            timestamps = [m["ts"] for m in parsed["messages"] if m.get("ts")]
            time_start = min(timestamps) if timestamps else ""
            time_end = max(timestamps) if timestamps else ""
            # 统计in/out:用peer判断客户方向,而不是只判断"你/我"
            self_names = ("你", "我", "me", "Me", "ME", "You", "you", "")
            peer_lower = (peer_name or "").strip().lower()
            in_count = 0
            out_count = 0
            for m in parsed["messages"]:
                nm = m["name"].strip()
                if not nm:
                    continue
                if nm in self_names:
                    out_count += 1
                elif peer_lower and nm.lower() == peer_lower:
                    in_count += 1
                else:
                    # 其他参与者默认算我方(销售经理/团队)
                    out_count += 1
            return self._ok({
                "peer_name": peer_name, "phone": phone, "country": country,
                "message_count": len(parsed["messages"]),
                "in_count": in_count, "out_count": out_count,
                "time_start": time_start, "time_end": time_end,
                "has_ts": parsed.get("has_ts", False),
                "participants": participants, "text": all_text,
            })

        # ---- 历史聊天导入(界面/CLI 共用,保留时间戳) ----
        # ---- 一次性导入(多选文件):像“迁移备份”一样一次弄完,不靠反复拉历史 ----
        if p == ["import-files"] and method == "POST":
            b = self._body()
            files = b.get("files") or []
            if not isinstance(files, list) or not files:
                return self._err("没有文件")
            report = []
            for it in files[:200]:
                nm = str(it.get("name") or "导入.txt")
                txt = str(it.get("text") or "")
                try:
                    r = autoimport.import_text(nm, txt)
                except Exception as e:
                    log.swallow("server.import_files", e)
                    r = {"ok": False, "error": str(e), "file": nm}
                report.append(r)
            okr = [r for r in report if r.get("ok")]
            return self._ok({"files": len(report), "ok": len(okr),
                             "messages": sum(int(r.get("imported") or 0) for r in okr),
                             "customers": len({r.get("customer_id") for r in okr}),
                             "report": report})
        if p and p[0] == "import-chat" and len(p) == 1 and method == "POST":
            data = self._body()
            text = str(data.get("text") or "")
            if not text.strip():
                return self._err("聊天内容为空")
            cid = data.get("customer_id")
            phone = str(data.get("phone") or "").strip()
            peer_name = str(data.get("peer_name") or "").strip()
            new_name = str(data.get("new_name") or "").strip()
            matched_by = "given"
            if cid:
                cid = int(cid)
                if not db.get_customer(cid):
                    return self._err("客户不存在", 404)
            else:
                # 导入的 .txt 只有名字、没有号码 —— 所以按这个顺序找已有客户:
                #   ① 手机号(填了就最准) ② 名字完全一致 ③ 名字本身就是号码
                # 都不中才新建。否则会开出一堆重复档案,后续 WhatsApp 真号也对不上。
                cust = None
                if phone:
                    cust = db.find_customer_by_phone(phone)
                    matched_by = "phone"
                if not cust and peer_name:
                    cust = db.find_customer_by_phone(peer_name)   # 未存联系人时导出名就是号码
                    if cust:
                        matched_by = "peer_phone"
                if not cust:
                    nm = new_name or peer_name
                    if nm:
                        cust = db.find_customer_by_name(nm)
                        if cust:
                            matched_by = "name"
                if cust:
                    cid = cust["id"]
                    # 只在原来**没号码**时才补上;已有的国际格式比本地 0 开头更规范,不覆盖
                    if phone and not (cust.get("phone") or "").strip():
                        db.update_customer(cid, {"phone": phone})
                else:
                    cid = db.create_customer({"name": new_name or peer_name or phone or "导入客户",
                                              "phone": phone, "source": "导入"})
                    matched_by = "new"
            res = chatimport.import_chat(
                cid, text, peer_name=peer_name or None)
            cust_now = db.get_customer(cid) or {}
            return self._ok({"customer_id": cid, "matched_by": matched_by,
                             "customer": {"id": cid, "name": cust_now.get("name"),
                                          "phone": cust_now.get("phone")},
                             **res}, 201)
        # ---- 通知中心(软件内提醒) ----
        if p and p[0] == "notifications" and len(p) == 1 and method == "GET":
            unread_only = self._query("unread", "") in ("1", "true")
            return self._ok({"items": db.list_notifications(unread_only=unread_only),
                             "unread": db.unread_count()})
        if (p and p[0] == "notifications" and len(p) == 2 and p[1] == "read"
                and method == "POST"):
            body = self._body()
            db.mark_notifications_read(body.get("id"))
            return self._ok({"unread": db.unread_count()})
        if (p and p[0] == "notifications" and len(p) == 2 and p[1] == "scan"
                and method == "POST"):
            return self._ok({"created": notify.scan(), "unread": db.unread_count()})
        # ---- 外部收信桥接(WhatsApp 等推送进来;凭令牌鉴权) ----
        # ---- 桥接通道(B 方案:实时收信;已按防封号加固)----
        if p == ["bridge", "status"] and method == "GET":
            st = _bridge_status()
            bdir = _bridge_dir()
            st["reset_wait_s"] = 0        # 已取消冷却:随时可重新扫码
            st["deps_ready"] = os.path.isdir(
                os.path.join(bdir, "node_modules", "@whiskeysockets", "baileys"))
            alive = _bridge_side_alive()
            st["proc_alive"] = alive
            st["paired"] = _bridge_paired()
            # 【关键】“在线”= 状态文件说已连 + 进程真的活着。
            # 旧版只看 linked,进程被强杀后文件仍留着 linked:true → 界面长期假在线。
            linked = bool(st.get("linked"))
            st["online"] = bool(linked and alive)
            upd = str(st.get("updated") or "")
            age = -1
            try:
                # status.json 的 updated 是 UTC(bridge.js toISOString),这里也必须用 UTC 比较,
                # 否则东八区会凭空多出 8 小时,“在线”永远被判成 stale。
                age = int((datetime.utcnow() - datetime.strptime(
                    upd[:19], "%Y-%m-%dT%H:%M:%S")).total_seconds())
            except Exception:
                age = -1
            st["age_sec"] = age
            # 桥接每 60 秒写一次心跳;超过 180 秒没更新 = 进程还在但状态不再可信。
            st["stale"] = bool(age >= 0 and age > 180)
            if st["stale"] and st["online"]:
                st["online"] = False
                st["stale_online"] = True     # 文件说在线但 180 秒没更新 → 疑似假在线
            # 依赖安装最近几行日志(排查用)
            try:
                lg = os.path.join(bdir, "bridge.log")
                if os.path.exists(lg):
                    with open(lg, "r", encoding="utf-8", errors="replace") as f:
                        _dl = [x.strip() for x in f.read().splitlines() if "[deps]" in x]
                    st["deps_log"] = _dl[-3:]
            except Exception as e:
                log.swallow("server.bridge_deps_log", e)
            # 断开/停手 → 写一条软件内提醒(同一次停手只提醒一次,避免轮询刷屏)
            try:
                why = str(st.get("stopped") or "")
                if why and why != "awaiting-pair-request":
                    key = "bridge:%s:%s" % (why, upd or "-")
                    if not db.notification_exists(key):
                        db.add_notification(
                            key, "桥接断开",
                            "WhatsApp 收信桥接已停止: %s。请到【WhatsApp登陆】点【拉起桥接】。"
                            % (st.get("reason") or why))
            except Exception as e:
                log.swallow("server.bridge_notify", e)
            return self._ok(st)
        if p == ["bridge", "qr"] and method == "GET":
            qp = os.path.join(db.PROJECT_DIR, "bridge", "qr.png")
            try:
                with open(qp, "rb") as f:
                    return self._send(200, f.read(), "image/png")
            except OSError:
                return self._err("还没有二维码", 404)
        # ---- 人工拉起桥接(断线提示里那个按钮;复用 auth,不用重新扫码)----
        if p == ["bridge", "start"] and method == "POST":
            bdir = _bridge_dir()
            kp = os.path.join(bdir, "keepalive.py")
            st = _bridge_status()
            why = str(st.get("stopped") or "")
            if why in ("logged-out", "qr-expired", "device-mismatch", "pair-failed"):
                return self._err("需要重新扫码(%s)" % (st.get("reason") or why), 409)
            if why == "machine-locked":
                return self._err("另一份桥接正在本机运行(%s),请先退出那一份"
                                 % (st.get("reason") or ""), 409)
            if _bridge_side_alive():
                # 【改 2026-11-03】进程还活着 → 让它"原地重新拨号",不要杀进程重开。
                # 杀进程重开 = 重新走一次完整登录,反复上下线正是封号诱因。
                r = _bridge_side_post("/reconnect")
                if r is not None:
                    return self._ok(r) if r.get("ok") else self._err(
                        str(r.get("error") or "重连被拒绝"), 409)
                return self._ok({"ok": True, "already": True})
            if not os.path.exists(kp):
                return self._err("缺少 bridge/keepalive.py,无法拉起", 500)
            if not _spawn_allowed():
                return self._ok({"ok": True, "starting": True, "dedup": True})
            # 人工拉起 → 清除"手动停止"暂停标记,恢复看门狗对崩溃的自救能力
            try:
                os.remove(os.path.join(bdir, ".watchdog_pause"))
            except OSError:
                pass
            subprocess.Popen([sys.executable, kp, "--start"], cwd=bdir, env=_bridge_env(),
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                             **_detached())
            return self._ok({"ok": True, "starting": True})
        if p == ["bridge", "reset"] and method == "POST":
            # 【改 2026-09-16】取消 30 分钟冷却:随时可重新扫码。
            # 但“请求二维码”只在此次点击时发生(写 pairing.req)——软件不会自动请求。
            bdir = os.path.join(db.PROJECT_DIR, "bridge")
            subprocess.run([sys.executable, "keepalive.py", "--stop"], cwd=bdir, timeout=30,
                           env=_bridge_env(), stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL, **_no_window())
            # 【关键】先确认旧进程真的退出,再动 auth —— 否则会出现"旧进程还在连、
            # 新进程又拿着新凭据连"的双连;而且中途失败时 auth 已经被改名,用户白白丢登录。
            for _ in range(40):          # 最多等 8 秒
                if not _bridge_side_alive(timeout=0.4):
                    break
                time.sleep(0.2)
            if _bridge_side_alive(timeout=0.4):
                return self._err("旧桥接进程没停干净,已取消本次重新扫码(请稍后重试)", 409)
            for f2 in ("qr.png", "qr.txt", "pairing.req", "status.json"):
                try:
                    os.remove(os.path.join(bdir, f2))
                except OSError:
                    pass
            # 重新扫码 = 人工重启动作 → 同样恢复看门狗(清"手动停止"暂停标记)
            try:
                os.remove(os.path.join(bdir, ".watchdog_pause"))
            except OSError:
                pass
            old = os.path.join(bdir, "auth")
            if os.path.isdir(old):
                try:
                    os.rename(old, os.path.join(bdir, "auth.bad-%s" % time.strftime("%Y%m%d-%H%M%S")))
                except OSError as e:
                    log.swallow("server.bridge_reset_rename", e)
            # 【关键】必须等旧进程真的退出,否则新进程会和旧的抢同一个账号(440 双连)。
            if not _spawn_allowed():
                return self._err("正在启动中,请稍候再点", 409)
            # 写“扫码指令” → 桥接看到它才去请求二维码
            try:
                with open(os.path.join(bdir, "pairing.req"), "w") as f:
                    f.write(str(time.time()))
            except OSError as e:
                log.swallow("server.bridge_pair_req", e)
            # 【后台拉起】首次可能要装依赖(1-3 分钟),不能阻塞界面
            _env = _bridge_env()
            subprocess.Popen([sys.executable, "keepalive.py", "--force"], cwd=bdir,
                             env=_env, stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL, **_detached())
            return self._ok({"ok": True, "reset_wait_s": 0, "starting": True})
        # ---- 重启桥接(不清除auth,bridge崩溃后用)----
        if p == ["bridge", "restart"] and method == "POST":
            bdir = _bridge_dir()
            kp = os.path.join(bdir, "keepalive.py")
            # 先停止旧进程(优雅 /shutdown,不弹窗)
            try:
                subprocess.run([sys.executable, kp, "--stop"], cwd=bdir,
                               timeout=15, env=_bridge_env(),
                               stdout=subprocess.DEVNULL,
                               stderr=subprocess.DEVNULL, **_no_window())
            except Exception:
                pass
            time.sleep(0.8)  # 等端口释放
            if _bridge_side_alive(timeout=0.4):
                return self._err("旧桥接进程没停干净,已取消重启(请稍后重试)", 409)
            if not _spawn_allowed():
                return self._ok({"ok": True, "restarting": True, "dedup": True})
            # 重新拉起(人工动作 → 允许忽略软停手);同时恢复看门狗
            try:
                os.remove(os.path.join(bdir, ".watchdog_pause"))
            except OSError:
                pass
            subprocess.Popen([sys.executable, kp, "--start"], cwd=bdir,
                             env=_bridge_env(), stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL, **_detached())
            return self._ok({"ok": True, "restarting": True})
        # ---- 手动停止桥接(调试/排查用)----
        if p == ["bridge", "stop"] and method == "POST":
            bdir = _bridge_dir()
            # 写暂停标记:告诉看门狗"这是用户主动停的,别自动拉起"
            try:
                with open(os.path.join(bdir, ".watchdog_pause"), "w") as f:
                    f.write(str(time.time()))
            except OSError:
                pass
            try:
                subprocess.run([sys.executable, os.path.join(bdir, "keepalive.py"), "--stop"],
                               cwd=bdir, timeout=20, env=_bridge_env(),
                               stdout=subprocess.DEVNULL,
                               stderr=subprocess.DEVNULL, **_no_window())
            except Exception:
                pass
            return self._ok({"ok": True})
        # ---- 退出软件(杀桥接+AI+自身)----
        if p == ["exit"] and method == "POST":
            self._ok({"ok": True})
            import threading as _t
            def _shutdown():
                time.sleep(0.5)
                try:
                    bd = os.path.join(db.PROJECT_DIR, "bridge")
                    subprocess.run([sys.executable, "keepalive.py", "--stop"],
                                   cwd=bd, timeout=10, env=_bridge_env(),
                                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                   **_no_window())
                except Exception:
                    pass
                try:
                    subprocess.run(["taskkill", "/F", "/IM", "llama-server.exe"],
                                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=10)
                except Exception:
                    pass
                os._exit(0)
            _t.Thread(target=_shutdown, daemon=True).start()
            return
        # ---- 用户登录/切换(多用户数据隔离)----
        if p == ["user", "current"] and method == "GET":
            return self._ok({
                "current": db.get_current_user(),
                "users": db.list_users(),
                "data_dir": db.DATA_DIR,
            })
        if p == ["user", "login"] and method == "POST":
            data = self._body()
            name = str(data.get("name", "")).strip()
            if not name:
                return self._err("请输入名字")
            if len(name) > 30:
                return self._err("名字太长(最多30字)")
            # 禁止危险字符
            if any(ch in name for ch in '\\/:*?"<>|'):
                return self._err("名字不能包含特殊字符")
            try:
                db.switch_user(name)
            except Exception as e:
                return self._err("登录失败: %s" % e)
            return self._ok({"ok": True, "user": name, "data_dir": db.DATA_DIR})
        if p == ["user", "switch"] and method == "POST":
            data = self._body()
            name = str(data.get("name", "")).strip()
            if not name:
                return self._err("请选择用户")
            try:
                db.switch_user(name)
            except Exception as e:
                return self._err("切换失败: %s" % e)
            return self._ok({"ok": True, "user": name})
        # ---- WhatsApp 官方 Cloud API(webhook 收信;合规、不会被封)----
        # Meta 配置 webhook 时会先用 GET 带 hub.challenge 来验一下
        if p == ["wa", "webhook"] and method == "GET":
            want = db.get_setting("wa_verify_token", "")
            mode = self._query("hub.mode", "")
            tok = self._query("hub.verify_token", "")
            chal = self._query("hub.challenge", "")
            if mode == "subscribe" and want and tok == want:
                return self._text(chal)          # 原样回显 challenge
            return self._err("verify failed", 403)
        if p == ["wa", "webhook"] and method == "POST":
            raw = self._raw_body()
            if not wa_official.signature_ok(raw, self.headers.get("X-Hub-Signature-256")):
                log.warn("webhook 签名不通过 @server", detail="已拒绝一条伪造/缺失签名的请求")
                return self._err("bad signature", 403)
            try:
                data = json.loads(raw.decode("utf-8") or "{}")
            except ValueError:
                return self._err("bad json", 400)
            n = 0
            for m in wa_official.parse_webhook(data):
                if not m.get("content"):
                    continue
                service.ingest_message({
                    "phone": m["phone"], "name": m["name"], "content": m["content"],
                    "ts": m["ts"], "direction": "in", "source": "direct",
                    "chat": "", "sender_role": "customer",
                    "wa_message_id": m.get("wa_message_id", ""),
                })
                n += 1
            return self._ok({"received": n})   # 必须快速 200,否则 Meta 会重推
        if p == ["wa", "status"] and method == "GET":
            return self._ok(wa_official.status())
        if p == ["wa", "settings"] and method == "POST":
            b = self._body()
            for k in ("wa_mode", "wa_app_secret", "wa_access_token", "wa_phone_number_id"):
                if k in b:
                    db.set_setting(k, str(b.get(k) or "").strip())
            wa_official.ensure_settings()
            return self._ok(wa_official.status())
        # ---- 收信接口(历史导入/自用脚本仍可用;官方 webhook 走上面那条)----
        if p and p[0] == "ingest" and len(p) == 1 and method == "POST":
            data = self._body()
            if str(data.get("token") or "") != db.get_setting("ingest_token", ""):
                return self._err("令牌不正确", 403)
            if not str(data.get("content") or "").strip():
                return self._err("content 不能为空")
            # 判定“谁发的/归哪个客户”全部在 service.ingest_message 里(我方 PM/SM、
            # 客户本人、客户自带设计师三种身份区分开)
            res = service.ingest_message(data)
            if not res.get("ok"):
                return self._ok({"skipped": res.get("skipped")}, 202)
            return self._ok({"customer_id": res.get("customer_id"),
                             "message_id": res.get("message_id"),
                             "role": res.get("role"),
                             "sender": res.get("sender")}, 201)
        # ---- 批量历史导入:导入完成后统一补一次分析(零 AI、不刷卡片) ----
        if (p and p[0] == "ingest" and len(p) == 2 and p[1] == "bulk-done"
                and method == "POST"):
            data = self._body()
            if str(data.get("token") or "") != db.get_setting("ingest_token", ""):
                return self._err("令牌不正确", 403)
            ids = []
            for x in (data.get("customer_ids") or []):
                try:
                    ids.append(int(x))
                except (TypeError, ValueError):
                    pass
            done = 0
            for cid in ids[:500]:
                try:
                    if db.get_customer(cid):
                        profile.enrich_customer(cid)
                        done += 1
                except Exception as e:
                    log.swallow("server.py:754", e)
            return self._ok({"enriched": done, "total": len(ids)})
        # ---- WhatsApp 标签(客户分级):把标签名字里的 A/B/C 映到客户分级 ----
        if (p and p[0] == "ingest" and len(p) == 2 and p[1] == "labels"
                and method == "POST"):
            data = self._body()
            if str(data.get("token") or "") != db.get_setting("ingest_token", ""):
                return self._err("令牌不正确", 403)
            labels = {}
            for l in (data.get("labels") or []):
                labels[str(l.get("id") or "")] = (l.get("name") or "")
            db.set_setting("wa_labels", json.dumps(labels, ensure_ascii=False))
            db.set_setting("wa_assoc", json.dumps(data.get("assoc") or [], ensure_ascii=False))
            if not data.get("assoc"):
                # 空的关联不动已有的等级(避免误清)
                pass
            applied = []
            for a in (data.get("assoc") or []):
                chat = (a.get("chat") or "").strip()
                if not chat:
                    continue
                # 会话可能按“群 JID”或“群名”绑定 —— 三种键都试,并且两个键都补绑
                subj = (a.get("subject") or "").strip()
                owner = (db.get_chat_customer(chat)
                         or db.get_chat_customer(re.sub(r"@.*$", "", chat))
                         or (db.get_chat_customer(subj) if subj else None))
                if not owner:
                    continue
                for _k in filter(None, [chat, subj]):
                    if not db.get_chat_customer(_k):
                        db.link_chat(_k, owner["id"])
                grade = _grade_from_labels([labels.get(str(i), "") for i in (a.get("ids") or [])])
                if grade and (owner.get("grade") or "") != grade:
                    db.update_customer(owner["id"], {"grade": grade})
                    applied.append({"customer_id": owner["id"], "grade": grade})
            return self._ok({"labels": len(labels), "applied": applied[:50],
                             "applied_count": len(applied)})
        # ---- 名片号码提示:群里发的“客户名片”里带真号 → 补进客户档 ----
        if (p and p[0] == "ingest" and len(p) == 2 and p[1] == "phone-hint"
                and method == "POST"):
            data = self._body()
            if str(data.get("token") or "") != db.get_setting("ingest_token", ""):
                return self._err("令牌不正确", 403)
            chat = (data.get("chat") or "").strip()
            phone = (data.get("phone") or "").strip()
            if not chat or len(re.sub(r"\D", "", phone)) < 7:
                return self._ok({"skipped": "参数不足"})
            # 会话可能以“群名”或“群 JID”任一形式绑定 —— 两个键都查
            owner = (db.get_chat_customer(chat)
                     or db.get_chat_customer((data.get("chat_jid") or "").strip()))
            if not owner:
                return self._ok({"skipped": "该会话还没绑定客户"})
            if (owner.get("phone") or "").strip():
                return self._ok({"skipped": "档案已有号码", "customer_id": owner["id"]})
            db.update_customer(owner["id"], {"phone": phone})
            return self._ok({"filled": owner["id"], "phone": phone})
        # ---- 联系人映射表(LID ↔ 真号 ↔ 备注名):给还没发言的群成员补号 ----
        if (p and p[0] == "ingest" and len(p) == 2 and p[1] == "contacts"
                and method == "POST"):
            data = self._body()
            if str(data.get("token") or "") != db.get_setting("ingest_token", ""):
                return self._err("令牌不正确", 403)
            try:
                cmap = json.loads(db.get_setting("contact_map", "{}"))
            except (ValueError, TypeError):
                cmap = {}
            n = 0
            for c in (data.get("contacts") or []):
                lid = re.sub(r"\D", "", str(c.get("lid") or ""))
                phone = re.sub(r"\D", "", str(c.get("phone") or ""))
                name = (c.get("name") or "").strip()
                if not lid or len(phone) < 7:
                    continue
                cur = cmap.get(lid) or {}
                cmap[lid] = {"phone": "+" + phone,
                             "name": name or cur.get("name", "")}
                n += 1
            if n:
                db.set_setting("contact_map", json.dumps(cmap, ensure_ascii=False))
            return self._ok({"stored": n, "total": len(cmap)})
        # ---- 客户进群:运营建群→邀请客户→客户还没发言就建档并绑定这个群 ----
        if (p and p[0] == "ingest" and len(p) == 2 and p[1] == "join"
                and method == "POST"):
            data = self._body()
            if str(data.get("token") or "") != db.get_setting("ingest_token", ""):
                return self._err("令牌不正确", 403)
            chat_jid = (data.get("chat_jid") or "").strip()
            chat = (data.get("chat") or "").strip()
            created, linked, pending_team = [], [], []
            for j in (data.get("joiners") or [])[:20]:
                phone = (j.get("phone") or "").strip()
                name = (j.get("name") or "").strip()
                if len(re.sub(r"\D", "", phone)) < 7:
                    continue
                if db.find_team_by_phone(phone):
                    continue                       # 名册里的同事,不建客户
                if db._digits(phone).startswith("86"):
                    # 国内号:多半是运营/同事还没登记 → 记入"待确认同事",不建客户
                    db.note_pending_team(phone, name)
                    pending_team.append(phone)
                    continue
                cust = db.find_customer_by_phone(phone)
                if not cust:
                    cid = db.create_customer({"name": name or phone, "phone": phone,
                                              "source": "群邀请", "stage": "新询盘"})
                    created.append(cid)
                else:
                    cid = cust["id"]
                    if name and (not cust.get("name") or cust["name"] == cust.get("phone")):
                        db.update_customer(cid, {"name": name})
                if chat_jid:
                    db.link_chat(chat_jid, cid)   # 群按 JID 绑定(改名不受影响)
                if chat:
                    db.link_chat(chat, cid)       # 兼容按群名绑的历史数据
                linked.append({"customer_id": cid, "phone": phone})
            return self._ok({"created": created, "linked": linked,
                             "pending_team": pending_team})
        # ---- 本地 AI 分级(手动触发;默认不自动跑,提示词待验收) ----
        if p and p[0] == "classify" and len(p) == 2 and p[1] == "status" and method == "GET":
            return self._ok(classifier.status())
        if (p and p[0] == "classify" and len(p) == 2 and p[1] == "run"
                and method == "POST"):
            data = self._body()
            try:
                cid = int(data.get("customer_id") or 0)
            except (TypeError, ValueError):
                return self._err("参数不正确", 400)
            r = classifier.run(cid)
            return self._ok(r) if r.get("ok") else self._err(
                str(r.get("reason") or "判断失败"), 409)
        # ---- 按需群名:本地没有这个名字时,才向桥接要"这一个群"(桥接侧有 ≤6 次/小时闸门) ----
        if p and p[0] == "groupname" and len(p) == 1 and method == "GET":
            import urllib.parse as _up
            q = parse_qs(urlparse(self.path).query)
            jid = (q.get("jid") or [""])[0]
            if not jid:
                return self._err("缺少 jid", 400)
            r = _bridge_side_get("/groupname?jid=" + _up.quote(jid))
            return self._ok({"jid": jid,
                             "subject": (r or {}).get("subject") or "",
                             "cached": bool((r or {}).get("cached"))})
        # ---- 待认领消息:号码/归属不明的消息(不再丢弃,人工指定客户后重放) ----
        if p and p[0] == "unclaimed" and len(p) == 1 and method == "GET":
            return self._ok({"items": db.list_unclaimed(),
                             "count": db.count_unclaimed()})
        if (p and p[0] == "unclaimed" and len(p) == 2 and p[1] == "assign"
                and method == "POST"):
            data = self._body()
            try:
                uid, cid = int(data.get("id") or 0), int(data.get("customer_id") or 0)
            except (TypeError, ValueError):
                return self._err("参数不正确", 400)
            row = db.get_unclaimed(uid)
            if not row:
                return self._err("没有这条待认领消息", 404)
            if not db.get_customer(cid):
                return self._err("客户不存在", 404)
            payload = row.get("payload") or {}
            direction = "out" if str(payload.get("direction") or "in") == "out" else "in"
            chat = (payload.get("chat_jid") or payload.get("chat") or "").strip()

            def _replay():
                # 【改 2026-11-03】放到后台跑:入库时会顺带推导客户档案(可能调用 AI,
                # 有超时)→ 不能把界面卡住。补回完成后待认领自动消失。
                try:
                    service.process_message(
                        cid, direction, payload.get("content") or "",
                        ts=payload.get("ts"),
                        source=payload.get("source") or "direct",
                        source_ref=payload.get("chat") or "",
                        sender_phone=payload.get("phone") or "",
                        sender_name=payload.get("name") or "",
                        sender_role=payload.get("sender_role") or "")
                    if chat:
                        db.link_chat(chat, cid)   # 下次这条会话再来的消息就自动归位
                    db.finish_unclaimed(uid, "done", cid)
                    log.warn("unclaimed.replay", None, "ok uid=%s cid=%s" % (uid, cid))
                except Exception as e:
                    log.swallow("server.unclaimed_replay", e)

            import threading as _th   # 本函数内已有 import threading 的局部绑定,这里用别名避免作用域冲突
            _th.Thread(target=_replay, daemon=True).start()
            return self._ok({"ok": True, "customer_id": cid, "async": True})
        if (p and p[0] == "unclaimed" and len(p) == 2 and p[1] == "ignore"
                and method == "POST"):
            data = self._body()
            try:
                uid = int(data.get("id") or 0)
            except (TypeError, ValueError):
                return self._err("参数不正确", 400)
            if not db.get_unclaimed(uid):
                return self._err("没有这条待认领消息", 404)
            db.finish_unclaimed(uid, "ignored", None)
            return self._ok({"ok": True})
        # ---- 历史同步进度(桥接上报,界面展示用) ----
        if (p and p[0] == "history" and len(p) == 2 and p[1] == "status"
                and method == "POST"):
            data = self._body()
            if str(data.get("token") or "") != db.get_setting("ingest_token", ""):
                return self._err("令牌不正确", 403)
            st = {k: data.get(k) for k in ("started", "chats", "messages",
                                           "progress", "done")}
            db.set_setting("history_status", json.dumps(st, ensure_ascii=False))
            return self._ok({"ok": True})
        if p and p[0] == "history" and len(p) == 2 and p[1] == "status" and method == "GET":
            raw = db.get_setting("history_status", "")
            try:
                st = json.loads(raw) if raw else {}
            except (ValueError, TypeError):
                st = {}
            return self._ok({"history": st})
        # ---- 我方团队名册(PM / SM / 运营):SM 的群内回复靠这个区分 ----
        if p and p[0] == "team" and len(p) == 1 and method == "GET":
            return self._ok({"items": db.list_team(), "roles": db.TEAM_ROLES})
        # 名册口:群里自动发现的我方号码(待确认)→ 一键加进名册
        if (p and p[0] == "team" and len(p) == 2 and p[1] == "pending"
                and method == "GET"):
            return self._ok({"items": db.list_pending_team()})
        if (p and p[0] == "team" and len(p) == 3 and p[1] == "pending"
                and p[2] == "confirm" and method == "POST"):
            b = self._body()
            phone = str(b.get("phone") or "").strip()
            if not phone:
                return self._err("缺少手机号")
            db.add_team_member({"phone": phone,
                                "name": str(b.get("name") or "").strip(),
                                "role": str(b.get("role") or "SM").strip()})
            db.clear_pending_team(phone)
            return self._ok({"items": db.list_team(),
                             "pending": db.list_pending_team()})
        if (p and p[0] == "team" and len(p) == 3 and p[1] == "pending"
                and p[2] == "remove" and method == "POST"):
            db.clear_pending_team(str(self._body().get("phone") or "").strip())
            return self._ok({"pending": db.list_pending_team()})
        if p and p[0] == "team" and len(p) == 1 and method == "POST":
            body = self._body()
            if not str(body.get("phone") or "").strip():
                return self._err("请填手机号")
            tid = db.add_team_member(body)
            return self._ok({"id": tid, "items": db.list_team()}, 201)
        if p and p[0] == "team" and len(p) == 2 and method in ("PUT", "POST"):
            db.update_team_member(int(p[1]), self._body())
            return self._ok({"items": db.list_team()})
        if p and p[0] == "team" and len(p) == 2 and method == "DELETE":
            db.delete_team_member(int(p[1]))
            return self._ok({"items": db.list_team()})
        # ---- 客户方相关人(客户自带的设计师/采购/同事) ----
        if p and p[0] == "persons" and len(p) == 1 and method == "GET":
            cid = self._query("customer_id", "")
            return self._ok({"items": db.list_persons(int(cid) if cid else None),
                             "roles": db.PERSON_ROLES})
        if p and p[0] == "persons" and len(p) == 1 and method == "POST":
            body = self._body()
            cid = body.get("customer_id")
            if not cid:
                return self._err("缺少 customer_id")
            pid = None
            if str(body.get("phone") or "").strip():
                p0 = db.upsert_person(int(cid), body.get("phone"),
                                      body.get("name") or "",
                                      body.get("role") or "其他",
                                      body.get("note") or "", source="human")
                pid = (p0 or {}).get("id")
                db.update_person(pid, {"role": body.get("role") or "其他",
                                       "name": body.get("name") or ""})
            return self._ok({"id": pid,
                             "items": db.list_persons(int(cid))}, 201)
        if p and p[0] == "persons" and len(p) == 2 and method in ("PUT", "POST"):
            db.update_person(int(p[1]), self._body())
            return self._ok({"ok": True})
        if p and p[0] == "persons" and len(p) == 2 and method == "DELETE":
            db.delete_person(int(p[1]))
            return self._ok({"ok": True})
        # ---- 发送者身份配置(手动调整消息方向) ----
        if p and p[0] == "sender-identities" and len(p) == 1 and method == "GET":
            cid = self._query("customer_id", "")
            return self._ok({"items": db.list_sender_identities(
                int(cid) if cid else None)})
        if p and p[0] == "sender-identities" and len(p) == 1 and method == "POST":
            body = self._body()
            phone = str(body.get("phone") or "").strip()
            name = str(body.get("name") or "").strip()
            side = str(body.get("side") or "customer").strip()
            role = str(body.get("role") or "").strip()
            cid = body.get("customer_id")
            if not phone and not name:
                return self._err("手机号和名字至少填一个")
            sid = db.upsert_sender_identity(
                phone=phone, name=name, side=side, role=role,
                customer_id=int(cid) if cid else None)
            return self._ok({"id": sid,
                             "items": db.list_sender_identities(
                                 int(cid) if cid else None)}, 201)
        if p and p[0] == "sender-identities" and len(p) == 2 and method == "DELETE":
            db.delete_sender_identity(int(p[1]))
            return self._ok({"ok": True})
        # ---- 一个客户的关系网(相关人 + 所属群聊) ----
        if (p and p[0] == "customers" and len(p) == 3 and p[2] == "relations"
                and method == "GET"):
            cid = int(p[1])
            return self._ok({"persons": db.list_persons(cid),
                             "chats": db.links_for_customer(cid),
                             "roles": db.PERSON_ROLES})
        # ---- 合并客户(同人两号 / 把设计师并进客户档案) ----
        if (p and p[0] == "customers" and len(p) == 3 and p[2] == "merge"
                and method == "POST"):
            body = self._body()
            src = body.get("source_id")
            if not src:
                return self._err("请选择要合并进来的客户")
            out = db.merge_customers(int(src), int(p[1]),
                                     body.get("role") or "其他",
                                     body.get("note") or "")
            if not out:
                return self._err("合并失败(客户不存在,或选了自己)")
            db.links_for_customer(int(p[1]))
            return self._ok(out)
        # ---- 合并留痕 + 撒销(误合并一键回滚) ----
        if p and p[0] == "merges" and len(p) == 1 and method == "GET":
            return self._ok({"items": db.list_merges()})
        if (p and p[0] == "merges" and len(p) == 3 and p[2] == "revert"
                and method == "POST"):
            out = db.revert_merge(int(p[1]))
            if not out:
                return self._err("找不到这条合并记录")
            return self._ok(out)
        # ---- 重新指定一个群聊归哪个客户 ----
        if p and p[0] == "chats" and len(p) == 1 and method == "POST":
            body = self._body()
            ref = str(body.get("chat") or "").strip()
            cid2 = body.get("customer_id")
            if not ref or not cid2:
                return self._err("缺少 chat / customer_id")
            db.link_chat(ref, int(cid2))
            return self._ok({"ok": True})
        # ---- AI 处理日志(半月导出给 William 固化) ----
        if p and p[0] == "ai-log" and len(p) == 1 and method == "GET":
            return self._ok({"items": db.list_ai_log(), "usage": ai.usage()})
        if (p and p[0] == "ai-log" and len(p) == 2 and p[1] == "export"
                and method == "GET"):
            items = db.list_ai_log()
            export = {
                "app": "外贸客户工作台",
                "exported_at": db.now_iso(),
                "count": len(items),
                "items": [{
                    "field": it["task"],
                    "field_cn": {"identity": "身份", "followup": "跟进分类",
                                 "grade": "分级", "batch": "批次"}.get(it["task"], it["task"]),
                    "customer": it.get("customer_name") or "",
                    "status": it.get("status") or "",
                    "result": it.get("result") or "",
                    "quote": it.get("quote") or "",
                    "detail": it.get("detail") or "",
                    "at": it.get("created_at") or "",
                } for it in items],
            }
            return self._ok(export)
        # ---- 桥接状态 / 二维码(登录页用) ----
        # 界面错误上报 → 写进 data/app.log(排障用:白屏/undefined 一目了然)
        if p and p[0] == "ui-error" and method == "POST":
            b = self._body()
            log.warn("UI:%s" % str(b.get("where") or "?"),
                     Exception(str(b.get("message") or "")[:300]),
                     detail=str(b.get("stack") or "")[:400])
            return self._ok({"ok": True})
        # ---- 设置 / 统计 ----
        if p and p[0] == "settings" and method == "GET":
            return self._ok({"settings": db.all_settings()})
        if p and p[0] == "settings" and method == "PUT":
            body = self._body()
            for key, value in body.items():
                if isinstance(value, (str, int, float)):
                    db.set_setting(key, str(value))
            return self._ok({"settings": db.all_settings()})
        if p and p[0] == "stats" and method == "GET":
            # 判断是否是开发者版(有port.txt文件即为开发者版)
            is_dev = os.path.exists(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "port.txt"))
            return self._ok({**db.stats(), "db_path": db.DB_PATH,
                             "version": APP_VERSION, "is_dev": is_dev})
        # ============ 老板端口API(只读,需密钥验证) ============
        if p and p[0] == "boss" and method == "GET":
            # 验证老板密钥
            token = self.headers.get("X-Boss-Token", "") or self.headers.get("x-boss-token", "")
            if token != BOSS_TOKEN:
                return self._err("老板密钥错误", 401)
            # /api/boss/summary - 统计概览
            if len(p) == 2 and p[1] == "summary":
                stats = db.stats()
                today = db.today_iso()
                # 今日已处理数
                processed_today = 0
                today_recommend_pending = 0
                try:
                    con = db.connect()
                    cur = con.execute(
                        "SELECT COUNT(*) as cnt FROM reminders WHERE status='done' AND date(decided_at)=?",
                        (today,))
                    processed_today = cur.fetchone()["cnt"]
                    # 今日推荐未处理:待批准的建议 + 已到点未处理的跟进
                    cur2 = con.execute(
                        "SELECT COUNT(*) as cnt FROM reminders WHERE status='suggested' OR (status='approved' AND date(notify_date)<=?)",
                        (today,))
                    today_recommend_pending = cur2.fetchone()["cnt"]
                    con.close()
                except Exception:
                    pass
                return self._ok({
                    "pm_name": db.get_current_user() or "未知",
                    "version": APP_VERSION,
                    "total_customers": stats.get("customers", 0),
                    "total_messages": stats.get("messages", 0),
                    "pending_followups": stats.get("reminders", {}).get("approved", 0),
                    "today_recommend_pending": today_recommend_pending,
                    "processed_today": processed_today,
                    "today": today,
                    "stages": db.stage_counts(),
                })
            # /api/boss/followups - 待跟进列表
            if len(p) == 2 and p[1] == "followups":
                items = profile.today_followups()
                return self._ok({"items": items, "today": db.today_iso()})
            # /api/boss/processed - 已处理列表(最近30天)
            if len(p) == 2 and p[1] == "processed":
                items = db.list_reminders(status="done", limit=100)
                return self._ok({"items": items})
            # /api/boss/customers - 客户列表
            if len(p) == 2 and p[1] == "customers":
                customers = db.list_customers()
                return self._ok({"customers": customers})
            # /api/boss/customers/{id}/messages - 客户消息记录
            if len(p) == 4 and p[1] == "customers" and p[3] == "messages":
                cid = int(p[2])
                limit = int(self._query("limit", "200") or "200")
                messages = db.list_messages(cid, limit=limit)
                customer = db.get_customer(cid)
                return self._ok({"customer": customer, "messages": messages})
            # /api/boss/customers/{id} - 客户详情
            if len(p) == 3 and p[1] == "customers":
                cid = int(p[2])
                customer = db.get_customer(cid)
                if not customer:
                    return self._err("客户不存在", 404)
                return self._ok({"customer": customer})
            # /api/boss/daily-report - 当日日报
            if len(p) == 2 and p[1] == "daily-report":
                report_date = self._query("date", db.today_iso()) or db.today_iso()
                report = db.get_daily_report(report_date)
                return self._ok({"date": report_date, "report": report})
            return self._err("未知老板API", 404)
        # 老板模式设置(本地界面调用,不需要密钥)
        if p and p[0] == "boss-settings" and method == "GET":
            return self._ok({
                "boss_enabled": True,
                "boss_token_set": bool(_boss_token()),
                "local_ip": _get_local_ip(),
            })
        if p and p[0] == "local-ip" and method == "GET":
            return self._ok({"ip": _get_local_ip()})
        # ---- 联网更新(你控制后台,PM 端一键更新)----
        if p == ["update", "check"] and method == "GET":
            return self._ok(updater.check())
        if p == ["update", "status"] and method == "GET":
            return self._ok({"current": APP_VERSION, "url": updater.update_url(),
                             "data_dir": getattr(db, "DATA_DIR", "") or
                                         os.path.dirname(db.DB_PATH),
                             "bridge_proxy": db.get_setting("bridge_proxy", ""),
                             **updater.staged_info()})
        if p == ["update", "download"] and method == "POST":
            return self._ok(updater.stage())
        if p == ["update", "apply"] and method == "POST":
            return self._ok(updater.run_apply())
        return self._err("not found", 404)

    # HTTP 方法入口
    do_GET = lambda self: self._handle("GET")
    do_POST = lambda self: self._handle("POST")
    do_PUT = lambda self: self._handle("PUT")
    do_DELETE = lambda self: self._handle("DELETE")


def _open_app_window(url):
    """优先用无边框原生窗口(启动窗口.ps1),失败回退到浏览器应用模式。"""
    import os
    import shutil
    import subprocess
    import sys as _sys
    if _sys.platform.startswith("win"):
        exe = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "客户工作台.exe")
        if os.path.exists(exe):
            try:
                subprocess.Popen([exe], cwd=os.path.dirname(exe))
                return True
            except Exception:
                pass
        cands = ["msedge", "chrome",
                 r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
                 r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
                 r"C:\Program Files\Google\Chrome\Application\chrome.exe",
                 r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"]
    elif _sys.platform == "darwin":
        cands = ["google-chrome"]
    else:
        cands = ["google-chrome", "chromium", "chromium-browser", "microsoft-edge"]
    for c in cands:
        exe = shutil.which(c) or (c if os.path.exists(c) else None)
        if not exe:
            continue
        try:
            subprocess.Popen([exe, "--app=" + url],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return True
        except Exception:
            continue
    return False


# ========== 日报总结(模块级别,API可访问) ==========
def _daily_report_loop():
    import time as _time
    last_date = None
    while True:
        try:
            now = datetime.now()
            today_str = now.strftime("%Y-%m-%d")
            if now.hour >= 7 and last_date != today_str:
                existing = db.get_daily_report(today_str)
                if not existing:
                    try:
                        generate_daily_report(today_str)
                        last_date = today_str
                        print("  日报总结:%s 已生成 ✅" % today_str)
                    except Exception as e:
                        print("  日报总结生成失败:", e)
                else:
                    last_date = today_str
        except Exception:
            pass
        _time.sleep(300)


def generate_daily_report(report_date):
    """用本地AI生成日报总结"""
    if not ai.enabled():
        stats = db.get_daily_stats(report_date)
        summary = "今日新增客户%d,新消息%d条,已处理承诺%d条" % (
            stats["new_customers"], stats["new_messages"], stats["reminders_done"])
        content = _build_daily_report_text(stats, None)
        db.save_daily_report(report_date, content, summary, stats, "stats")
        return
    stats = db.get_daily_stats(report_date)
    prompt = _build_daily_ai_prompt(stats)
    try:
        result = ai._call_api([
            {"role": "system", "content": "你是外贸销售团队的日报助手。根据今日工作数据,生成简洁专业的日报总结。"},
            {"role": "user", "content": prompt}
        ])
        summary = result.get("summary", "") if isinstance(result, dict) else str(result)[:100]
        content = result.get("content", str(result)) if isinstance(result, dict) else str(result)
    except Exception as e:
        summary = "今日新增客户%d,新消息%d条,已处理承诺%d条" % (
            stats["new_customers"], stats["new_messages"], stats["reminders_done"])
        content = _build_daily_report_text(stats, None)
    db.save_daily_report(report_date, content, summary, stats, "ai")


def _build_daily_ai_prompt(stats):
    lines = ["今日工作数据:"]
    lines.append("- 新增客户: %d 人" % stats["new_customers"])
    if stats.get("new_customer_list"):
        names = ", ".join([c["name"] for c in stats["new_customer_list"][:10]])
        lines.append("  客户名单: %s" % names)
    lines.append("- 新消息: %d 条(客户发来%d,我方发出%d)" % (
        stats["new_messages"], stats["in_messages"], stats["out_messages"]))
    lines.append("- 活跃客户: %d 人" % stats["active_customers"])
    lines.append("- 已处理承诺: %d 条" % stats["reminders_done"])
    if stats.get("done_customers"):
        names = ", ".join([c["name"] for c in stats["done_customers"][:10]])
        lines.append("  处理客户: %s" % names)
    lines.append("- 新批准承诺: %d 条" % stats["reminders_approved"])
    lines.append("- 待跟进承诺: %d 条" % stats["pending_reminders"])
    lines.append("")
    lines.append("请生成日报总结,包含:1)今日工作概览 2)重点客户跟进 3)明日待办建议。")
    lines.append('输出JSON格式: {"summary":"一句话摘要","content":"日报正文,用换行分隔段落"}')
    return "\n".join(lines)


def _build_daily_report_text(stats, ai_content):
    """生成简洁美观的日报文本,适合截图发工作群"""
    lines = []
    lines.append("📊 外贸客户工作台日报")
    lines.append("📅 %s" % stats["date"])
    lines.append("")
    lines.append("━━━━━━━━━━━━━━━━━━━━")
    lines.append("")
    lines.append("📈 今日概览")
    lines.append("")
    lines.append("  新增客户: %d 人" % stats["new_customers"])
    lines.append("  活跃客户: %d 人" % stats["active_customers"])
    lines.append("  新消息: %d 条 (收%d / 发%d)" % (
        stats["new_messages"], stats["in_messages"], stats["out_messages"]))
    lines.append("  已处理承诺: %d 条" % stats["reminders_done"])
    lines.append("  待跟进承诺: %d 条" % stats["pending_reminders"])
    lines.append("")

    # 已处理承诺明细
    if stats.get("done_customers"):
        lines.append("━━━━━━━━━━━━━━━━━━━━")
        lines.append("")
        lines.append("✅ 今日已处理 (%d条)" % stats["reminders_done"])
        lines.append("")
        for cust in stats["done_customers"]:
            grade = cust.get("grade", "")
            grade_str = " [%s]" % grade if grade and grade != "未分级" else ""
            lines.append("  • %s%s" % (cust["name"], grade_str))
        lines.append("")

    # 新增客户
    if stats.get("new_customer_list"):
        lines.append("━━━━━━━━━━━━━━━━━━━━")
        lines.append("")
        lines.append("🆕 新增客户 (%d人)" % len(stats["new_customer_list"]))
        lines.append("")
        for cust in stats["new_customer_list"]:
            grade = cust.get("grade", "")
            grade_str = " [%s]" % grade if grade and grade != "未分级" else ""
            lines.append("  • %s%s" % (cust["name"], grade_str))
        lines.append("")

    # AI总结
    if ai_content:
        lines.append("━━━━━━━━━━━━━━━━━━━━")
        lines.append("")
        lines.append("🤖 AI智能总结")
        lines.append("")
        lines.append("  " + ai_content.replace("\n", "\n  "))
        lines.append("")

    lines.append("━━━━━━━━━━━━━━━━━━━━")
    lines.append("")
    lines.append("💡 待跟进承诺请及时处理,避免超时")
    return "\n".join(lines)


def run_server(port=DEFAULT_PORT, open_browser=True):
    global ACTIVE_PORT
    ACTIVE_PORT = port
    db.init_db()
    wa_official.ensure_settings()   # 官方通道:首次运行自动生成 webhook 验证口令
    autoimport.start_background()   # 自动导入:收件夹里有导出文件就自动入库(零成本)
    notify.start_background()   # 软件内提醒的后台扫描线程(纯代码,零 token)
    aiworker.start_background()  # 边聊边跑的 AI 识别队列(本地模型,零成本)

    # 本地 AI 模型:开机自动拉起(内置,不用手动开)
    def _boot_ai():
        try:
            info = ai.ensure_local(wait=180)
            if info.get("started"):
                print("  本地 AI 模型:已自动启动 ✅")
            elif info.get("ok"):
                print("  本地 AI 模型:已就绪(或未配置本地模型)")
            else:
                print("  本地 AI 模型:未启动(%s)" % info.get("detail"))
        except Exception as exc:
            print("  本地 AI 模型启动失败:", exc)
    threading.Thread(target=_boot_ai, daemon=True).start()

    # WhatsApp 桥接:开机只“尝试连一次”,不强制、不绕过停手原因。
    # 目的:补收关机期间的消息(WhatsApp 重连时会把窗口内的离线消息推上来)。
    # 若上次是被登出/403/同号别处登录硬停手,或依赖缺失 → 不自动拉起,等人工点按钮。
    def _boot_bridge():
        try:
            import subprocess as _sp
            bdir = os.path.join(db.PROJECT_DIR, "bridge")
            kp = os.path.join(bdir, "keepalive.py")
            if not os.path.exists(kp):
                print("  WhatsApp 桥接:未找到 keepalive.py,跳过")
                return
            if _bridge_side_alive():
                print("  WhatsApp 桥接:已在运行 ✅")
                return
            ok, why = _boot_bridge_allowed()
            if not ok:
                print("  WhatsApp 桥接:不自动拉起 ——", why)
                return
            if not _spawn_allowed():
                print("  WhatsApp 桥接:另一个拉起动作正在进行,本次跳过")
                return
            _sp.Popen([sys.executable, kp], cwd=bdir, env=_bridge_env(),
                      stdout=_sp.DEVNULL, stderr=_sp.DEVNULL, **_detached())
            print("  WhatsApp 桥接:开机连接一次(用于补收关机期间消息)")
        except Exception as exc:
            print("  WhatsApp 桥接启动失败:", exc)
    threading.Thread(target=_boot_bridge, daemon=True).start()

    # 轻量看门狗:只救"进程意外死掉",不救"活着但连不上"(后者交给 bridge.js 自己 5→15→30 分钟慢速重连)。
    # 【根因修法 2026-11-03 · 白名单】不再维护"哪些死因不许拉"的黑名单。
    #   黑名单的问题是:每新增一种死因就得补一条,漏补一个就误拉第二份(治标不治本)。
    #   改为只看一条:进程死了 且 已配对 且 **没有任何停手原因(stopped 为空)** 且 没被手动停止。
    #   · 意外崩溃:状态里 stopped 为空 → 拉(这才是真该救的);
    #   · 任何主动停手(logged-out/403/440/411/machine-locked/以后新增的任何原因)都会写 stopped
    #     → 一律不拉。未知死因天然 fail-safe,机器锁/端口占用这两个"本机已有另一份"也自动被排除。
    #   另受 24h ≤3 次 + 间隔 ≥30 分钟 限制,防止崩溃循环变成高频拉起。
    def _bridge_watchdog():
        import time as _t
        lifts = []
        while True:
            try:
                if not _bridge_side_alive(timeout=1):
                    bdir = os.path.join(db.PROJECT_DIR, "bridge")
                    why = str(_bridge_status().get("stopped") or "")
                    pause = os.path.join(bdir, ".watchdog_pause")
                    if (_bridge_paired() and why == '' and not os.path.exists(pause)):
                        now = _t.time()
                        lifts = [x for x in lifts if now - x < 24 * 3600]
                        if len(lifts) < 3 and (not lifts or now - lifts[-1] >= 30 * 60):
                            kp = os.path.join(bdir, "keepalive.py")
                            # 与开机线程/按钮互斥:只有真要拉了才占用 15 秒闸门,避免空占
                            if os.path.exists(kp) and _spawn_allowed():
                                lifts.append(now)
                                print("  WhatsApp 桥接看门狗:进程意外退出(无停手原因),自动拉起(24h 内第 %d 次)" % len(lifts))
                                # 走 keepalive 的"自动"路径(不带 --start):它会再确认一次
                                # "有停手原因就不拉",与这里的白名单形成双保险。
                                subprocess.Popen([sys.executable, kp], cwd=bdir,
                                                 env=_bridge_env(), stdout=subprocess.DEVNULL,
                                                 stderr=subprocess.DEVNULL, **_detached())
            except Exception:
                pass
            _t.sleep(300)   # 每 5 分钟巡检一次
    threading.Thread(target=_bridge_watchdog, daemon=True).start()

    # 清理软件重启前遗留的running翻译任务(线程已没了,状态卡在running)
    def _cleanup_stale_translation_tasks():
        try:
            con = db.connect()
            cur = con.execute(
                "UPDATE translation_tasks SET status='cancelled', updated_at=? WHERE status='running'",
                (db.now_iso(),)
            )
            con.commit()
            n = cur.rowcount
            con.close()
            if n > 0:
                print(f"  翻译任务:已清理 {n} 个遗留的运行中任务")
        except Exception as e:
            print(f"  翻译任务清理失败: {e}")
    _cleanup_stale_translation_tasks()

    # 日报总结:每日7点自动生成(本地AI)
    threading.Thread(target=_daily_report_loop, daemon=True).start()

    handler = lambda *a, **kw: Api(*a, **kw)
    host = _get_host()
    httpd = ThreadingHTTPServer((host, port), handler)
    print("=" * 52)
    print("  外贸客户工作台 v%s(本地版)已启动" % APP_VERSION)
    print("  操作台地址: http://127.0.0.1:%d" % port)
    if _boss_enabled():
        print("  老板模式:已开启(局域网可访问 http://<本机IP>:%d)" % port)
    print("  数据文件:   %s" % db.DB_PATH)
    print("  按 Ctrl+C 退出")
    print("=" * 52)
    if open_browser:
        def _open():
            url = f"http://127.0.0.1:{port}"
            if not _open_app_window(url):   # 优先“应用模式”(像客户端)
                webbrowser.open(url)        # 退回到普通浏览器
        threading.Timer(1.0, _open).start()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n已退出,数据都已保存在本地。")
