"""客户分级 —— 本地 AI 框架（提示词在 prompts/classify.md，待验收后填写）。

为什么单独一个模块:
  旧做法是"跟着手机 WhatsApp 的标签走" —— 标签由人工在手机上打,桥接每次连上
  都要把标签事件同步一遍(既多请求,又依赖别人的操作习惯)。现在改成"本地判断":
  消息、跟进记录、客户档案都在本机,不需要向 WhatsApp 要任何东西。

安全约束(防"自动泛滥",写死):
  1. 默认**不自动**跑:只有 explicit 调用(界面点"重新判断")才执行。
  2. 每客户每天最多 MAX_PER_DAY 次,超过直接拒绝(不排队、不重试)。
  3. 提示词文件为空/未填写 → 直接返回"未配置",不调用模型(避免乱判污染档案)。
  4. 只会写 customers 的 grade/stage/followup_category/grade_reason 四个字段。
"""

import json
import os
import re
from datetime import datetime

from . import ai
from . import db
from . import log

PROMPT_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                           "prompts", "classify.md")
MAX_PER_DAY = 3          # 同一客户每天最多手动判断次数(防连点/防跑飞)
MSG_LIMIT = 20           # 上下文只用最近 20 条消息


def prompt_text():
    """读提示词正文;去掉以 '>' 开头的说明行,避免把注释放进模型。"""
    try:
        with open(PROMPT_FILE, "r", encoding="utf-8") as f:
            raw = f.read()
    except OSError:
        return ""
    lines = [ln for ln in raw.splitlines() if not ln.strip().startswith(">")]
    return "\n".join(lines).strip()


def prompt_ready():
    """提示词是否已经填过(占位符 '（待填写）' 还在就不算)。"""
    txt = prompt_text()
    if len(txt) < 80:
        return False
    return "待填写" not in txt


def status():
    return {"prompt_ready": prompt_ready(),
            "ai_enabled": bool(ai.enabled()),
            "max_per_day": MAX_PER_DAY,
            "prompt_path": PROMPT_FILE}


def _recent_messages(customer_id, limit=MSG_LIMIT):
    rows = db.list_messages(customer_id, limit=limit) or []
    out = []
    for m in rows:
        out.append({
            "ts": m.get("ts") or "",
            "dir": "我方" if m.get("direction") == "out" else "客户",
            "who": m.get("sender_name") or m.get("sender_phone") or "",
            "text": (m.get("content") or "")[:200],
        })
    return out


def _context(customer_id):
    cust = db.get_customer(customer_id) or {}
    return {
        "customer": {k: cust.get(k) for k in
                     ("name", "country", "stage", "grade", "product", "notes",
                      "last_contact_at", "next_followup_at") if k in cust},
        "messages": _recent_messages(customer_id),
        "stages": list(db.STAGES),
        "grades": list(db.GRADES),
    }


def _daily_count(customer_id):
    """用 ai_log 计数(不新建表):只数 task='classify' 的记录。"""
    try:
        from datetime import date
        day = date.today().isoformat()
        con = db.connect()
        try:
            r = con.execute(
                "SELECT COUNT(*) c FROM ai_log WHERE task='classify'"
                " AND customer_id=? AND substr(created_at,1,10)=?",
                (customer_id, day)).fetchone()
            return int(r["c"] if r else 0)
        finally:
            con.close()
    except Exception as e:
        log.swallow("classifier.daily_count", e)
        return 0


def _parse_json(text):
    """模型可能带 ```json 包装,做一次容错解析。"""
    t = (text or "").strip()
    t = re.sub(r"^```(?:json)?", "", t).strip()
    t = re.sub(r"```$", "", t).strip()
    m = re.search(r"\{[\s\S]*\}", t)
    if not m:
        return None
    try:
        return json.loads(m.group(0))
    except ValueError:
        return None


def run(customer_id, force=False):
    """对一个客户做一次分级判断。返回 {ok, updated, reason, raw}。"""
    customer_id = int(customer_id or 0)
    if not customer_id:
        return {"ok": False, "reason": "缺少客户 ID"}
    if not ai.enabled():
        return {"ok": False, "reason": "本地 AI 未启用(设置里开启后再用)"}
    if not prompt_ready():
        return {"ok": False, "reason": "提示词未配置(app/prompts/classify.md)"}
    n = _daily_count(customer_id)
    if n >= MAX_PER_DAY:
        return {"ok": False, "reason": "今日判断次数已用完(%d/%d)" % (n, MAX_PER_DAY)}

    ctx = _context(customer_id)
    prompt = prompt_text()
    user = (prompt
            + "\n\n## 客户档案\n" + json.dumps(ctx["customer"], ensure_ascii=False)
            + "\n\n## 最近消息\n" + json.dumps(ctx["messages"], ensure_ascii=False))
    try:
        raw = ai._call_api([
            {"role": "system", "content": "你是外贸客户分级助手,只输出 JSON。"},
            {"role": "user", "content": user},
        ], allow_cloud=False)
    except Exception as e:
        log.swallow("classifier.call_api", e)
        return {"ok": False, "reason": "模型调用失败: %s" % e}

    data = _parse_json(raw) or {}
    grade = str(data.get("grade") or "").strip()
    stage = str(data.get("stage") or "").strip()
    cat = str(data.get("followup_category") or "").strip()
    reason = str(data.get("reason") or "").strip()[:80]

    upd = {}
    if grade in db.GRADES:
        upd["grade"] = grade
    if stage in db.STAGES:
        upd["stage"] = stage
    if cat:
        upd["followup_category"] = cat
    if reason:
        upd["grade_reason"] = reason
    if not upd:
        return {"ok": False, "reason": "模型输出无法解析", "raw": (raw or "")[:300]}

    db.update_customer(customer_id, upd)
    try:
        db.add_ai_log(customer_id, "classify",
                      json.dumps(upd, ensure_ascii=False), "", "ok",
                      (data.get("reason") or "")[:80])
    except Exception as e:
        log.swallow("classifier.log_ai", e)
    return {"ok": True, "updated": upd, "raw": (raw or "")[:300]}
