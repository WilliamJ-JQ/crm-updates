# -*- coding: utf-8 -*-
"""桥接看护 / 开关(纯代码,零 token)。

  python keepalive.py            # 检查桥接,不在就拉起一次(不管开机还是人工点击)
  python keepalive.py --status   # 只看状态
  python keepalive.py --stop     # 停止(优先调用 8767 的 /shutdown,不闪窗)
  python keepalive.py --force    # 忽略“已停手”标记与最短间隔(仅人工“重新扫码/拉起”用)

设计原则(对应“不封号 + 断开提示 + 人工拉起”):
  1. 这里**只拉起一次**,不做常驻轮询 —— 断线后由 bridge.js 自己限速恢复,超出上限就停手;
  2. 停手原因(status.json 的 stopped)会拦住自动拉起,避免“拉起→被拒→再拉起”刷接口;
  3. 全程不弹控制台窗口:不用 PowerShell、不用 taskkill,子进程一律 CREATE_NO_WINDOW。
"""
import argparse
import json
import os
import shutil
import signal
import subprocess
import sys
import time
import urllib.error
import urllib.request

PROJECT = os.path.dirname(os.path.abspath(__file__))
PIDFILE = os.path.join(PROJECT, "bridge.pid")
LOGFILE = os.path.join(PROJECT, "bridge.log")
STATUS = os.path.join(PROJECT, "status.json")
SIDE_PORT = int(os.environ.get("WA_SIDE_PORT", "8767"))

# 这些停手原因必须人工处理(重新扫码 / 确认账号),任何自动路径都不许拉起。
PAIR_NEEDED = {"logged-out", "qr-expired", "device-mismatch", "pair-failed"}
HARD_STOP = {"logged-out", "forbidden-403", "conflict", "device-mismatch", "pair-failed"}
# 软停手(网络/频率问题):人工点“拉起桥接”可以重来,开机不再自动拉起。
SOFT_STOP = {"too-many-failures", "reconnect-rate-limit", "qr-expired",
             "awaiting-pair-request", "bridge-failed", "bridge-deps-missing",
             "side-port-busy"}


def _node_exe():
    """node 可执行文件:优先随包的便携版(<包根>/node/node.exe),否则用 PATH 里的 node。"""
    if os.name == "nt":
        cand = os.path.join(os.path.dirname(PROJECT), "node", "node.exe")
        if os.path.exists(cand):
            return cand
    return shutil.which("node") or "node"


def side_alive(timeout=2):
    """桥接的本地小接口(127.0.0.1:SIDE_PORT)在响应 = 进程活着。跨平台,不依赖 /proc。"""
    try:
        urllib.request.urlopen("http://127.0.0.1:%d/groups" % SIDE_PORT, timeout=timeout)
        return True
    except urllib.error.HTTPError:
        return True                     # 有 HTTP 响应就算活着
    except Exception:
        return False


# ---------------- 进程判活 / 停止(Windows 走 ctypes,不产生控制台窗口) -------------
def _pid_alive(pid):
    if not pid or pid <= 0:
        return False
    if os.name == "nt":
        try:
            import ctypes
            from ctypes import wintypes
            k = ctypes.windll.kernel32
            h = k.OpenProcess(0x1000, False, int(pid))   # PROCESS_QUERY_LIMITED_INFORMATION
            if not h:
                return False
            code = wintypes.DWORD()
            ok = k.GetExitCodeProcess(h, ctypes.byref(code))
            k.CloseHandle(h)
            return bool(ok) and code.value == 259        # STILL_ACTIVE
        except Exception:
            return False
    try:
        os.kill(int(pid), 0)
        return True
    except Exception:
        return False


def _kill_pid(pid):
    if os.name == "nt":
        try:
            import ctypes
            k = ctypes.windll.kernel32
            h = k.OpenProcess(0x0001, False, int(pid))   # PROCESS_TERMINATE
            if h:
                k.TerminateProcess(h, 1)
                k.CloseHandle(h)
                return True
        except Exception:
            pass
        return False
    try:
        os.kill(int(pid), signal.SIGTERM)
        return True
    except Exception:
        return False


def _read_pid():
    try:
        with open(PIDFILE, encoding="utf-8") as f:
            return int((f.read() or "0").strip() or 0)
    except Exception:
        return 0


def _write_pid(pid):
    try:
        with open(PIDFILE, "w", encoding="utf-8") as f:
            f.write(str(pid))
    except Exception:
        pass


def alive():
    """只认“本地接口有响应”,不再用命令行扫描(旧实现每次调用都弹一个 PowerShell 黑窗)。"""
    return side_alive()


def linked(timeout=3):
    """桥接是否已连上 WhatsApp(status.json 里的 linked 字段)。"""
    try:
        with open(STATUS, encoding="utf-8") as f:
            return bool(json.load(f).get("linked"))
    except Exception:
        return False


def status_info():
    """读 status.json 的完整状态(连不上/停手原因/更新时间)。"""
    try:
        with open(STATUS, encoding="utf-8") as f:
            return json.load(f) or {}
    except Exception:
        return {}


def stopped_reason():
    return str(status_info().get("stopped") or "")


def _last_start():
    try:
        with open(os.path.join(PROJECT, "last_start.txt"), encoding="utf-8") as f:
            return float(f.read().strip() or 0)
    except Exception:
        return 0.0


def _note_start():
    try:
        with open(os.path.join(PROJECT, "last_start.txt"), "w", encoding="utf-8") as f:
            f.write(str(time.time()))
    except Exception:
        pass


def _write_status(payload):
    """启动失败时也要给界面一个能看懂的状态(而不是让旧“在线”继续骗人)。"""
    if alive():
        return                                   # 已有实例在跑,绝不覆盖它的状态
    payload = dict(payload or {})
    payload.setdefault("linked", False)
    payload.setdefault("qr", False)
    # 与 bridge.js 保持一致:用 UTC,主服务按 UTC 计算“多久没更新”
    payload["updated"] = time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime())
    try:
        with open(STATUS, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False)
    except Exception:
        pass


def _log(line):
    try:
        with open(LOGFILE, "ab") as f:
            f.write(("[keepalive] " + line + "\n").encode("utf-8", "replace"))
    except Exception:
        pass


def _tail_log(n=16):
    try:
        with open(LOGFILE, "rb") as f:
            data = f.read()[-4000:]
        lines = [x for x in data.decode("utf-8", "replace").splitlines() if x.strip()]
        return lines[-n:]
    except Exception:
        return []


def _npm_cmd():
    if os.name == "nt":
        p = os.path.join(os.path.dirname(PROJECT), "node", "npm.cmd")
        if os.path.exists(p):
            return p
        return "npm.cmd"
    return "npm"


def _deps_ok():
    """关键依赖在不在(避免“半装”被当成装好)。"""
    nm = os.path.join(PROJECT, "node_modules")
    return os.path.isdir(os.path.join(nm, "@whiskeysockets", "baileys"))


def _npm_run(args, logf):
    """执行 npm。Windows 上 .cmd 必须经 cmd /c 才能跑。"""
    npm = _npm_cmd()
    cmd = [npm] + args
    if os.name == "nt":
        cmd = ["cmd", "/c"] + cmd
    logf.write(("[deps] run: %s\n" % " ".join(cmd)).encode("utf-8", "replace"))
    _kw = {"creationflags": 0x08000000} if os.name == "nt" else {}
    subprocess.run(cmd, cwd=PROJECT, stdout=logf, stderr=logf, timeout=900, **_kw)


def ensure_deps():
    """装桥接依赖(node_modules)。已装好则秒过;先国内镜像,失败再回退官方源。"""
    if _deps_ok():
        return True
    manifest = os.path.join(PROJECT, "package.json")
    if not os.path.exists(manifest):
        # 没有 package.json 时 npm install 什么也装不了 —— 直接说清楚,别让人等 3 分钟。
        _log("[deps] 缺少 bridge/package.json,npm 无法安装依赖")
        return False
    nm = os.path.join(PROJECT, "node_modules")
    regs = [os.environ.get("WA_NPM_REGISTRY", "https://registry.npmmirror.com"),
            "https://registry.npmjs.org"]
    try:
        with open(LOGFILE, "ab") as logf:
            logf.write(b"\n[deps] ensure bridge dependencies ...\n")
            for i, reg in enumerate(regs):
                if i and os.path.isdir(nm):
                    shutil.rmtree(nm, ignore_errors=True)   # 换源前清掉半装
                try:
                    _npm_run(["install", "--no-audit", "--no-fund",
                              "--registry=" + reg], logf)
                except Exception as e:
                    logf.write(("[deps] %s 失败: %s\n" % (reg, e)).encode("utf-8", "replace"))
                if _deps_ok():
                    break
    except Exception:
        pass
    return _deps_ok()


def _win_system_proxy():
    """读取 Windows 系统代理设置(规则模式 VPN 会写这里)。返回 http://host:port 或空串。"""
    if os.name != "nt":
        return ""
    try:
        import winreg
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                             r"Software\Microsoft\Windows\CurrentVersion\Internet Settings")
        enable, _ = winreg.QueryValueEx(key, "ProxyEnable")
        if not enable:
            winreg.CloseKey(key)
            return ""
        server, _ = winreg.QueryValueEx(key, "ProxyServer")
        winreg.CloseKey(key)
        server = (server or "").strip()
        if not server:
            return ""
        if "=" in server:
            for part in server.split(";"):
                if part.strip().lower().startswith("https="):
                    server = part.split("=", 1)[1].strip()
                    break
                if part.strip().lower().startswith("http="):
                    server = part.split("=", 1)[1].strip()
        if not server.startswith("http"):
            server = "http://" + server
        return server
    except Exception:
        return ""


def _rotate_log(max_bytes=5 * 1024 * 1024, keep=2):
    """日志轮转:超过 5MB 就把 bridge.log 滚成 .1(保留 2 份)。
    以前是单文件无限追加,一次事故就 1MB+ 且没时间戳,排查只能靠文件修改时间猜。
    """
    try:
        if not os.path.exists(LOGFILE) or os.path.getsize(LOGFILE) < max_bytes:
            return
        for i in range(keep, 0, -1):
            src = LOGFILE if i == 1 else "%s.%d" % (LOGFILE, i - 1)
            dst = "%s.%d" % (LOGFILE, i)
            if os.path.exists(src):
                if os.path.exists(dst):
                    os.remove(dst)
                os.replace(src, dst)
    except Exception:
        pass


def start():
    """拉起 node bridge.js。返回 pid;失败返回 0,并把原因写进 status.json / bridge.log。"""
    _rotate_log()
    if not ensure_deps():
        why = ("缺少 bridge/node_modules(且无法用 npm 安装)。"
               "请重新安装完整包,或把 bridge/node_modules 一起复制过来。")
        _write_status({"stopped": "bridge-deps-missing", "reason": why})
        _log("[start] 依赖缺失,已放弃拉起 —— " + why)
        return 0

    # 【防双连】本地接口已有响应 = 已经有一份在跑,绝不再拉起第二份。
    # (并发两条 --start 的极端情况由 bridge.js 的整机锁兜底)
    if alive():
        _log("[start] 本地接口已有响应 → 已有桥接在运行,不重复拉起(避免同号双连)")
        return 0

    node = _node_exe()
    if node == "node" or not os.path.exists(node):
        import shutil as _sh
        if not _sh.which("node"):
            why = "找不到 Node 运行时(既没有 node/node.exe,系统 PATH 里也没有 node)。"
            _write_status({"stopped": "bridge-deps-missing", "reason": why})
            _log("[start] " + why)
            return 0

    kwargs = {}
    if os.name == "nt":
        # CREATE_NO_WINDOW | CREATE_NEW_PROCESS_GROUP(不用 DETACHED_PROCESS:它与重定向句柄常出问题)
        kwargs["creationflags"] = 0x08000000 | 0x00000200
    else:
        kwargs["start_new_session"] = True

    # 代理:优先用调用方传入的 WA_PROXY(软件设置里配的);
    # 没配时**跟随 Windows 系统代理**(很多 PM 用 Clash/VPN 的规则模式,只写注册表)。
    env = os.environ.copy()
    env["WA_SIDE_PORT"] = str(SIDE_PORT)
    if not env.get("WA_PROXY", "").strip():
        sys_proxy = _win_system_proxy()
        if sys_proxy:
            env["WA_PROXY"] = sys_proxy

    _log("starting node=%s cwd=%s deps_ok=%s proxy=%s side_port=%s"
         % (node, PROJECT, _deps_ok(), env.get("WA_PROXY", "(direct)"), SIDE_PORT))
    try:
        with open(LOGFILE, "ab") as logf:
            proc = subprocess.Popen(
                [node, "bridge.js"], cwd=PROJECT, stdout=logf, stderr=logf,
                stdin=subprocess.DEVNULL, env=env, **kwargs)
    except Exception as e:
        why = "拉起 node 失败:%s" % e
        _write_status({"stopped": "bridge-failed", "reason": why})
        _log("[start] " + why)
        return 0

    _write_pid(proc.pid)
    _note_start()

    # 等它起来:接口有响应 = 进程已在正常待命(是否连上另看 status.json 的 linked);
    # 进程还活着但没接口 = 正在等扫码/连接。
    # 进程直接退出 = 真失败(node 报错),把原因写清楚,别让人对着“没二维码”猜。
    deadline = time.time() + 10
    while time.time() < deadline:
        if side_alive(timeout=1):
            return proc.pid
        rc = proc.poll()
        if rc is not None:
            why = "node 启动后立即退出(code=%s)。最后几行日志:%s" % (rc, " / ".join(_tail_log(6)))
            _write_status({"stopped": "bridge-failed", "reason": why})
            _log("[start] " + why)
            return 0
        time.sleep(0.5)
    return proc.pid


def stop():
    """优雅停止:优先请求 /shutdown;不行再按 PID 文件精确结束(不扫命令行、不用 taskkill)。
    只有在“端口仍有人监听”时才按 PID 收尾 —— 避免误杀一个被复用了 PID 的无关进程。"""
    was_alive = side_alive(timeout=2)
    try:
        urllib.request.urlopen("http://127.0.0.1:%d/shutdown" % SIDE_PORT, timeout=3)
        _log("已请求 /shutdown (端口 %d)" % SIDE_PORT)
    except Exception:
        pass
    for _ in range(12):
        if not side_alive(timeout=1):
            break
        time.sleep(0.5)
    still = side_alive(timeout=1)
    pid = _read_pid()
    if still and _pid_alive(pid):
        # 还在监听 = 确实是本目录这一份桥接(旧版没有 /shutdown)→ 才允许按 PID 结束
        _kill_pid(pid)
        _log("优雅停止失败,已按 PID 结束 %s" % pid)
    try:
        if os.path.exists(PIDFILE):
            os.remove(PIDFILE)
    except Exception:
        pass
    return pid if was_alive else 0


def main():
    ap = argparse.ArgumentParser(description="WhatsApp 桥接看护")
    ap.add_argument("--status", action="store_true")
    ap.add_argument("--stop", action="store_true")
    ap.add_argument("--start", action="store_true", help="人工拉起(忽略软停手与最短间隔)")
    ap.add_argument("--force", action="store_true", help="同 --start,兼容旧调用")
    args = ap.parse_args()

    manual = bool(args.start or args.force)

    if args.status:
        if alive():
            print("OK: 桥接进程在运行 | 已连WhatsApp:", "是" if linked() else "否")
            return 0
        st = status_info()
        print("DEAD: 桥接没在运行 | stopped=%s | reason=%s"
              % (st.get("stopped") or "-", st.get("reason") or "-"))
        return 1

    if args.stop:
        killed = stop()
        print("已停止进程: %s" % killed if killed else "桥接本来就没在跑")
        return 0

    if alive():
        print("OK: 桥接已在运行,无需处理")
        return 0

    why = stopped_reason()

    # 人工点击:除了“必须重新扫码”的两种,都允许重新拉起(用户已明确要求人工拉起)
    if manual:
        if why in PAIR_NEEDED:
            print("需要重新扫码(原因: %s),不能直接拉起。" % why)
            return 2
        print("人工拉起桥接……(上次停手原因: %s)" % (why or "-"))
        pid = start()
        if not pid:
            print("拉起失败,详见 bridge/bridge.log")
            return 1
        print("OK: 已拉起,pid=%d(独立进程)" % pid)
        return 0

    # 自动路径(开机):只允许“没有停手原因”时拉起一次
    if why:
        print("桥接此前已停手(原因: %s),不自动拉起,等人工点【拉起桥接】。" % why)
        return 0

    gap = time.time() - _last_start()
    if gap < 120:
        print("距上次启动仅 %.0f 秒,先不重启(避免高频重试)。" % gap)
        return 0

    print("桥接未运行,正在拉起……")
    pid = start()
    if not pid:
        print("拉起失败,详见 bridge/bridge.log")
        return 1
    print("OK: 已拉起,pid=%d(独立进程)" % pid)
    return 0


if __name__ == "__main__":
    sys.exit(main())
