# -*- coding: utf-8 -*-
"""外贸客户工作台 —— 启动入口。

运行:
  python main.py                # 启动后自动打开浏览器操作台
  python main.py --no-browser   # 只启动服务(不弹浏览器)
  python main.py --port 9000    # 换端口

说明:界面是本地网页(只在你电脑上),数据全在本地 data/crm.db。
"""
import argparse

from app import server


def main():
    p = argparse.ArgumentParser(description="外贸客户工作台(本地版)")
    p.add_argument("--port", type=int, default=server.DEFAULT_PORT,
                   help=f"本地端口(默认 {server.DEFAULT_PORT})")
    p.add_argument("--no-browser", action="store_true",
                   help="启动后不自动打开浏览器")
    args = p.parse_args()
    server.run_server(port=args.port, open_browser=not args.no_browser)


if __name__ == "__main__":
    main()
