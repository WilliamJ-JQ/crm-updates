# -*- coding: utf-8 -*-
"""本地数据库层:SQLite 单文件,零第三方依赖。

所有客户资料、聊天流水、提醒、设置都存本地 data/crm.db,数据不出这台电脑。
备份 = 复制这一个文件。
"""
import json
import os
import re
import secrets
import sqlite3
from datetime import datetime

PROJECT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_DB = os.path.join(PROJECT_DIR, "data", "crm.db")
DB_PATH = os.environ.get("CRM_DB", DEFAULT_DB)

# 看板阶段(按推进顺序)
STAGES = ["新询盘", "方案讨论中", "报价中", "谈价中", "生产中", "交付中"]
# 客户身份(自动推导,可手改)
IDENTITIES = ["未识别", "业主", "建筑商", "中介", "设计师", "采购商", "其他"]
# 客户分级 A/B/C(跟进节奏)
GRADES = ["未分级", "A", "B", "C"]
GRADE_LABELS = {
    "A": "A级·高意向(本月内能付款)",
    "B": "B级·周期较长(需一段时间才能付款)",
    "C": "C级·机会渺茫或一年以上",
}
# 跟进内容分类
FOLLOWUP_CATEGORIES = ["", "等待客户确认", "挑选款式", "待我出方案/搭配",
                       "待我报价", "待客户付款", "待发货", "其他"]

# 提醒状态机
R_SUGGESTED = "suggested"   # 系统建议,等你在界面点"批准"
R_APPROVED = "approved"     # 已批准,到点提醒
R_CANCELLED = "cancelled"   # 已取消
R_DONE = "done"             # 已处理完

SCHEMA = """
CREATE TABLE IF NOT EXISTS customers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    company TEXT DEFAULT '',
    country TEXT DEFAULT '',
    phone TEXT DEFAULT '',
    email TEXT DEFAULT '',
    source TEXT DEFAULT '',
    product TEXT DEFAULT '',
    stage TEXT DEFAULT '新询盘',
    identity TEXT DEFAULT '未识别',
    timezone TEXT DEFAULT '',
    grade TEXT DEFAULT '未分级',
    followup_category TEXT DEFAULT '',
    last_contact_at TEXT DEFAULT '',
    next_followup_at TEXT DEFAULT '',
    grade_reason TEXT DEFAULT '',
    notes TEXT DEFAULT '',
    created_at TEXT,
    updated_at TEXT
);
CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id INTEGER NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
    direction TEXT NOT NULL DEFAULT 'in',
    content TEXT NOT NULL,
    tags TEXT DEFAULT '[]',
    ts TEXT,
    created_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_messages_customer ON messages(customer_id);
CREATE TABLE IF NOT EXISTS reminders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id INTEGER NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
    kind TEXT DEFAULT '跟进',
    note TEXT DEFAULT '',
    days INTEGER,
    notify_date TEXT,
    status TEXT DEFAULT 'suggested',
    created_at TEXT,
    decided_at TEXT,
    quote TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_reminders_status ON reminders(status);
CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT
);
CREATE TABLE IF NOT EXISTS notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    key TEXT UNIQUE,
    kind TEXT DEFAULT '',
    text TEXT DEFAULT '',
    customer_id INTEGER,
    read INTEGER DEFAULT 0,
    created_at TEXT
);
CREATE TABLE IF NOT EXISTS msg_queue (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    message_id INTEGER UNIQUE,
    customer_id INTEGER,
    status TEXT DEFAULT 'pending',
    kind TEXT DEFAULT '',
    promise TEXT DEFAULT '',
    created_at TEXT,
    processed_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_msgq_status ON msg_queue(status);
CREATE TABLE IF NOT EXISTS reminder_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    reminder_id INTEGER,
    customer_id INTEGER,
    action TEXT DEFAULT '',
    prev_status TEXT DEFAULT '',
    new_status TEXT DEFAULT '',
    note TEXT DEFAULT '',
    created_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_rlog_reminder ON reminder_log(reminder_id);

CREATE TABLE IF NOT EXISTS ai_queue (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    key TEXT UNIQUE,
    customer_id INTEGER,
    field TEXT DEFAULT '',
    snippet TEXT DEFAULT '',
    reason TEXT DEFAULT '',
    status TEXT DEFAULT 'pending',
    created_at TEXT
);
CREATE TABLE IF NOT EXISTS ai_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id INTEGER,
    task TEXT DEFAULT '',
    result TEXT DEFAULT '',
    quote TEXT DEFAULT '',
    status TEXT DEFAULT 'ok',
    detail TEXT DEFAULT '',
    created_at TEXT
);
CREATE TABLE IF NOT EXISTS knowledge (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    category TEXT DEFAULT '公司档案',
    title TEXT NOT NULL,
    content TEXT DEFAULT '',
    tags TEXT DEFAULT '',
    source TEXT DEFAULT '',
    version INTEGER DEFAULT 1,
    status TEXT DEFAULT 'active',
    created_at TEXT,
    updated_at TEXT
);
CREATE TABLE IF NOT EXISTS catalog (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    department TEXT NOT NULL,
    category TEXT DEFAULT '',
    keywords TEXT DEFAULT '',
    price_min REAL,
    price_max REAL,
    currency TEXT DEFAULT 'USD',
    unit TEXT DEFAULT '',
    lead_time TEXT DEFAULT '',
    moq TEXT DEFAULT '',
    sm_owner TEXT DEFAULT '',
    notes TEXT DEFAULT '',
    status TEXT DEFAULT 'active',
    updated_at TEXT
);
CREATE TABLE IF NOT EXISTS customer_docs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id INTEGER NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
    category TEXT DEFAULT '需求详情',
    title TEXT NOT NULL,
    content TEXT DEFAULT '',
    quote TEXT DEFAULT '',
    source TEXT DEFAULT 'code',
    status TEXT DEFAULT 'active',
    msg_id INTEGER,
    created_at TEXT,
    updated_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_docs_customer ON customer_docs(customer_id);
CREATE INDEX IF NOT EXISTS idx_docs_category ON customer_docs(category);
CREATE TABLE IF NOT EXISTS customer_brief (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id INTEGER NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
    sections TEXT DEFAULT '{}',
    model TEXT DEFAULT '',
    item_count INTEGER DEFAULT 0,
    created_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_brief_customer ON customer_brief(customer_id);
CREATE TABLE IF NOT EXISTS customer_profile (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id INTEGER NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
    sections TEXT DEFAULT '{}',
    model TEXT DEFAULT '',
    created_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_profile_customer ON customer_profile(customer_id);
-- 我方团队名册(PM / SM / 运营):用于区分“我方谁发的”与“客户发的”。
-- 客户总是海外号;SM/同事都在国内(+86),以前被当噪音丢掉 —— 现在按名册登记
-- 后,他们的回复也计入“我方已回复”,并标明是谁回的。
CREATE TABLE IF NOT EXISTS team_members (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    phone TEXT DEFAULT '',
    name TEXT DEFAULT '',
    role TEXT DEFAULT 'SM',
    note TEXT DEFAULT '',
    active INTEGER DEFAULT 1,
    created_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_team_phone ON team_members(phone);
-- 会话(群聊名)→ 客户 的归属:运营拉的客户群,群里多人发言都归到同一个客户档案
CREATE TABLE IF NOT EXISTS chat_links (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_ref TEXT UNIQUE,
    customer_id INTEGER REFERENCES customers(id) ON DELETE CASCADE,
    created_at TEXT
);
-- 客户方相关人(客户自带的设计师 / 采购 / 同事 / 家人):并入客户档案但**不混为本人**
CREATE TABLE IF NOT EXISTS persons (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id INTEGER NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
    phone TEXT DEFAULT '',
    name TEXT DEFAULT '',
    role TEXT DEFAULT '其他',
    note TEXT DEFAULT '',
    source TEXT DEFAULT 'auto',
    created_at TEXT,
    updated_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_persons_customer ON persons(customer_id);
CREATE INDEX IF NOT EXISTS idx_persons_phone ON persons(phone);
-- 合并客户的留痕:记下这次合并搬走了哪些行 → 误合并可一键撒回(不能只靠数据库备份)
CREATE TABLE IF NOT EXISTS merge_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    src_id INTEGER,
    dst_id INTEGER,
    role TEXT DEFAULT '其他',
    note TEXT DEFAULT '',
    src_json TEXT DEFAULT '{}',    -- 被合并客户的整行快照(含姓名/号码/分级)
    moved_json TEXT DEFAULT '{}',  -- 搬走/改属的行 id:{表名: [id,...], chat_links:[...]}
    snaps_json TEXT DEFAULT '{}',  -- 随档案级联删除、需重建的行(customer_brief/profile/persons)
    person_id INTEGER,             -- 合并时在 dst 名下建的“相关人”行
    reverted INTEGER DEFAULT 0,
    created_at TEXT,
    reverted_at TEXT
);
"""

# 非词表类的系统设置默认值
META_DEFAULTS = {
    "reminder_lead_default": "1",   # 承诺提醒:提前几天提醒(例:3天内报价→提前1天)
    "night_auto": "0",              # 夜间自动回复总开关(阶段4功能,当前恒为关闭)
    "grade_cadence_A": "2",         # A级:每 2 天跟进一次
    "grade_cadence_B": "3",         # B级:约每 3 天跟进一次(一周 2~3 次)
    "grade_cadence_C": "7",         # C级:每周跟进一次
    "notify_interval_seconds": "60",  # 软件内提醒检查间隔(秒)
    "ingest_token": "",             # 外部收信桥接令牌(首次启动自动生成)
    "ai_enabled": "0",              # AI 增强总开关(默认关)
    "ai_api_key": "",               # DeepSeek 密钥(存本机,不出门)
    "ai_model": "deepseek-chat",
    "ai_base_url": "https://api.deepseek.com",
    "ai_daily_limit": "15",         # 每日 AI 处理上限(条)
    "docs_auto": "1",              # 收到消息自动抽取客户文档(代码通道,零 token)
    "docs_ai_auto": "0",           # 客户文档的 AI 通道自动开关(默认关,手动点)
}

# 知识库分类(文档型)
KB_CATEGORIES = ["公司档案", "组织与角色", "业务流程", "价格与条款",
                 "客户规则", "话术库", "术语对照", "收录规则"]
KB_STATUS_ACTIVE = "active"
KB_STATUS_PENDING = "pending"

# 客户文档分类(结构化提炼,不是聊天流水)
DOC_CATEGORIES = ["需求详情", "产品规格", "数量与预算", "时间与交期",
                  "价格与条款", "物流与目的地", "决策与角色",
                  "偏好与标准", "顾虑与障碍", "下一步行动", "客户背景"]
DOC_STATUS_ACTIVE = "active"
DOC_STATUS_ARCHIVED = "archived"


def now_iso():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def today_iso():
    return datetime.now().strftime("%Y-%m-%d")


def connect(db_path=None):
    path = db_path or DB_PATH
    parent = os.path.dirname(path)
    if parent:
        os.makedirs(parent, exist_ok=True)
    con = sqlite3.connect(path)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    return con


def init_db(db_path=None):
    """建表 + 补齐默认设置。任何程序启动前都应调用一次(幂等)。"""
    from . import keywords
    con = connect(db_path)
    con.executescript(SCHEMA)
    _migrate(con)
    for key, value in keywords.DEFAULT_GROUPS.items():
        if get_setting(key, "", con=con) == "":
            set_setting(key, value, con=con)
    for key, value in META_DEFAULTS.items():
        if get_setting(key, "", con=con) == "":
            set_setting(key, value, con=con)
    # 桥接收信令牌:首次启动自动生成(让外部 WhatsApp 桥接可以安全推送消息)
    if get_setting("ingest_token", "", con=con) == "":
        set_setting("ingest_token", secrets.token_hex(12), con=con)
    # 知识库首次种入初始条目(规则/模板),以后你改的版本不会再被覆盖
    if con.execute("SELECT COUNT(*) n FROM knowledge").fetchone()["n"] == 0:
        from . import kb_seed
        now = now_iso()
        for item in kb_seed.SEED_ITEMS:
            con.execute(
                "INSERT INTO knowledge(category,title,content,tags,source,version,"
                "status,created_at,updated_at) VALUES(?,?,?,?,?,1,?,?,?)",
                (item.get("category", KB_CATEGORIES[0]), item["title"],
                 item.get("content", ""), item.get("tags", ""),
                 item.get("source", ""), KB_STATUS_ACTIVE, now, now))
    # 产品目录首次种入 14 个部门
    if con.execute("SELECT COUNT(*) n FROM catalog").fetchone()["n"] == 0:
        from . import catalog_seed
        now = now_iso()
        for d in catalog_seed.DEPARTMENTS:
            con.execute(
                "INSERT INTO catalog(department,category,keywords,notes,status,"
                "updated_at) VALUES(?,?,?,?,?,?)",
                (d.get("department", ""), d.get("category", ""),
                 d.get("keywords", ""), d.get("notes", ""),
                 KB_STATUS_ACTIVE, now))
    con.commit()
    con.close()


# ---------- settings ----------

def get_setting(key, default="", con=None):
    own = con is None
    if own:
        con = connect()
    try:
        row = con.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return row["value"] if row else default
    finally:
        if own:
            con.close()


def set_setting(key, value, con=None):
    own = con is None
    if own:
        con = connect()
    try:
        con.execute("INSERT OR REPLACE INTO settings(key, value) VALUES(?,?)", (key, value))
        if own:
            con.commit()
    finally:
        if own:
            con.close()


def get_group_terms(key):
    """把设置里的词表文本拆成干净的关键词列表(去重、去空)。"""
    raw = get_setting(key, "")
    out = []
    for part in raw.replace("\n", ",").split(","):
        p = part.strip()
        if p and p not in out:
            out.append(p)
    return out


def all_settings():
    con = connect()
    try:
        rows = con.execute("SELECT key, value FROM settings").fetchall()
        return {r["key"]: r["value"] for r in rows}
    finally:
        con.close()


# ---------- customers ----------

_CUSTOMER_FIELDS = ("name", "company", "country", "phone", "email", "source",
                    "product", "stage", "identity", "timezone", "grade",
                    "followup_category", "next_followup_at", "notes")


_CUSTOMER_COLS = ("identity", "timezone", "grade", "followup_category",
                 "last_contact_at", "next_followup_at", "grade_reason",
                 "stage_reason", "followup_reason")


def _migrate(con):
    """为旧库补充新增列 / 清理废弃列(幂等)。"""
    cols = {r["name"] for r in con.execute("PRAGMA table_info(customers)").fetchall()}
    for c in _CUSTOMER_COLS:
        if c not in cols:
            default = "未识别" if c == "identity" else ("未分级" if c == "grade" else "")
            con.execute(f"ALTER TABLE customers ADD COLUMN {c} TEXT DEFAULT '{default}'")
    rcols = {r["name"] for r in con.execute("PRAGMA table_info(reminders)").fetchall()}
    if "quote" not in rcols:
        con.execute("ALTER TABLE reminders ADD COLUMN quote TEXT DEFAULT ''")
    # 承诺审批卡片需要:原话时间 / 谁发的 / 中文译文 / 是否系统直判
    for col in ("src_ts", "src_direction", "quote_zh", "auto"):
        if col not in rcols:
            con.execute("ALTER TABLE reminders ADD COLUMN %s TEXT DEFAULT ''" % col)
    # 待跟进自动关闭:我方回复哪条 / 回复内容 / 判定状态
    for col in ("reply_msg_id", "reply_quote", "reply_state", "reply_checked_at",
                "reply_ts", "src_msg_id", "decided_by", "reply_reason",
                "reply_by", "reply_role"):
        if col not in rcols:
            con.execute("ALTER TABLE reminders ADD COLUMN %s TEXT DEFAULT ''" % col)
    # 消息来源标记:私聊 direct / 群聊 group(+群名或对方号码)
    mcols = {r["name"] for r in con.execute("PRAGMA table_info(messages)").fetchall()}
    for col in ("source", "source_ref", "sender_phone", "sender_name", "sender_role"):
        if col not in mcols:
            con.execute("ALTER TABLE messages ADD COLUMN %s TEXT DEFAULT ''" % col)
    # 通知已读时间(read_at):”我什么时候读过什么“要能查
    ncols = {r["name"] for r in con.execute("PRAGMA table_info(notifications)").fetchall()}
    if "read_at" not in ncols:
        con.execute("ALTER TABLE notifications ADD COLUMN read_at TEXT DEFAULT ''")
    # 后台队列:记录重试次数(防止单条坏消息被无限重试 → 一直烧 CPU)
    qcols = {r["name"] for r in con.execute("PRAGMA table_info(msg_queue)").fetchall()}
    if "attempts" not in qcols:
        con.execute("ALTER TABLE msg_queue ADD COLUMN attempts INTEGER DEFAULT 0")
    # 质量字段已废弃(改用 A/B/C 分级);旧库清掉它,不影响新库
    if "quality" in cols:
        try:
            con.execute("ALTER TABLE customers DROP COLUMN quality")
        except sqlite3.OperationalError:
            pass  # 老版 SQLite 不支持 DROP COLUMN:留着也无害(代码已不用)


def _clean_stage(v):
    return v if v in STAGES else STAGES[0]


def _clean_identity(v):
    return v if v in IDENTITIES else IDENTITIES[0]


def _clean_grade(v):
    return v if v in GRADES else GRADES[0]


def create_customer(data):
    con = connect()
    try:
        now = now_iso()
        cur = con.execute(
            "INSERT INTO customers(name, company, country, phone, email, source, product,"
            " stage, identity, timezone, grade, followup_category, notes,"
            " created_at, updated_at)"
            " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (str(data.get("name", "")).strip(),
             str(data.get("company", "")).strip(),
             str(data.get("country", "")).strip(),
             str(data.get("phone", "")).strip(),
             str(data.get("email", "")).strip(),
             str(data.get("source", "")).strip(),
             str(data.get("product", "")).strip(),
             _clean_stage(data.get("stage") or STAGES[0]),
             _clean_identity(data.get("identity") or IDENTITIES[0]),
             str(data.get("timezone", "")),
             _clean_grade(data.get("grade") or GRADES[0]),
             str(data.get("followup_category", "")),
             str(data.get("notes", "")),
             now, now))
        con.commit()
        return cur.lastrowid
    finally:
        con.close()


def get_customer(cid):
    con = connect()
    try:
        row = con.execute("SELECT * FROM customers WHERE id=?", (cid,)).fetchone()
        return dict(row) if row else None
    finally:
        con.close()


def update_customer(cid, data, move=None):
    """move: 'next'/'prev' 表示看板上推进/后退一个阶段(返回新 stage)。"""
    con = connect()
    try:
        if move:
            row = con.execute("SELECT stage FROM customers WHERE id=?", (cid,)).fetchone()
            if not row:
                return None
            cur_stage = row["stage"]
            idx = STAGES.index(cur_stage) if cur_stage in STAGES else -1
            new_idx = min(len(STAGES) - 1, idx + 1) if move == "next" else max(0, idx - 1)
            new_stage = STAGES[new_idx]
            con.execute("UPDATE customers SET stage=?, updated_at=? WHERE id=?",
                        (new_stage, now_iso(), cid))
            con.commit()
            return new_stage
        fields = {k: v for k, v in data.items() if k in _CUSTOMER_FIELDS and k != "name"}
        if data.get("name") is not None:
            fields["name"] = str(data["name"]).strip()
        if not fields:
            return None
        if "stage" in fields:
            fields["stage"] = _clean_stage(fields["stage"])
        if "identity" in fields:
            fields["identity"] = _clean_identity(fields["identity"])
        if "grade" in fields:
            fields["grade"] = _clean_grade(fields["grade"])
        fields["updated_at"] = now_iso()
        sets = ", ".join(f"{k}=?" for k in fields)
        con.execute(f"UPDATE customers SET {sets} WHERE id=?", (*fields.values(), cid))
        con.commit()
        return True
    finally:
        con.close()


def delete_customer(cid):
    con = connect()
    try:
        con.execute("DELETE FROM customers WHERE id=?", (cid,))
        con.commit()
    finally:
        con.close()


# ---------- 我方团队名册(PM / SM / 运营) ----------
# 客户总是海外号;SM 和国内同事都是 +86。以前桥接直接把 +86 当噪音丢掉,
# 结果“SM 在群里回了客户”这件事在跟进系统里完全看不见。
# 现在:名册里的号 = 我方,消息照常入库(direction=out),并标明是谁回的。
TEAM_ROLES = ["PM", "SM", "运营", "其他"]
PERSON_ROLES = ["设计师", "采购", "同事", "家人", "客户本人", "其他"]
_ROLE_KEY = {"PM": "pm", "SM": "sm", "运营": "team", "其他": "team"}


def _norm_phone(p):
    d = _digits(p)
    return d


def list_team():
    con = connect()
    try:
        rows = con.execute(
            "SELECT * FROM team_members ORDER BY CASE role WHEN 'PM' THEN 0"
            " WHEN 'SM' THEN 1 ELSE 2 END, id").fetchall()
        return [dict(r) for r in rows]
    finally:
        con.close()


def find_team_by_phone(phone):
    """按号码找团队成员(容错:国家码/空格/前导 0)。找不到返回 None。"""
    d = _norm_phone(phone)
    if len(d) < 7:
        return None
    key = d[-9:] if len(d) >= 9 else d
    con = connect()
    try:
        for r in con.execute("SELECT * FROM team_members WHERE active IS NOT 0"):
            tp = _norm_phone(r["phone"])
            if len(tp) < 7:
                continue
            tkey = tp[-9:] if len(tp) >= 9 else tp
            if tkey == key or tp.endswith(d) or d.endswith(tp):
                return dict(r)
        return None
    finally:
        con.close()


def role_key(role):
    """名册角色 → 消息里的 sender_role 键(pm/sm/team)。"""
    return _ROLE_KEY.get((role or "").strip(), "team")


def note_pending_team(phone, name=""):
    """记下“在客户群里说过话、但不在我方名册”的国内号 —— 等 PM 一键确认。

    以前这种号直接被丢掉,结果运营给客户建的“资料卡”群一条都进不来(实测某运营 14 条全丢)。
    """
    d = _digits(phone)
    if len(d) < 7:
        return
    try:
        items = json.loads(get_setting("pending_team", "[]"))
    except (ValueError, TypeError):
        items = []
    for it in items:
        if _digits(it.get("phone", "")) == d:
            it["hits"] = int(it.get("hits", 0)) + 1
            it["name"] = it.get("name") or name or ""
            set_setting("pending_team", json.dumps(items, ensure_ascii=False))
            return
    items.append({"phone": "+" + d, "name": name or "", "hits": 1,
                  "seen": now_iso()})
    set_setting("pending_team", json.dumps(items[-50:], ensure_ascii=False))


def list_pending_team():
    try:
        return json.loads(get_setting("pending_team", "[]"))
    except (ValueError, TypeError):
        return []


def clear_pending_team(phone):
    d = _digits(phone)
    items = [i for i in list_pending_team() if _digits(i.get("phone", "")) != d]
    set_setting("pending_team", json.dumps(items, ensure_ascii=False))


def add_team_member(data):
    con = connect()
    try:
        cur = con.execute(
            "INSERT INTO team_members(phone,name,role,note,active,created_at)"
            " VALUES(?,?,?,?,?,?)",
            (_norm_phone(data.get("phone")), (data.get("name") or "").strip(),
             data.get("role") if data.get("role") in TEAM_ROLES else "SM",
             (data.get("note") or "").strip(),
             0 if data.get("active") in (0, "0", False) else 1, now_iso()))
        con.commit()
        return cur.lastrowid
    finally:
        con.close()


def update_team_member(tid, data):
    con = connect()
    try:
        fields = {}
        if "phone" in data:
            fields["phone"] = _norm_phone(data["phone"])
        if "name" in data:
            fields["name"] = (data["name"] or "").strip()
        if "role" in data and data["role"] in TEAM_ROLES:
            fields["role"] = data["role"]
        if "note" in data:
            fields["note"] = (data["note"] or "").strip()
        if "active" in data:
            fields["active"] = 0 if data["active"] in (0, "0", False) else 1
        if not fields:
            return False
        sets = ", ".join(f"{k}=?" for k in fields)
        con.execute(f"UPDATE team_members SET {sets} WHERE id=?",
                    (*fields.values(), tid))
        con.commit()
        return True
    finally:
        con.close()


def delete_team_member(tid):
    con = connect()
    try:
        con.execute("DELETE FROM team_members WHERE id=?", (tid,))
        con.commit()
    finally:
        con.close()


# ---------- 会话(群)→ 客户 归属 ----------

def get_chat_customer(chat_ref):
    """某个群/会话归属哪个客户;没绑定返回 None。"""
    ref = (chat_ref or "").strip()
    if not ref:
        return None
    con = connect()
    try:
        row = con.execute(
            "SELECT c.* FROM chat_links l JOIN customers c ON c.id=l.customer_id"
            " WHERE l.chat_ref=?", (ref,)).fetchone()
        return dict(row) if row else None
    finally:
        con.close()


def link_chat(chat_ref, customer_id):
    ref = (chat_ref or "").strip()
    if not ref or not customer_id:
        return None
    con = connect()
    try:
        con.execute(
            "INSERT INTO chat_links(chat_ref,customer_id,created_at) VALUES(?,?,?)"
            " ON CONFLICT(chat_ref) DO UPDATE SET customer_id=excluded.customer_id",
            (ref, customer_id, now_iso()))
        con.commit()
        return True
    finally:
        con.close()


def links_for_customer(customer_id):
    con = connect()
    try:
        rows = con.execute("SELECT * FROM chat_links WHERE customer_id=?",
                           (customer_id,)).fetchall()
        return [dict(r) for r in rows]
    finally:
        con.close()


# ---------- 客户方相关人(设计师/采购/同事/家人) ----------

def list_persons(customer_id=None):
    con = connect()
    try:
        if customer_id is None:
            rows = con.execute("SELECT * FROM persons ORDER BY id").fetchall()
        else:
            rows = con.execute("SELECT * FROM persons WHERE customer_id=? ORDER BY id",
                               (customer_id,)).fetchall()
        return [dict(r) for r in rows]
    finally:
        con.close()


# 群名匹配时忽略的通用词(公司名/业务词,几乎所有群名都有)
_GROUP_STOP = {"george", "group", "vip", "deco", "decoration", "project",
               "house", "furniture", "villa", "office", "采购", "全案", "翻新",
               "别墅", "项目", "家具", "灯具", "设计"}


def match_customer_by_group_name(chat_name):
    """用地名/群名把群绑到已有客户。

    运营建群的习惯是“把客户名写进群名”(如 “7.25丨VIP—某客户 菲律宾”),
    所以群名里能找到哪个客户的名字,这个群就是他的。找不到返回 None。
    """
    name = (chat_name or "").strip().lower()
    if len(name) < 4:
        return None
    best, best_len = None, 0
    for c in list_customers():
        cn = (c.get("name") or "").strip().lower()
        if len(cn) < 3 or cn in _GROUP_STOP:
            continue
        if re.search(r"\d{5,}", cn):        # 名字本身就是一串号码 → 跳过
            continue
        if cn in name and len(cn) > best_len:
            best, best_len = c, len(cn)
    return best


def find_person_by_phone(phone):
    """全局按号码找『相关人』(客户自带的设计师/同事)。

    用途:合并后那个人(如某客户的设计师)没有自己的客户档案了,
    但他/她再发消息时必须能回到原客户名下,而**不是又建一份新档案**。
    """
    d = _digits(phone)
    if len(d) < 7:
        return None
    key = d[-9:] if len(d) >= 9 else d
    con = connect()
    try:
        for r in con.execute("SELECT * FROM persons"):
            pp = _digits(r["phone"])
            if len(pp) < 7:
                continue
            pkey = pp[-9:] if len(pp) >= 9 else pp
            if pkey == key or pp.endswith(d) or d.endswith(pp):
                return dict(r)
        return None
    finally:
        con.close()


def find_person(customer_id, phone):
    d = _norm_phone(phone)
    if not d:
        return None
    key = d[-9:] if len(d) >= 9 else d
    con = connect()
    try:
        for r in con.execute("SELECT * FROM persons WHERE customer_id=?",
                             (customer_id,)):
            pp = _norm_phone(r["phone"])
            if not pp:
                continue
            pkey = pp[-9:] if len(pp) >= 9 else pp
            if pkey == key or pp.endswith(d) or d.endswith(pp):
                return dict(r)
        return None
    finally:
        con.close()


def upsert_person(customer_id, phone, name="", role="其他", note="",
                  source="auto"):
    """相关人入库:同号只保留一条;人工改过的角色不被自动覆盖。"""
    role = role if role in PERSON_ROLES else "其他"
    p = find_person(customer_id, phone)
    con = connect()
    try:
        if p:
            new_role = p["role"]
            if p.get("source") != "human" and role != "其他":
                new_role = role
            con.execute(
                "UPDATE persons SET name=CASE WHEN ?<>'' THEN ? ELSE name END,"
                " role=?, note=CASE WHEN ?<>'' THEN ? ELSE note END, updated_at=?"
                " WHERE id=?",
                ((name or ""), (name or ""), new_role, (note or ""), (note or ""),
                 now_iso(), p["id"]))
            con.commit()
            return get_person(p["id"])
        cur = con.execute(
            "INSERT INTO persons(customer_id,phone,name,role,note,source,created_at,"
            " updated_at) VALUES(?,?,?,?,?,?,?,?)",
            (customer_id, _norm_phone(phone), name or "", role, note or "", source,
             now_iso(), now_iso()))
        con.commit()
        return get_person(cur.lastrowid)
    finally:
        con.close()


def get_person(pid):
    con = connect()
    try:
        row = con.execute("SELECT * FROM persons WHERE id=?", (pid,)).fetchone()
        return dict(row) if row else None
    finally:
        con.close()


def update_person(pid, data):
    con = connect()
    try:
        fields = {}
        if "name" in data:
            fields["name"] = (data["name"] or "").strip()
        if "role" in data and data["role"] in PERSON_ROLES:
            fields["role"] = data["role"]
        if "note" in data:
            fields["note"] = (data["note"] or "").strip()
        if not fields:
            return False
        fields["source"] = "human"      # 人工设过 → 以后自动识别不再覆盖
        fields["updated_at"] = now_iso()
        sets = ", ".join(f"{k}=?" for k in fields)
        con.execute(f"UPDATE persons SET {sets} WHERE id=?", (*fields.values(), pid))
        con.commit()
        return True
    finally:
        con.close()


def delete_person(pid):
    con = connect()
    try:
        con.execute("DELETE FROM persons WHERE id=?", (pid,))
        con.commit()
    finally:
        con.close()


# ---------- 合并客户(同人两号 / 客户自带设计师) ----------

# 合并时要改属的行(带 customer_id 列)
_MERGE_MOVE_TABLES = ("messages", "reminders", "customer_docs", "notifications",
                      "ai_log", "msg_queue", "ai_queue")
# 随客户行级联删除、需快照才能重建的表
_MERGE_SNAP_TABLES = ("customer_brief", "customer_profile", "persons")


def _insert_dict(con, table, data, keep_id=False):
    """把一行 dict 插回表(用于撒销合并时重建快照行)。"""
    d = {k: v for k, v in data.items() if keep_id or k != "id"}
    cols = ", ".join(d.keys())
    ph = ", ".join("?" for _ in d)
    cur = con.execute(f"INSERT INTO {table}({cols}) VALUES({ph})", list(d.values()))
    return cur.lastrowid


def merge_customers(src_id, dst_id, role="其他", note=""):
    """把 src 客户并进 dst 客户:消息/文档/提醒/通知全搬过去,
    src 以“相关人”身份保留在 dst 档案里(**不抹掉身份区别**),然后删掉 src 档案。

    场景:客户的设计师自己先私聊加了我们(于是建了一份档案),
    后来发现他是某客户的设计师 —— 把他并进该客户档案并标『设计师』。

    每次合并都写一条 merge_log(含被搬走的行 id),所以**误合并可以一键撒回**
    (见 revert_merge)。
    """
    if not src_id or not dst_id or int(src_id) == int(dst_id):
        return None
    src = get_customer(src_id)
    dst = get_customer(dst_id)
    if not src or not dst:
        return None
    role = role if role in PERSON_ROLES else "其他"
    moved, snaps = {}, {}
    con = connect()
    try:
        for table in _MERGE_MOVE_TABLES:
            ids = [r["id"] for r in con.execute(
                f"SELECT id FROM {table} WHERE customer_id=?", (src_id,))]
            if ids:
                marks = ",".join("?" for _ in ids)
                con.execute(f"UPDATE {table} SET customer_id=? WHERE id IN ({marks})",
                            [dst_id] + ids)
            moved[table] = ids
        # 群聊归属跟着走(否则群会莫名其妙断掉)
        links = [dict(r) for r in con.execute(
            "SELECT chat_ref, customer_id FROM chat_links WHERE customer_id=?", (src_id,))]
        moved["chat_links"] = links
        if links:
            con.execute("UPDATE chat_links SET customer_id=? WHERE customer_id=?",
                        (dst_id, src_id))
        for table in _MERGE_SNAP_TABLES:
            snaps[table] = [dict(r) for r in con.execute(
                f"SELECT * FROM {table} WHERE customer_id=?", (src_id,))]
        con.execute("DELETE FROM customers WHERE id=?", (src_id,))
        con.commit()
    finally:
        con.close()
    # 相关人记录:保留被合并方的姓名/号码/身份
    info = "; ".join([x for x in [note,
                                  ("来自档案 #%s" % src_id),
                                  ("原来源:%s" % src["source"] if src.get("source") else "")]
                       if x])
    person = upsert_person(dst_id, src.get("phone") or "", src.get("name") or "",
                           role=role, note=info, source="human")
    mid = add_merge_log(src, dst_id, role, note, moved, snaps,
                        (person or {}).get("id"))
    return {"merge_id": mid, "moved": moved, "person": person, "dst": dst_id,
            "dst_name": dst.get("name")}


def add_merge_log(src, dst_id, role, note, moved, snaps, person_id=None):
    con = connect()
    try:
        cur = con.execute(
            "INSERT INTO merge_log(src_id,dst_id,role,note,src_json,moved_json,"
            "snaps_json,person_id,reverted,created_at) VALUES(?,?,?,?,?,?,?,?,0,?)",
            (src.get("id"), dst_id, role, note or "",
             json.dumps(src, ensure_ascii=False),
             json.dumps(moved, ensure_ascii=False),
             json.dumps(snaps, ensure_ascii=False), person_id, now_iso()))
        con.commit()
        return cur.lastrowid
    finally:
        con.close()


def list_merges(limit=50):
    """最近的合并记录(带 dst 客户名;src 名字从快照里取)。"""
    con = connect()
    try:
        rows = con.execute(
            "SELECT m.*, c.name AS dst_name FROM merge_log m"
            " LEFT JOIN customers c ON c.id=m.dst_id ORDER BY m.id DESC LIMIT ?",
            (limit,)).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            try:
                d["src_name"] = (json.loads(d.get("src_json") or "{}") or {}).get("name") or ""
            except (ValueError, TypeError):
                d["src_name"] = ""
            out.append(d)
        return out
    finally:
        con.close()


def get_merge(mid):
    con = connect()
    try:
        row = con.execute("SELECT * FROM merge_log WHERE id=?", (mid,)).fetchone()
        return dict(row) if row else None
    finally:
        con.close()


def revert_merge(mid):
    """撒销一次合并:按留痕把行 id 搬回、重建被并方档案(优先沿用原编号),
    删掉那条“相关人”,恢复群属。幂等:重复调用第二次返回 already。
    """
    row = get_merge(mid)
    if not row:
        return None
    if row.get("reverted"):
        return {"merge_id": mid, "already": True}
    src = json.loads(row.get("src_json") or "{}") or {}
    moved = json.loads(row.get("moved_json") or "{}") or {}
    snaps = json.loads(row.get("snaps_json") or "{}") or {}
    src_id, dst_id = row.get("src_id"), row.get("dst_id")
    con = connect()
    try:
        # 1) 重建被并方客户(原编号空着就沿用,否则自动分配新号)
        keep = not con.execute("SELECT 1 FROM customers WHERE id=?",
                               (src_id,)).fetchone()
        actual = _insert_dict(con, "customers", src, keep_id=bool(keep))
        if not keep:
            actual = int(actual)
        else:
            actual = int(src_id)
        # 2) 行改属搬回
        counts = {}
        for table in _MERGE_MOVE_TABLES:
            ids = [int(x) for x in (moved.get(table) or [])]
            if ids:
                marks = ",".join("?" for _ in ids)
                counts[table] = con.execute(
                    f"UPDATE {table} SET customer_id=? WHERE id IN ({marks})",
                    [actual] + ids).rowcount
        # 3) 群属搬回
        n_chat = 0
        for lk in (moved.get("chat_links") or []):
            n_chat += con.execute(
                "UPDATE chat_links SET customer_id=? WHERE chat_ref=?",
                (actual, lk.get("chat_ref"))).rowcount
        # 4) 快照行(画像/建档简报/当时的相关人)重建
        n_snap = 0
        for table in _MERGE_SNAP_TABLES:
            for r0 in (snaps.get(table) or []):
                d = dict(r0)
                d["customer_id"] = actual
                _insert_dict(con, table, d)   # 不保留原 id,避免冲突
                n_snap += 1
        # 5) 删掉合并时在 dst 名下建的那条“相关人”
        n_person = 0
        if row.get("person_id"):
            n_person = con.execute("DELETE FROM persons WHERE id=?",
                                   (row["person_id"],)).rowcount
        con.execute("UPDATE merge_log SET reverted=1, reverted_at=? WHERE id=?",
                    (now_iso(), mid))
        con.commit()
    finally:
        con.close()
    return {"merge_id": mid, "already": False, "customer_id": actual,
            "counts": counts, "chats": n_chat, "snaps": n_snap,
            "person_removed": n_person}


def list_customers(q=None):
    con = connect()
    try:
        sql = ("SELECT c.*, COUNT(DISTINCT m.id) AS msg_count, MAX(m.ts) AS last_ts,"
               " (SELECT COUNT(*) FROM customer_docs d WHERE d.customer_id=c.id"
               "  AND d.status='active') AS doc_count,"
               " (SELECT m2.content FROM messages m2 WHERE m2.customer_id=c.id"
               "  ORDER BY m2.ts DESC, m2.id DESC LIMIT 1) AS last_msg,"
               " (SELECT m3.direction FROM messages m3 WHERE m3.customer_id=c.id"
               "  ORDER BY m3.ts DESC, m3.id DESC LIMIT 1) AS last_dir"
               " FROM customers c LEFT JOIN messages m ON m.customer_id = c.id")
        args = []
        if q:
            like = f"%{q}%"
            sql += " WHERE c.name LIKE ? OR c.company LIKE ? OR c.country LIKE ?"
            args = [like, like, like]
        sql += " GROUP BY c.id ORDER BY c.updated_at DESC"
        rows = con.execute(sql, args).fetchall()
        return [dict(r) for r in rows]
    finally:
        con.close()


# ---------- messages ----------

def find_customer_by_name(name):
    """按名字找一个客户(去空格、不分区大小写)。找不到返回 None。

    用途:导入 .txt 时里面只有名字、没有号码 —— 若已有同名客户就归过去,
    避免开出一堆重复档案。
    """
    n = (name or "").strip().lower()
    if not n:
        return None
    con = connect()
    try:
        row = con.execute("SELECT * FROM customers WHERE LOWER(TRIM(name))=? LIMIT 1",
                          (n,)).fetchone()
        return dict(row) if row else None
    finally:
        con.close()


def _digits(s):
    return re.sub(r"\D", "", str(s or ""))


def same_phone(a, b):
    """两个号码是不是同一个人(末 9 位指纹;兼容国家码/前导 0/空格)。"""
    da, dbb = _digits(a), _digits(b)
    if len(da) < 7 or len(dbb) < 7:
        return False
    ka = da[-9:] if len(da) >= 9 else da
    kb = dbb[-9:] if len(dbb) >= 9 else dbb
    return ka == kb


def find_customer_by_phone(phone):
    """按手机号找客户(容错:国家码/前导 0/空格)。

    场景:群里是 +27 82 572 8798,私聊只显示 082 572 8798
    (当地号码用 0 代替了国家码)—— 必须能对上,否则同一人会开两份档案。
    做法:取**末 9 位**作指纹比较。
    """
    d = _digits(phone)
    if len(d) < 7:
        return None
    key = d[-9:] if len(d) >= 9 else d
    con = connect()
    try:
        for r in con.execute("SELECT * FROM customers"):
            cp = _digits(r["phone"])
            if len(cp) < 7:
                continue
            ckey = cp[-9:] if len(cp) >= 9 else cp
            if ckey == key or cp.endswith(d) or d.endswith(cp):
                return dict(r)
        return None
    finally:
        con.close()


def add_message(customer_id, direction, content, ts=None, tags=None,
                source="", source_ref="", sender_phone="", sender_name="",
                sender_role=""):
    """入库一条消息。

    sender_role 说明“这句话是谁说的”:
      customer=客户本人 / designer=客户方设计师 / other=客户方其他人
      pm=我(PM) / sm=销售经理(我方) / team=我方其他人
    我方(PM/SM)说的同样入库(direction=out),这样 SM 的回复也能计入“已回复”。
    """
    con = connect()
    try:
        if ts is None:
            ts = now_iso()
        # 【去重】历史同步会把同一批消息重发(实测积了 308 条重复);
        # 重复会让“按 id 排序”的时间轴变乱,所以入库前先查一遍。
        dup = con.execute(
            "SELECT id FROM messages WHERE customer_id=? AND ts=? AND direction=?"
            " AND content=? LIMIT 1",
            (customer_id, ts,
             direction if direction in ("in", "out") else "in", content)).fetchone()
        if dup:
            return dup["id"]
        cur = con.execute(
            "INSERT INTO messages(customer_id, direction, content, tags, ts, created_at,"
            " source, source_ref, sender_phone, sender_name, sender_role)"
            " VALUES(?,?,?,?,?,?,?,?,?,?,?)",
            (customer_id, direction if direction in ("in", "out") else "in",
             content, json.dumps(tags or [], ensure_ascii=False), ts, now_iso(),
             source or "", source_ref or "", sender_phone or "", sender_name or "",
             sender_role or ""))
        con.execute("UPDATE customers SET updated_at=? WHERE id=?", (now_iso(), customer_id))
        con.commit()
        return cur.lastrowid
    finally:
        con.close()


def get_message(mid):
    con = connect()
    try:
        row = con.execute("SELECT m.*, c.name AS customer_name FROM messages m"
                          " JOIN customers c ON c.id = m.customer_id WHERE m.id=?",
                          (mid,)).fetchone()
        return dict(row) if row else None
    finally:
        con.close()


def update_message_tags(mid, tags):
    """校准词表后,重新识别某条消息时更新其标签。"""
    con = connect()
    try:
        con.execute("UPDATE messages SET tags=? WHERE id=?",
                    (json.dumps(tags or [], ensure_ascii=False), mid))
        con.commit()
    finally:
        con.close()
    return get_message(mid)


def _tags_list(v):
    """tags 在库里存的是 JSON 字符串(如 '["决策信号"]');接口必须返回**数组**。

    踩过的坑:返回字符串时前端调 (m.tags||[]).forEach 会抛 TypeError,
    导致「消息记录」整页空白(而且只在有标签的消息上炸)。
    """
    if isinstance(v, list):
        return v
    if v is None or v == "":
        return []
    try:
        d = json.loads(v)
        if isinstance(d, list):
            return d
        return [str(d)]
    except (ValueError, TypeError):
        s = str(v).strip()
        return [t.strip() for t in s.replace("、", ",").split(",") if t.strip()]


def last_message(customer_id):
    """取某客户**时间上最新**的一条消息。

    【坑】不能按 id 取:历史导入的消息 id 很大但时间很老,按 id 会取到“几天前客户那句话”,
    于是明明 PM 后面已经回过了,系统还报“客户在等回复”。所以一律按 ts 排。
    """
    con = connect()
    try:
        return con.execute(
            "SELECT * FROM messages WHERE customer_id=?"
            " ORDER BY IFNULL(ts,'') DESC, id DESC LIMIT 1", (customer_id,)).fetchone()
    finally:
        con.close()


def list_messages(customer_id=None, limit=300, around_id=None, span=25):
    """取消息。

    around_id: 只看这条消息附近的对话(追溯用)。
    ——踩过的坑:追溯一条很老的消息时,它不在“最新 300 条”里,
      页面上根本没渲染 → 定位不到。所以支持按 id 取窗口。
    """
    con = connect()
    try:
        if around_id is not None and customer_id is not None:
            rows = con.execute(
                "SELECT m.*, c.name AS customer_name FROM messages m"
                " JOIN customers c ON c.id = m.customer_id"
                " WHERE m.customer_id=? AND m.id BETWEEN ? AND ?"
                " ORDER BY m.ts, m.id",
                (customer_id, int(around_id) - span, int(around_id) + span)
            ).fetchall()
            out = []
            for r in rows:
                d = dict(r)
                d["tags"] = _tags_list(d.get("tags"))
                out.append(d)
            return out
        sql = ("SELECT m.*, c.name AS customer_name FROM messages m"
               " JOIN customers c ON c.id = m.customer_id")
        args = []
        if customer_id is not None:
            sql += " WHERE m.customer_id=?"
            args.append(customer_id)
        sql += " ORDER BY m.ts DESC, m.id DESC LIMIT ?"
        args.append(limit)
        rows = con.execute(sql, args).fetchall()
        out = []
        for r in reversed(rows):          # 旧→新排列
            d = dict(r)
            d["tags"] = _tags_list(d.get("tags"))
            out.append(d)
        return out
    finally:
        con.close()


# ---------- reminders ----------

def add_reminder(customer_id, kind, note, days=None, status=R_SUGGESTED,
                 notify_date=None, quote="", src_ts="", src_direction="",
                 auto="", src_msg_id=None, decided_by="code"):
    """新增提醒。

    decided_by: 这条是“谁判出来的” —— code=代码 / ai=本地AI / human=人工。
                调试期要能一眼看出 AI 有没有参与。
    """
    con = connect()
    try:
        if status == R_SUGGESTED:
            row = con.execute(
                "SELECT id FROM reminders WHERE customer_id=? AND kind=?"
                " AND status=? AND created_at >= datetime('now','localtime','-3 days')"
                " LIMIT 1", (customer_id, kind, R_SUGGESTED)).fetchone()
            if row:
                return row["id"]
        if status == R_APPROVED and auto:
            # 系统直判的自动待跟进:同客户同类型 2 天内只出一条,避免刷屏
            row = con.execute(
                "SELECT id FROM reminders WHERE customer_id=? AND kind=?"
                " AND status=? AND auto=? AND created_at >= datetime('now','localtime','-2 days')"
                " LIMIT 1", (customer_id, kind, R_APPROVED, auto)).fetchone()
            if row:
                return row["id"]
        cur = con.execute(
            "INSERT INTO reminders(customer_id, kind, note, days, notify_date,"
            " status, created_at, quote, src_ts, src_direction, auto, src_msg_id,"
            " decided_by) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (customer_id, kind, note, days, notify_date, status, now_iso(), quote,
             src_ts or "", src_direction or "", auto or "",
             src_msg_id if src_msg_id is not None else "", decided_by or "code"))
        con.commit()
        return cur.lastrowid
    finally:
        con.close()


def set_reminder_reply(rid, state, msg_id=None, quote=None, reason=None,
                       reply_by="", reply_role=""):
    """记录“我方是否已回复”的判定结果(连回复时间和**判定依据**一起存)。

    为什么存理由:只看结论 PM 没法信任;要能说出“为什么这么判”。
    reply_by/reply_role:是**谁**回的(我 PM / SM 张三 / 团队)—— 多个业务员进同一个群时,
    PM 要一眼看出这条已经被谁处理了。传空则不动原值。
    """
    ts = ""
    if msg_id:
        con2 = connect()
        try:
            row = con2.execute("SELECT ts FROM messages WHERE id=?",
                               (msg_id,)).fetchone()
            ts = (row["ts"] if row else "") or ""
        finally:
            con2.close()
    con = connect()
    try:
        sets = ["reply_state=?", "reply_msg_id=?", "reply_quote=?", "reply_ts=?",
                "reply_checked_at=?"]
        args = [state, msg_id if msg_id is not None else "", (quote or "")[:400], ts,
                now_iso()]
        if reason is not None:
            sets.append("reply_reason=?")
            args.append((reason or "")[:300])
        if reply_by:
            sets.append("reply_by=?")
            args.append(reply_by[:60])
        if reply_role:
            sets.append("reply_role=?")
            args.append(reply_role[:20])
        args.append(rid)
        con.execute("UPDATE reminders SET " + ", ".join(sets) + " WHERE id=?", args)
        con.commit()
    finally:
        con.close()


# ---------- 操作留痕(可追溯 + 可撤回) ----------

def log_reminder(rid, customer_id, action, prev_status="", new_status="",
                 note=""):
    con = connect()
    try:
        con.execute(
            "INSERT INTO reminder_log(reminder_id,customer_id,action,prev_status,"
            " new_status,note,created_at) VALUES(?,?,?,?,?,?,?)",
            (rid, customer_id, action, prev_status, new_status, note[:200],
             now_iso()))
        con.commit()
    finally:
        con.close()


def list_reminder_log(limit=60):
    """最近的操作历史(带客户名),用于界面“留痕 + 撤回”。"""
    con = connect()
    try:
        rows = con.execute(
            "SELECT l.*, c.name AS customer_name, r.kind, r.note AS r_note"
            " FROM reminder_log l LEFT JOIN customers c ON c.id=l.customer_id"
            " LEFT JOIN reminders r ON r.id=l.reminder_id"
            " ORDER BY l.id DESC LIMIT ?", (limit,)).fetchall()
        return [dict(r) for r in rows]
    finally:
        con.close()


def revert_reminder(rid, note="撤回"):
    """撤回:恢复到上一次操作前的状态(从日志里取)。"""
    con = connect()
    try:
        row = con.execute(
            "SELECT * FROM reminder_log WHERE reminder_id=? AND prev_status!=''"
            " ORDER BY id DESC LIMIT 1", (rid,)).fetchone()
        r = _reminder_row(con, rid)
        if not r:
            return {"status": "not-found"}
        if row:
            prev = row["prev_status"]
        else:
            # 老数据没历史(早前完成时没记 prev_status)→ 兜底:done 回到 approved(待跟进)
            prev = R_APPROVED if r["status"] == R_DONE else r["status"]
        con.execute("UPDATE reminders SET status=?, decided_at=? WHERE id=?",
                    (prev, now_iso(), rid))
        # 撤回到“待跟进”时,连回复判定一起清掉 —— 回到“未判定”,后续会重新判
        if prev == R_APPROVED:
            con.execute("UPDATE reminders SET decided_by='', reply_state='',"
                        " reply_msg_id='', reply_quote='', reply_reason='', reply_by='',"
                        " reply_role='', reply_ts='', reply_checked_at='' WHERE id=?",
                        (rid,))
        con.commit()
        rid_c = r["customer_id"]
    finally:
        con.close()
    log_reminder(rid, rid_c, "revert", r["status"], prev, note)
    return {"status": "ok", "restored": prev}


def clear_reminders(keep_days=0):
    """清掉所有提醒/待跟进(样本数据用)。消息、文档、客户都保留。"""
    con = connect()
    try:
        n = con.execute("SELECT COUNT(*) n FROM reminders").fetchone()["n"]
        con.execute("DELETE FROM reminders")
        con.execute("DELETE FROM reminder_log")
        con.execute("DELETE FROM msg_queue")
        con.commit()
        return n
    finally:
        con.close()


def delay_reminder_once(rid):
    """延时一天 —— 只允许一次,并在 note 里留痕“已延时一次”(可追溯、防无限拖)。"""
    from datetime import date as _d, timedelta as _td
    r = get_reminder(rid)
    if not r:
        return False, "", "", "提醒不存在"
    note = r.get("note") or ""
    if "已延时一次" in note:
        return False, r.get("notify_date") or "", note, "已经延时过一次(只允许再延一天一次)"
    base = (r.get("notify_date") or "")[:10]
    try:
        nd = (_d.fromisoformat(base) if base else _d.today()) + _td(days=1)
    except ValueError:
        nd = _d.today() + _td(days=1)
    new_note = note + " · 已延时一次"
    con = connect()
    try:
        con.execute("UPDATE reminders SET notify_date=?, note=? WHERE id=?",
                    (nd.isoformat(), new_note, rid))
        con.commit()
    finally:
        con.close()
    return True, nd.isoformat(), new_note, ""


def set_reminder_quote_zh(rid, zh):
    con = connect()
    try:
        con.execute("UPDATE reminders SET quote_zh=? WHERE id=?", (zh, rid))
        con.commit()
    finally:
        con.close()


def _reminder_row(con, rid):
    row = con.execute("SELECT * FROM reminders WHERE id=?", (rid,)).fetchone()
    return dict(row) if row else None


def get_reminder(rid):
    con = connect()
    try:
        return _reminder_row(con, rid)
    finally:
        con.close()


def list_reminders(status=None, customer_id=None, limit=300):
    con = connect()
    try:
        sql = ("SELECT r.*, c.name AS customer_name, c.company AS company"
               " FROM reminders r JOIN customers c ON c.id = r.customer_id")
        conds, args = [], []
        if status:
            conds.append("r.status=?")
            args.append(status)
        if customer_id is not None:
            conds.append("r.customer_id=?")
            args.append(customer_id)
        if conds:
            sql += " WHERE " + " AND ".join(conds)
        sql += " ORDER BY r.id DESC LIMIT ?"
        args.append(limit)
        rows = con.execute(sql, args).fetchall()
        return [dict(r) for r in rows]
    finally:
        con.close()


def set_reminder_status(rid, status, notify_date=None):
    con = connect()
    try:
        r = _reminder_row(con, rid)
        if not r:
            return None
        if notify_date is None:
            notify_date = r["notify_date"]
        con.execute(
            "UPDATE reminders SET status=?, notify_date=?, decided_at=? WHERE id=?",
            (status, notify_date, now_iso(), rid))
        con.commit()
        prev = r["status"]
        cid = r["customer_id"]
    finally:
        con.close()
    # 留痕:批准/取消/完成/重开 都记一笔,可追溯、可撤回
    if prev != status:
        log_reminder(rid, cid, "set_status", prev, status,
                     "%s → %s" % (prev, status))
    return get_reminder(rid)


def delete_reminder(rid):
    con = connect()
    try:
        con.execute("DELETE FROM reminders WHERE id=?", (rid,))
        con.commit()
    finally:
        con.close()


def due_reminders(on=None):
    """已批准且提醒日期 <= on(默认今天)的提醒 = 到点了。"""
    on = on or today_iso()
    con = connect()
    try:
        rows = con.execute(
            "SELECT r.*, c.name AS customer_name, c.company AS company"
            " FROM reminders r JOIN customers c ON c.id = r.customer_id"
            " WHERE r.status=? AND r.notify_date IS NOT NULL AND r.notify_date<=?"
            " ORDER BY r.notify_date ASC", (R_APPROVED, on)).fetchall()
        return [dict(r) for r in rows]
    finally:
        con.close()


# ---------- knowledge(知识库) ----------

def get_kb(kid):
    con = connect()
    try:
        row = con.execute("SELECT * FROM knowledge WHERE id=?", (kid,)).fetchone()
        return dict(row) if row else None
    finally:
        con.close()


def list_kb(category=None, limit=500):
    con = connect()
    try:
        sql = "SELECT * FROM knowledge"
        args = []
        if category:
            sql += " WHERE category=?"
            args.append(category)
        sql += " ORDER BY category, id"
        rows = con.execute(sql, args).fetchall()
        return [dict(r) for r in rows][:limit]
    finally:
        con.close()


def add_kb(category, title, content, tags="", source="",
           status=KB_STATUS_ACTIVE):
    con = connect()
    try:
        now = now_iso()
        cur = con.execute(
            "INSERT INTO knowledge(category,title,content,tags,source,version,"
            "status,created_at,updated_at) VALUES(?,?,?,?,?,1,?,?,?)",
            (category or KB_CATEGORIES[0], title, content, tags, source,
             status, now, now))
        con.commit()
        return cur.lastrowid
    finally:
        con.close()


def update_kb(kid, data):
    """修改条目:版本号自动 +1,留修改时间。"""
    con = connect()
    try:
        row = con.execute("SELECT * FROM knowledge WHERE id=?", (kid,)).fetchone()
        if not row:
            return None
        fields = {k: data[k] for k in ("category", "title", "content", "tags",
                                        "source", "status") if k in data}
        if not fields:
            return dict(row)
        fields["version"] = (row["version"] or 1) + 1
        fields["updated_at"] = now_iso()
        sets = ", ".join(f"{k}=?" for k in fields)
        con.execute(f"UPDATE knowledge SET {sets} WHERE id=?",
                    (*fields.values(), kid))
        con.commit()
    finally:
        con.close()
    return get_kb(kid)


def delete_kb(kid):
    con = connect()
    try:
        con.execute("DELETE FROM knowledge WHERE id=?", (kid,))
        con.commit()
    finally:
        con.close()


# ---------- catalog(产品目录:结构化) ----------

def get_catalog(cid):
    con = connect()
    try:
        row = con.execute("SELECT * FROM catalog WHERE id=?", (cid,)).fetchone()
        return dict(row) if row else None
    finally:
        con.close()


def list_catalog(department=None, limit=500):
    con = connect()
    try:
        sql = "SELECT * FROM catalog"
        args = []
        if department:
            sql += " WHERE department=?"
            args.append(department)
        sql += " ORDER BY id"
        rows = con.execute(sql, args).fetchall()
        return [dict(r) for r in rows][:limit]
    finally:
        con.close()


def _cat_price(v):
    if v is None or v == "":
        return None
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def add_catalog(data):
    con = connect()
    try:
        now = now_iso()
        cur = con.execute(
            "INSERT INTO catalog(department,category,keywords,price_min,price_max,"
            "currency,unit,lead_time,moq,sm_owner,notes,status,updated_at)"
            " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (str(data.get("department", "")).strip(),
             str(data.get("category", "")),
             str(data.get("keywords", "")),
             _cat_price(data.get("price_min")), _cat_price(data.get("price_max")),
             str(data.get("currency", "USD")), str(data.get("unit", "")),
             str(data.get("lead_time", "")), str(data.get("moq", "")),
             str(data.get("sm_owner", "")), str(data.get("notes", "")),
             KB_STATUS_ACTIVE, now))
        con.commit()
        return cur.lastrowid
    finally:
        con.close()


def update_catalog(cid, data):
    con = connect()
    try:
        row = con.execute("SELECT * FROM catalog WHERE id=?", (cid,)).fetchone()
        if not row:
            return None
        fields = {
            "department": str(data.get("department", row["department"])).strip(),
            "category": str(data.get("category", row["category"])),
            "keywords": str(data.get("keywords", row["keywords"])),
            "currency": str(data.get("currency", row["currency"] or "USD")),
            "unit": str(data.get("unit", row["unit"])),
            "lead_time": str(data.get("lead_time", row["lead_time"])),
            "moq": str(data.get("moq", row["moq"])),
            "sm_owner": str(data.get("sm_owner", row["sm_owner"])),
            "notes": str(data.get("notes", row["notes"])),
            "updated_at": now_iso(),
        }
        if "price_min" in data:
            fields["price_min"] = _cat_price(data.get("price_min"))
        if "price_max" in data:
            fields["price_max"] = _cat_price(data.get("price_max"))
        sets = ", ".join(f"{k}=?" for k in fields)
        con.execute(f"UPDATE catalog SET {sets} WHERE id=?", (*fields.values(), cid))
        con.commit()
    finally:
        con.close()
    return get_catalog(cid)


def delete_catalog(cid):
    con = connect()
    try:
        con.execute("DELETE FROM catalog WHERE id=?", (cid,))
        con.commit()
    finally:
        con.close()


def apply_profile(cid, **fields):
    """档案自动推导引擎写回客户(仅限推导字段)。"""
    allowed = ("identity", "timezone", "grade", "followup_category",
               "last_contact_at", "next_followup_at", "grade_reason", "country",
               "product", "stage", "stage_reason", "followup_reason")
    updates = {k: fields[k] for k in allowed if k in fields}
    if not updates:
        return get_customer(cid)
    updates["updated_at"] = now_iso()
    sets = ", ".join(f"{k}=?" for k in updates)
    con = connect()
    try:
        con.execute(f"UPDATE customers SET {sets} WHERE id=?", (*updates.values(), cid))
        con.commit()
    finally:
        con.close()
    return get_customer(cid)


def grade_cadence(grade):
    """A/B/C 级跟进周期(天),可在设置里改。"""
    default = {"A": "2", "B": "3", "C": "7"}.get(grade, "7")
    try:
        return int(get_setting(f"grade_cadence_{grade}", default) or default)
    except ValueError:
        return int(default)


# ---------- notifications(软件内提醒) ----------

def add_notification(key, kind, text, customer_id=None):
    con = connect()
    try:
        con.execute(
            "INSERT OR IGNORE INTO notifications(key,kind,text,customer_id,read,created_at)"
            " VALUES(?,?,?,?,0,?)", (key, kind, text, customer_id, now_iso()))
        con.commit()
    finally:
        con.close()


def notification_exists(key):
    con = connect()
    try:
        return con.execute("SELECT 1 FROM notifications WHERE key=?",
                           (key,)).fetchone() is not None
    finally:
        con.close()


def list_notifications(unread_only=False, limit=50):
    con = connect()
    try:
        sql = "SELECT * FROM notifications"
        if unread_only:
            sql += " WHERE read=0"
        sql += " ORDER BY id DESC LIMIT ?"
        rows = con.execute(sql, (limit,)).fetchall()
        return [dict(r) for r in rows]
    finally:
        con.close()


def mark_notifications_read(nid=None):
    """标记已读,并**留下已读时间**(read_at)—— “我什么时候读过什么”要看得到。"""
    con = connect()
    try:
        ts = now_iso()
        if nid:
            con.execute("UPDATE notifications SET read=1, read_at=? WHERE id=?", (ts, nid))
        else:
            con.execute("UPDATE notifications SET read=1, read_at=? WHERE read=0", (ts,))
        con.commit()
    finally:
        con.close()


def unread_count():
    con = connect()
    try:
        return con.execute("SELECT COUNT(*) n FROM notifications WHERE read=0"
                           ).fetchone()["n"]
    finally:
        con.close()


# ---------- customer_docs(客户文档:从对话提炼的高价值信息) ----------

def doc_exists(customer_id, category, title):
    """同一客户 + 同一分类 + 同一标题 已存在则不重复写(防刷屏)。"""
    con = connect()
    try:
        return con.execute(
            "SELECT 1 FROM customer_docs WHERE customer_id=? AND category=?"
            " AND title=? LIMIT 1",
            (customer_id, category, title)).fetchone() is not None
    finally:
        con.close()


def add_doc(customer_id, category, title, content, quote="", source="code",
            status=DOC_STATUS_ACTIVE, msg_id=None, dedupe=True):
    if dedupe and doc_exists(customer_id, category, title):
        return None
    con = connect()
    try:
        now = now_iso()
        cur = con.execute(
            "INSERT INTO customer_docs(customer_id,category,title,content,quote,"
            "source,status,msg_id,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
            (customer_id, category or DOC_CATEGORIES[0], title, content, quote,
             source, status, msg_id, now, now))
        con.commit()
        return cur.lastrowid
    finally:
        con.close()


def get_doc(did):
    con = connect()
    try:
        row = con.execute("SELECT * FROM customer_docs WHERE id=?", (did,)).fetchone()
        return dict(row) if row else None
    finally:
        con.close()


def list_docs(customer_id=None, category=None, limit=500,
              include_archived=False):
    con = connect()
    try:
        sql = ("SELECT d.*, c.name AS customer_name FROM customer_docs d"
               " LEFT JOIN customers c ON c.id=d.customer_id WHERE 1=1")
        args = []
        if customer_id:
            sql += " AND d.customer_id=?"
            args.append(customer_id)
        if category:
            sql += " AND d.category=?"
            args.append(category)
        if not include_archived:
            sql += " AND d.status=?"
            args.append(DOC_STATUS_ACTIVE)
        sql += " ORDER BY d.id DESC LIMIT ?"
        args.append(limit)
        return [dict(r) for r in con.execute(sql, args).fetchall()]
    finally:
        con.close()


def update_doc(did, data):
    con = connect()
    try:
        row = con.execute("SELECT * FROM customer_docs WHERE id=?", (did,)).fetchone()
        if not row:
            return None
        fields = {k: data[k] for k in ("category", "title", "content", "quote",
                                        "status") if k in data}
        if not fields:
            return dict(row)
        fields["updated_at"] = now_iso()
        sets = ", ".join(f"{k}=?" for k in fields)
        con.execute(f"UPDATE customer_docs SET {sets} WHERE id=?",
                    (*fields.values(), did))
        con.commit()
    finally:
        con.close()
    return get_doc(did)


def delete_doc(did):
    con = connect()
    try:
        con.execute("DELETE FROM customer_docs WHERE id=?", (did,))
        con.commit()
    finally:
        con.close()


def doc_counts():
    """按分类统计客户文档条数(看板用)。"""
    con = connect()
    try:
        rows = con.execute(
            "SELECT category, COUNT(*) n FROM customer_docs WHERE status=?"
            " GROUP BY category ORDER BY n DESC", (DOC_STATUS_ACTIVE,)).fetchall()
        return {r["category"]: r["n"] for r in rows}
    finally:
        con.close()


# ---------- customer_brief(精炼客户档案:AI 归纳的关键信息) ----------

def save_brief(customer_id, sections, model="", item_count=0):
    """存一份精炼档案(同一客户只留最新一份)。"""
    con = connect()
    try:
        con.execute("DELETE FROM customer_brief WHERE customer_id=?",
                    (customer_id,))
        cur = con.execute(
            "INSERT INTO customer_brief(customer_id,sections,model,item_count,"
            "created_at) VALUES(?,?,?,?,?)",
            (customer_id, json.dumps(sections, ensure_ascii=False), model,
             item_count, now_iso()))
        con.commit()
        return cur.lastrowid
    finally:
        con.close()


def get_brief(customer_id):
    con = connect()
    try:
        row = con.execute(
            "SELECT * FROM customer_brief WHERE customer_id=?"
            " ORDER BY id DESC LIMIT 1", (customer_id,)).fetchone()
        if not row:
            return None
        d = dict(row)
        try:
            d["sections"] = json.loads(d.get("sections") or "{}")
        except (ValueError, TypeError):
            d["sections"] = {}
        return d
    finally:
        con.close()


# ---------- customer_profile(客户画像文档:叙述式概况,供夜间自动回复用) ----------

def save_profile_doc(customer_id, sections, model=""):
    con = connect()
    try:
        con.execute("DELETE FROM customer_profile WHERE customer_id=?",
                    (customer_id,))
        cur = con.execute(
            "INSERT INTO customer_profile(customer_id,sections,model,created_at)"
            " VALUES(?,?,?,?)",
            (customer_id, json.dumps(sections, ensure_ascii=False), model,
             now_iso()))
        con.commit()
        return cur.lastrowid
    finally:
        con.close()


def get_profile_doc(customer_id):
    con = connect()
    try:
        row = con.execute(
            "SELECT * FROM customer_profile WHERE customer_id=?"
            " ORDER BY id DESC LIMIT 1", (customer_id,)).fetchone()
        if not row:
            return None
        d = dict(row)
        try:
            d["sections"] = json.loads(d.get("sections") or "{}")
        except (ValueError, TypeError):
            d["sections"] = {}
        return d
    finally:
        con.close()


# ---------- msg_queue(待 AI 识别的消息:代码先滤,筛中的丢后台) ----------

def enqueue_msg(message_id, customer_id):
    """把一条消息排进后台 AI 队列。返回队列行 id(已存在则返回它原来的 id)。"""
    con = connect()
    try:
        cur = con.execute(
            "INSERT OR IGNORE INTO msg_queue(message_id, customer_id, status,"
            " created_at) VALUES(?,?,?,?)",
            (message_id, customer_id, "pending", now_iso()))
        con.commit()
        if cur.lastrowid:
            return cur.lastrowid
        row = con.execute("SELECT id FROM msg_queue WHERE message_id=?",
                          (message_id,)).fetchone()
        return row["id"] if row else None
    finally:
        con.close()


def next_queued_msg():
    """取一条待处理消息(含正文),没有则 None。

    重试超过 3 次的直接跳过(由 bump_queue_attempt 计数)—— 不能让一条坏消息
    把后台线程卡死(踩过:一个 TypeError 让 worker 18 小时反复重跑同一条)。
    """
    con = connect()
    try:
        row = con.execute(
            "SELECT q.id AS qid, q.customer_id, m.id AS mid, m.content, m.direction,"
            " m.ts FROM msg_queue q JOIN messages m ON m.id = q.message_id"
            " WHERE q.status='pending' AND COALESCE(q.attempts,0) < 3"
            " ORDER BY q.id LIMIT 1").fetchone()
        return dict(row) if row else None
    finally:
        con.close()


def bump_queue_attempt(qid):
    """给一条队列消息记一次失败尝试,返回累计次数。"""
    con = connect()
    try:
        con.execute("UPDATE msg_queue SET attempts=COALESCE(attempts,0)+1 WHERE id=?",
                    (qid,))
        row = con.execute("SELECT attempts FROM msg_queue WHERE id=?",
                          (qid,)).fetchone()
        con.commit()
        return int(row["attempts"] or 0) if row else 0
    finally:
        con.close()


def finish_queued(qid, status="done", kind="", promise=""):
    con = connect()
    try:
        con.execute("UPDATE msg_queue SET status=?, kind=?, promise=?,"
                    " processed_at=? WHERE id=?",
                    (status, kind, promise, now_iso(), qid))
        con.commit()
    finally:
        con.close()


def queue_stats():
    con = connect()
    try:
        n = con.execute("SELECT COUNT(*) n FROM msg_queue WHERE status='pending'").fetchone()["n"]
        last = con.execute("SELECT MAX(processed_at) t FROM msg_queue").fetchone()["t"]
        return {"pending": n, "last_done": last or ""}
    finally:
        con.close()


# ---------- ai_log(AI 处理日志:成功/被拒/unknown 都记) ----------

def add_ai_log(customer_id, task, result, quote, status, detail=""):
    con = connect()
    try:
        con.execute(
            "INSERT INTO ai_log(customer_id,task,result,quote,status,detail,created_at)"
            " VALUES(?,?,?,?,?,?,?)",
            (customer_id, task, result, quote, status, detail, now_iso()))
        con.commit()
    finally:
        con.close()


def list_ai_log(limit=500):
    con = connect()
    try:
        rows = con.execute(
            "SELECT l.*, c.name AS customer_name FROM ai_log l"
            " LEFT JOIN customers c ON c.id=l.customer_id"
            " ORDER BY l.id DESC LIMIT ?", (limit,)).fetchall()
        return [dict(r) for r in rows]
    finally:
        con.close()


def ai_log_today_count():
    """今日实际处理过的字段条数(不含 capped/disabled/batch)。"""
    con = connect()
    try:
        return con.execute(
            "SELECT COUNT(*) n FROM ai_log WHERE task!='batch'"
            " AND status IN ('ok','rejected','unknown','error')"
            " AND created_at LIKE ?", (today_iso() + "%",)).fetchone()["n"]
    finally:
        con.close()


def ai_tried_today(customer_id):
    """该客户今天是否已让 AI 处理过(避免同一客户反复烧额度)。"""
    con = connect()
    try:
        return con.execute(
            "SELECT 1 FROM ai_log WHERE customer_id=? AND created_at LIKE ? LIMIT 1",
            (customer_id, today_iso() + "%")).fetchone() is not None
    finally:
        con.close()


# (已移除旧的 find_customer_by_phone 重复定义 —— 它会覆盖上面的容错版本)

def stats():
    con = connect()
    try:
        out = {
            "customers": con.execute("SELECT COUNT(*) n FROM customers").fetchone()["n"],
            "messages": con.execute("SELECT COUNT(*) n FROM messages").fetchone()["n"],
            "knowledge": con.execute("SELECT COUNT(*) n FROM knowledge").fetchone()["n"],
            "catalog": con.execute("SELECT COUNT(*) n FROM catalog").fetchone()["n"],
            "unread": con.execute("SELECT COUNT(*) n FROM notifications WHERE read=0"
                                  ).fetchone()["n"],
            "docs": con.execute("SELECT COUNT(*) n FROM customer_docs WHERE status=?",
                                (DOC_STATUS_ACTIVE,)).fetchone()["n"],
            "ai_used_today": ai_log_today_count(),
            "reminders": {
                s: con.execute("SELECT COUNT(*) n FROM reminders WHERE status=?",
                               (s,)).fetchone()["n"]
                for s in (R_SUGGESTED, R_APPROVED, R_CANCELLED, R_DONE)
            },
        }
        return out
    finally:
        con.close()
