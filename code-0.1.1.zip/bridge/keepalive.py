# -*- coding: utf-8 -*-
"""桥接看护 / 开关(纯代码,零 token)。

  python3 keepalive.py            # 检查桥接,不在就拉起(独立进程,不会随会话被带走)
  python3 keepalive.py --status   # 只看状态
  python3 keepalive.py --stop     # 停止

桥接本身只收不发;这里只是保证它一直活着。
"""
import argparse
import os
import signal
import subprocess
import sys
import time
import urllib.request

PROJECT = os.path.dirname(os.path.abspath(__file__))
PIDFILE = os.path.join(PROJECT, "bridge.pid")
LOGFILE = os.path.join(PROJECT, "bridge.log")
STATUS = os.path.join(PROJECT, "status.json")


def scan_pids():
    pids = []
    for name in os.listdir("/proc"):
        if not name.isdigit():
            continue
        try:
            with open("/proc/%s/cmdline" % name, "rb") as f:
                cmd = f.read().decode("utf-8", "replace").replace("\x00", " ")
        except Exception:
            continue
        if "bridge.js" in cmd and "node" in cmd:
            pids.append(int(name))
    return pids


def alive():
    return len(scan_pids()) > 0


def linked(timeout=3):
    """桥接是否已连上 WhatsApp(status.json 里的 linked 字段)。"""
    try:
        import json
        with open(STATUS, encoding="utf-8") as f:
            return bool(json.load(f).get("linked"))
    except Exception:
        return False


def stopped_reason():
    """桥接自己写下的“停手”原因(status.json 的 stopped 字段)。

    只要是这些值,看护就**不再自动拉起** —— 否则会变成“拉起→被拒→再拉起”的
    刷接口循环,这正是上次封号的加速器。
    """
    try:
        import json
        with open(STATUS, encoding="utf-8") as f:
            return str(json.load(f).get("stopped") or "")
    except Exception:
        return ""


def _last_start():
    try:
        with open(os.path.join(PROJECT, "last_start.txt"), encoding="utf-8") as f:
            return float(f.read().strip() or 0)
    except Exception:
        return 0.0


def _note_start():
    try:
        with open(os.path.join(PROJECT, "last_start.txt"), "w", encoding="utf-8") as f:
            f.write(str(time.time()))
    except Exception:
        pass


def start():
    with open(LOGFILE, "ab") as logf:
        proc = subprocess.Popen(
            ["node", "bridge.js"], cwd=PROJECT, stdout=logf, stderr=logf,
            stdin=subprocess.DEVNULL, start_new_session=True)
    with open(PIDFILE, "w") as f:
        f.write(str(proc.pid))
    time.sleep(2)
    return proc.pid


def stop():
    pids = scan_pids()
    for p in pids:
        try:
            os.kill(p, signal.SIGTERM)
        except Exception:
            pass
    time.sleep(1)
    return pids


def main():
    ap = argparse.ArgumentParser(description="WhatsApp 桥接看护")
    ap.add_argument("--status", action="store_true")
    ap.add_argument("--stop", action="store_true")
    ap.add_argument("--force", action="store_true", help="忽略“已停手”标记与最短间隔,强制拉起")
    args = ap.parse_args()

    if args.status:
        if alive():
            print("OK: 桥接进程在运行 | 已连WhatsApp:", "是" if linked() else "否")
            return 0
        print("DEAD: 桥接没在运行")
        return 1

    if args.stop:
        killed = stop()
        print(("已停止进程: " + ",".join(map(str, killed))) if killed else "桥接本来就没在跑")
        return 0

    if alive():
        print("OK: 桥接已在运行,无需处理")
        return 0

    why = stopped_reason()
    if why and not getattr(args, "force", False):
        print("桥接此前已自行停手(原因: %s),看护不再自动拉起。" % why)
        print("  · 需要重新扫码 → 在软件【通道集成】点「重新扫码」")
        print("  · 确认无碍可手动: python3 keepalive.py --force")
        return 0

    # 最短重启间隔:防止“拉起→秒退→再拉起”的循环(刷接口会被判自动化)
    gap = time.time() - _last_start()
    if gap < 120 and not getattr(args, "force", False):
        print("距上次启动仅 %.0f 秒,先不重启(避免高频重试)。" % gap)
        return 0

    print("桥接未运行,正在拉起……")
    pid = start()
    _note_start()
    print("OK: 已拉起,pid=%d(独立进程)" % pid)
    return 0


if __name__ == "__main__":
    sys.exit(main())
