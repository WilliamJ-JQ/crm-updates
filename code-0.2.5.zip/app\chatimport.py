# -*- coding: utf-8 -*-
"""历史聊天导入器(纯代码,零 token)。

解决一个关键坑:**原导入器丢弃时间戳**,导致所有历史消息都记成"现在",
"最近跟进时间 / 分级节奏 / 今日跟进"全部失真。本模块保留真实日期时间。

支持格式:
  1) WhatsApp 导出(Android):  2026/9/9, 14:30 - 名字: 内容
     WhatsApp 导出(iOS):      [9/9/26, 2:30:15 PM] 名字: 内容
  2) 命令行简单格式:           IN: 内容   /   OUT: 内容
  3) 纯文本:                   每行一条(无时间戳)
续行(消息内部的换行)会自动接到上一条。

方向判定:按参与者名字区分——名字 == 客户(peer) 算"客户发来"(in),其余算"我方发出"(out)。
"""
import re
from datetime import datetime

from . import service

_HEADER_RE = re.compile(
    r"^\s*\[?"
    r"(?:(?P<date>\d{1,4}[/.\-]\d{1,2}[/.\-]\d{1,4})[，,]?\s+)?"
    r"(?P<time>\d{1,2}:\d{2}(?::\d{2})?)\s*(?P<ampm>[AaPp][Mm])?"
    r"\s*[\]\-–—]*\s*"
    r"(?P<name>[^:：]{1,40}?)\s*[:：]\s?"
    r"(?P<content>.*)$"
)


def _to_iso(date_s, time_s, ampm):
    """日期时间 → 'YYYY-MM-DD HH:MM:SS';只有时间时用今天日期;解析不了返回 None。"""
    from datetime import date as _date
    if date_s:
        parts = re.split(r"[/.\-]", date_s)
        if len(parts) != 3:
            return None
        try:
            nums = [int(p) for p in parts]
        except ValueError:
            return None
        if len(parts[0]) == 4:
            y, mo, d = nums
        else:
            mo, d, y = nums
            if y < 100:
                y += 2000
    else:
        # 只有时间(如 [14:11]),用今天日期
        today = _date.today()
        y, mo, d = today.year, today.month, today.day
    tp = time_s.split(":")
    try:
        hh, mm = int(tp[0]), int(tp[1])
        ss = int(tp[2]) if len(tp) > 2 else 0
    except ValueError:
        return None
    if ampm:
        ap = ampm.lower()
        if ap == "pm" and hh < 12:
            hh += 12
        if ap == "am" and hh == 12:
            hh = 0
    try:
        return datetime(y, mo, d, hh, mm, ss).strftime("%Y-%m-%d %H:%M:%S")
    except ValueError:
        return None


def parse_chat(text):
    """解析聊天文本。

    返回 {'messages': [{ts,name,content}], 'participants': {name: 条数}, 'has_ts': bool}
    """
    lines = [ln.rstrip() for ln in (text or "").splitlines()]
    has_header = any(_HEADER_RE.match(ln) for ln in lines if ln.strip())

    if not has_header:
        # 简单模式:每行一条;支持 IN:/OUT: 前缀
        msgs = []
        for ln in lines:
            if not ln.strip():
                continue
            up = ln.strip().upper()
            if up.startswith("IN:") or up.startswith("OUT:"):
                d = "in" if up.startswith("IN:") else "out"
                msgs.append({"ts": None, "name": "__DIR__:" + d,
                             "content": ln.split(":", 1)[1].strip()})
            else:
                msgs.append({"ts": None, "name": "", "content": ln.strip()})
        return {"messages": msgs, "participants": {}, "has_ts": False}

    # 头部模式:带续行合并
    msgs, participants, has_ts = [], {}, False
    cur = None
    current_date = None  # chat.md 格式:## 2026年9月12日
    for ln in lines:
        if not ln.strip():
            continue
        # chat.md 日期行:## 2026年9月12日
        dm = re.match(r"^#+\s*(\d{4})年(\d{1,2})月(\d{1,2})日", ln)
        if dm:
            current_date = f"{dm.group(1)}-{int(dm.group(2)):02d}-{int(dm.group(3)):02d}"
            continue
        m = _HEADER_RE.match(ln)
        if m:
            date_s = m.group("date") or current_date
            ts = _to_iso(date_s, m.group("time"), m.group("ampm"))
            name = m.group("name").strip()
            # chat.md 中名字可能带 ** 前缀,去掉
            name = name.lstrip("*").strip()
            content = m.group("content").strip()
            if ts:
                has_ts = True
            cur = {"ts": ts, "name": name, "content": content}
            msgs.append(cur)
            participants[name] = participants.get(name, 0) + 1
        elif cur is not None:
            cur["content"] = (cur["content"] + "\n" + ln.strip()).strip()
        else:
            msgs.append({"ts": None, "name": "", "content": ln.strip()})
    return {"messages": msgs, "participants": participants, "has_ts": has_ts}


def pick_peer(participants, peer_name=None):
    """客户是谁:优先用指定名字(需在参与者中存在);否则排除我方后取发言最多的。"""
    self_names = ("你", "我", "me", "Me", "ME", "You", "you", "")
    others = {k: v for k, v in participants.items() if k.strip() not in self_names}
    if peer_name and peer_name.strip() in others:
        return peer_name
    if not others:
        return None
    return max(others.items(), key=lambda kv: kv[1])[0]


def import_chat(customer_id, text, peer_name=None, default_direction="in",
                source="import"):
    """解析并批量入库(保留时间戳)。返回统计信息。"""
    from . import db
    parsed = parse_chat(text)
    peer = pick_peer(parsed["participants"], peer_name)

    # 自动从参与者名字中提取客户电话(如 +254 712 229841)
    phone_re = re.compile(r"\+?\d[\d\s\-]{7,}")
    extracted_phone = ""
    for pname in parsed["participants"]:
        if pname in ("你", "我", "me", "Me", "ME"):
            continue
        pm = phone_re.search(pname)
        if pm:
            digits = re.sub(r"\D", "", pm.group(0))
            if len(digits) >= 8:
                extracted_phone = "+" + digits
                break
    # 如果客户没有电话,自动补上
    if extracted_phone:
        cust = db.get_customer(customer_id)
        if cust and not (cust.get("phone") or "").strip():
            db.update_customer(customer_id, {"phone": extracted_phone})

    saved = 0
    for m in parsed["messages"]:
        if not m["content"].strip():
            continue
        nm = m["name"]
        sender_role = ""
        if nm.startswith("__DIR__:"):
            direction = nm.split(":", 1)[1]
        elif nm.strip() in ("你", "我", "me", "Me", "ME", "You", "you"):
            # "你"/"我" = 我方PM发出
            direction = "out"
            sender_role = "pm"
        elif peer and nm.strip().lower() == peer.strip().lower():
            # 匹配到客户 = 客户发来
            direction = "in"
            sender_role = "customer"
        else:
            # 其他参与者 = 我方同事(销售经理/团队)
            direction = "out"
            sender_role = "sm"
        service.process_message(customer_id, direction, m["content"], ts=m["ts"],
                                source=source, fast=True,
                                sender_name=nm, sender_role=sender_role)
        saved += 1
    # 批量导入完成后统一分析(快速落库后补全画像/提醒/文档)
    try:
        from . import profile
        profile.enrich_customer(customer_id)
    except Exception:
        pass
    try:
        from . import docs
        msgs = db.list_messages(customer_id=customer_id)
        for m in msgs[-200:]:  # 只分析最近200条,避免太慢
            try:
                docs.extract_code_to_db(customer_id, m["content"],
                                        direction=m["direction"], msg_id=m["id"])
            except Exception:
                pass
    except Exception:
        pass
    # 自动把同事(非客户、非我方)添加到相关人列表
    try:
        from . import db
        self_names = ("你", "我", "me", "Me", "ME", "You", "you", "")
        for pname in parsed["participants"]:
            if pname.strip() in self_names:
                continue
            if peer and pname.strip().lower() == peer.strip().lower():
                continue
            # 检查是否已存在
            existing = db.list_persons(customer_id)
            if not any(p.get("phone") == pname or p.get("name") == pname for p in existing):
                db.upsert_person(customer_id, phone=pname, name=pname, role="销售经理", source="import")
    except Exception:
        pass
    # 启动后台翻译(不阻塞导入流程)
    try:
        from . import bg_translate
        cust = db.get_customer(customer_id)
        cname = cust.get("name", "") if cust else ""
        bg_translate.start_bg_translate(customer_id, cname)
    except Exception:
        pass
    return {"imported": saved, "peer": peer, "phone": extracted_phone,
            "participants": parsed["participants"], "has_ts": parsed["has_ts"]}
