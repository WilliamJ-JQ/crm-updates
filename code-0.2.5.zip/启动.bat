@echo off
chcp 65001 >nul
cd /d %~dp0

REM ---- 首次启动时自动在桌面创建快捷方式 ----
if not exist "%USERPROFILE%\Desktop\客户工作台.lnk" (
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-shortcut.ps1"
)

REM ---- 启动客户端(exe会自动拉起python服务器) ----
start "" "客户工作台.exe"