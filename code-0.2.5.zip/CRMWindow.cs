using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Reflection;
using Microsoft.Web.WebView2.WinForms;
using Microsoft.Web.WebView2.Core;

namespace CRMWindow
{
    static class Program
    {
        [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
        [DllImport("user32.dll")] public static extern int SetProcessDpiAwarenessContext(int c);
        [DllImport("user32.dll")] public static extern IntPtr FindWindow(string lpClassName, string lpWindowName);
        [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
        [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
        [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr hWnd);

        [STAThread]
        static void Main()
        {
            bool createdNew;
            using (var mutex = new System.Threading.Mutex(true, "CRMWorkstationSingleInstance", out createdNew))
            {
                if (!createdNew)
                {
                    IntPtr hWnd = FindWindow(null, "外贸客户工作台");
                    if (hWnd != IntPtr.Zero)
                    {
                        if (IsIconic(hWnd)) ShowWindow(hWnd, 9);
                        ShowWindow(hWnd, 5);
                        SetForegroundWindow(hWnd);
                    }
                    return;
                }
                try { SetProcessDpiAwarenessContext(-4); } catch {}
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                AppDomain.CurrentDomain.AssemblyResolve += (s, e) => {
                    string name = new AssemblyName(e.Name).Name + ".dll";
                    string p = Path.Combine(Application.StartupPath, "webview2", name);
                    if (File.Exists(p)) return Assembly.LoadFrom(p);
                    return null;
                };
                // 确保服务器在运行
                EnsureServer();
                Application.Run(new MainForm());
            }
        }

        static bool IsServerUp(int port)
        {
            try {
                using (var c = new System.Net.Sockets.TcpClient())
                {
                    var ar = c.BeginConnect("127.0.0.1", port, null, null);
                    bool ok = ar.AsyncWaitHandle.WaitOne(800);
                    if (ok && c.Connected) { c.EndConnect(ar); return true; }
                }
            } catch {}
            return false;
        }

        static void EnsureServer()
        {
            int port = 8765;
            if (IsServerUp(port)) return;
            string py = Path.Combine(Application.StartupPath, "python", "pythonw.exe");
            if (!File.Exists(py)) py = "pythonw.exe";
            try {
                var psi = new ProcessStartInfo();
                psi.FileName = py;
                psi.Arguments = "main.py --no-browser";
                psi.WorkingDirectory = Application.StartupPath;
                psi.UseShellExecute = false;
                psi.CreateNoWindow = true;
                Process.Start(psi);
                // 等服务器起来,最多等15秒
                for (int i = 0; i < 30; i++)
                {
                    System.Threading.Thread.Sleep(500);
                    if (IsServerUp(port)) return;
                }
            } catch (Exception ex) {
                MessageBox.Show("启动服务器失败: " + ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }

    public class MainForm : Form
    {
        private WebView2 webView;
        private Panel titleBar;
        private Label btnMin, btnMax, btnClose;
        private NotifyIcon trayIcon;
        private bool isMax = false;
        private bool allowClose = false;
        private const int BW = 8;
        private const int TITLE_H = 36;

        [DllImport("user32.dll")] public static extern bool ReleaseCapture();
        [DllImport("user32.dll")] public static extern int SendMessage(IntPtr h, int m, int w, int l);
        [DllImport("dwmapi.dll")] public static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int val, int size);

        public MainForm()
        {
            Text = "外贸客户工作台";
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.CenterScreen;
            Size = new Size(1280, 800);
            MinimumSize = new Size(900, 600);
            BackColor = Color.FromArgb(241, 245, 249);
            Font = new Font("Microsoft YaHei UI", 9F);
            try { int v = 1; DwmSetWindowAttribute(Handle, 2, ref v, 4); } catch {}
            try { int corner = 2; DwmSetWindowAttribute(Handle, 33, ref corner, 4); } catch {}

            // 系统托盘
            InitTray();

            titleBar = new Panel();
            titleBar.Location = new Point(1, 1);
            titleBar.Size = new Size(Width - 2, TITLE_H);
            titleBar.BackColor = Color.White;
            titleBar.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            Controls.Add(titleBar);

            btnMin = MkBtn("\uE921", Width - 140); btnMin.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnMin.Click += (s,e) => WindowState = FormWindowState.Minimized;
            titleBar.Controls.Add(btnMin);
            btnMax = MkBtn("\uE922", Width - 94); btnMax.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnMax.Click += (s,e) => ToggleMax();
            titleBar.Controls.Add(btnMax);
            btnClose = MkBtn("\uE8BB", Width - 48); btnClose.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnClose.MouseEnter += (s,e) => { btnClose.BackColor=Color.FromArgb(232,17,35); btnClose.ForeColor=Color.White; };
            btnClose.MouseLeave += (s,e) => { btnClose.BackColor=Color.Transparent; btnClose.ForeColor=Color.FromArgb(100,116,139); };
            btnClose.Click += (s,e) => HideToTray();
            titleBar.Controls.Add(btnClose);

            titleBar.MouseDown += (s,e) => { if(e.Button==MouseButtons.Left) Drag(); };

            webView = new WebView2();
            webView.Location = new Point(1, TITLE_H + 1);
            webView.Size = new Size(Width - 2, Height - TITLE_H - 2);
            webView.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Controls.Add(webView);

            Shown += async (s,e) => await InitWebView();
        }

        private void InitTray()
        {
            string icoPath = Path.Combine(Application.StartupPath, "app.ico");
            Icon ico = File.Exists(icoPath) ? new Icon(icoPath) : SystemIcons.Application;

            var menu = new ContextMenuStrip();
            menu.Font = new Font("Microsoft YaHei UI", 9F);

            var showItem = new ToolStripMenuItem("显示主界面");
            showItem.Click += (s, e) => ShowWindow();
            menu.Items.Add(showItem);

            menu.Items.Add(new ToolStripSeparator());

            var exitItem = new ToolStripMenuItem("退出软件");
            exitItem.Click += (s, e) => ExitApp();
            menu.Items.Add(exitItem);

            trayIcon = new NotifyIcon();
            trayIcon.Icon = ico;
            trayIcon.Text = "外贸客户工作台";
            trayIcon.Visible = true;
            trayIcon.ContextMenuStrip = menu;
            trayIcon.MouseDoubleClick += (s, e) => { if (e.Button == MouseButtons.Left) ShowWindow(); };
        }

        private void HideToTray()
        {
            Hide();
            try { trayIcon.ShowBalloonTip(1500, "外贸客户工作台", "软件已最小化到托盘，右键托盘图标可退出", ToolTipIcon.Info); } catch {}
        }

        private void ShowWindow()
        {
            Show();
            WindowState = FormWindowState.Normal;
            Activate();
        }

        private void ExitApp()
        {
            allowClose = true;
            try { trayIcon.Visible = false; } catch {}
            try { using(var c=new WebClient()) { c.DownloadStringAsync(new Uri("http://127.0.0.1:8765/api/exit")); } } catch {}
            Application.Exit();
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (!allowClose)
            {
                e.Cancel = true;
                HideToTray();
            }
            base.OnFormClosing(e);
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == 0x0084 && WindowState != FormWindowState.Maximized)
            {
                var p = PointToClient(Cursor.Position);
                if (p.X < BW && p.Y < BW) { m.Result = (IntPtr)13; return; }
                if (p.X > Width - BW && p.Y < BW) { m.Result = (IntPtr)14; return; }
                if (p.X < BW && p.Y > Height - BW) { m.Result = (IntPtr)16; return; }
                if (p.X > Width - BW && p.Y > Height - BW) { m.Result = (IntPtr)17; return; }
                if (p.X < BW) { m.Result = (IntPtr)10; return; }
                if (p.X > Width - BW) { m.Result = (IntPtr)11; return; }
                if (p.Y < BW) { m.Result = (IntPtr)12; return; }
                if (p.Y > Height - BW) { m.Result = (IntPtr)15; return; }
            }
            base.WndProc(ref m);
        }

        private Label MkBtn(string symbol, int x)
        {
            var b = new Label { Text=symbol, Font=new Font("Segoe MDL2 Assets", 10F), ForeColor=Color.FromArgb(100,116,139),
                TextAlign=ContentAlignment.MiddleCenter, Location=new Point(x,0), Size=new Size(46,TITLE_H), Cursor=Cursors.Hand };
            b.MouseEnter += (s,e) => { b.BackColor=Color.FromArgb(241,245,249); b.ForeColor=Color.FromArgb(15,23,42); };
            b.MouseLeave += (s,e) => { b.BackColor=Color.Transparent; b.ForeColor=Color.FromArgb(100,116,139); };
            return b;
        }

        private void Drag() { ReleaseCapture(); SendMessage(Handle, 0xA1, 2, 0); }

        private void ToggleMax()
        {
            if (isMax) { WindowState=FormWindowState.Normal; btnMax.Text="\uE922"; isMax=false; }
            else { WindowState=FormWindowState.Maximized; btnMax.Text="\uE923"; isMax=true; }
        }

        private async System.Threading.Tasks.Task InitWebView()
        {
            Activate();
            try
            {
                string ud = Path.Combine(Application.StartupPath, "data", "webview2");
                Directory.CreateDirectory(ud);
                var env = await CoreWebView2Environment.CreateAsync(null, ud);
                await webView.EnsureCoreWebView2Async(env);
                webView.CoreWebView2.Settings.AreDevToolsEnabled = false;
                webView.CoreWebView2.Settings.IsZoomControlEnabled = false;
                webView.CoreWebView2.Navigate("http://127.0.0.1:8765/");
            }
            catch (Exception ex) { FallbackEdge(ex.Message); }
        }

        private void FallbackEdge(string reason)
        {
            string[] c = { @"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
                           @"C:\Program Files\Microsoft\Edge\Application\msedge.exe" };
            foreach (var p in c) if (File.Exists(p)) {
                try { Process.Start(p, "--app=http://127.0.0.1:8765/"); allowClose=true; Close(); return; } catch {}
            }
            MessageBox.Show("无法启动窗口: " + reason, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
