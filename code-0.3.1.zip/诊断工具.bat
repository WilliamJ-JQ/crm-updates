@echo off
title CRM Workstation Diagnostic Tool
color 0A

echo ========================================
echo   CRM Workstation Diagnostic Tool
echo ========================================
echo.

echo [1/8] Checking current directory...
cd /d "%~dp0"
echo   Current: %CD%
echo.

echo [2/8] Checking files...
if exist "CRMWorkstation.exe" (echo   [OK] CRMWorkstation.exe) else (echo   [MISSING] CRMWorkstation.exe)
if exist "python\pythonw.exe" (echo   [OK] python\pythonw.exe) else (echo   [MISSING] python\pythonw.exe)
if exist "main.py" (echo   [OK] main.py) else (echo   [MISSING] main.py)
if exist "app\server.py" (echo   [OK] app\server.py) else (echo   [MISSING] app\server.py)
echo.

echo [3/8] Checking WebView2 runtime...
reg query "HKLM\SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}" /v pv >nul 2>&1
if %errorlevel%==0 (echo   [OK] WebView2 installed) else (
    reg query "HKCU\SOFTWARE\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}" /v pv >nul 2>&1
    if %errorlevel%==0 (echo   [OK] WebView2 installed) else (
        echo   [MISSING] WebView2 NOT installed, installing...
        if exist "MicrosoftEdgeWebView2Setup.exe" (
            start /wait "" "MicrosoftEdgeWebView2Setup.exe" /silent /install
            echo   WebView2 installed
        ) else (echo   [ERROR] WebView2 installer not found)
    )
)
echo.

echo [4/8] Checking port 8765...
netstat -ano | findstr ":8765" >nul 2>&1
if %errorlevel%==0 (echo   [OK] Port 8765 in use) else (echo   [INFO] Port 8765 free)
echo.

echo [5/8] Killing old processes...
taskkill /f /im "CRMWorkstation.exe" >nul 2>&1
taskkill /f /im "pythonw.exe" >nul 2>&1
taskkill /f /im "python.exe" >nul 2>&1
timeout /t 2 /nobreak >nul
echo   Done
echo.

echo [6/8] Starting server (with console to show errors)...
echo   Close the server window after testing.
start "CRM-Server-Debug" "python\python.exe" "main.py" --no-browser
timeout /t 10 /nobreak >nul
echo.

echo [7/8] Checking if server started...
netstat -ano | findstr ":8765" >nul 2>&1
if %errorlevel%==0 (echo   [OK] Server running on port 8765) else (echo   [ERROR] Server did NOT start, check console window)
echo.

echo [8/8] Starting CRM Workstation window...
if exist "CRMWorkstation.exe" (
    start "" "CRMWorkstation.exe"
    echo   Window launched
) else (echo   [ERROR] CRMWorkstation.exe not found)
echo.

echo ========================================
echo   Diagnostic complete
echo ========================================
echo If window does not appear, check:
echo 1. Server console window for errors
echo 2. WebView2 installation
echo 3. Try running CRMWorkstation.exe directly
echo.
pause