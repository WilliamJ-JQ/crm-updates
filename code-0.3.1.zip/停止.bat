@echo off
title Stop CRM Workstation

echo ========================================
echo   Stopping all processes...
echo ========================================
echo.

taskkill /f /im "CRMWorkstation.exe" >nul 2>&1
taskkill /f /im "?????.exe" >nul 2>&1
taskkill /f /im pythonw.exe >nul 2>&1
taskkill /f /im python.exe >nul 2>&1
taskkill /f /im node.exe >nul 2>&1
taskkill /f /im llama-server.exe >nul 2>&1
taskkill /f /im python-translate.exe >nul 2>&1

echo.
echo ========================================
echo   All processes stopped
echo ========================================
echo.
timeout /t 3 /nobreak >nul
exit /b 0